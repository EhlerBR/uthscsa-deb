# format.p.value.v0.1.r
# Christopher Louden
# 2 Nov 2011
# Input: x - A vector of p-values to be formated
# Output: p - A vector of formated p-values

format.p.value <- function(x){
   p <- as.character(round(x, digits = 2))
   p[x < 0.01] <- as.character(round(x[x < 0.01], digits = 3))
   p[x < 0.001] <- "< 0.001"
   return(p)
}

### EOF ###