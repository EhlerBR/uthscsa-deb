# smart.round.v0.1.r
# Christopher Louden
# 2 Nov 2011
# Input: x - A vector of numbers to be rounded
#        min.round - the minimum value digits can be in the round function
#        max.round - the maximum value digits can be in the round function
# Output: y - A vector of rounded numbers

smart.round <- function(x, min.round = 1, max.round = 4){
   if(min.round == max.round){
      y <- round(x, digit = min.round)
      return(y)
   }
   y <- round(x, digit = min.round)
   for(digit in (min.round + 1):max.round){
      y[y == 0] <- round(x[y == 0], digit = digit)
   }
   return(y)
}

### EOF ###