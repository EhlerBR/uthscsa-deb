#
#  Summarize Data Set
#

summarize.data.frame <- function(data., outcome., columns. = NULL, names. = names(data.), levels. = levels(outcome.), output. = FALSE, filename. = "summary.csv", cont_test = "kw", cat_test = "chisq", row.perc = FALSE, cat.round = 2, cont.round = NULL, no.col.print = FALSE){
 
   counter <- 0
   table <- NULL
   pvalues <- NULL
   if(is.null(columns.)) columns. <- 1:dim(data.)[2]
   for(column in columns.){
      if(!no.col.print) print(column)
      counter <- counter + 1
      if(is.numeric(data.[, column])){
         temp <- cont_sum(outcome.[!is.na(data.[, column])], data.[!is.na(data.[, column]), column], levels., names.[column], panel = counter, test = cont_test, round = cont.round)
      } else {
         temp <- cat_sum(outcome.[!is.na(data.[, column])], data.[!is.na(data.[, column]), column], levels., names.[column], panel = counter, test = cat_test, row.perc = row.perc, round = cat.round)
      }
      table <- rbind(table, temp[[1]])
      pvalues <- rbind(pvalues, temp[[2]])
   }

   if(output.) write.csv(table, filename., row.names = FALSE)
   return(list(table = table, pvalues = pvalues))
}



### EOF ###