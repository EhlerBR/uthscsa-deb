#
#  Support_functions.R
#





makePrettyTests <- function(tableOut){

# Will make the tests column in the summary statement pretty in tables

nrows <- nrow(tableOut)
tableOut$test <- as.character(tableOut$test)
tester <- ""

for(i in 1:nrows){

if(tester!=""){ tableOut$test[i] <- ""}
	
tester <- tableOut$Label[i]
	
}

return(tableOut)

}#END makePrettyTests


Split.runs <- function(factor,step){

# puts page breaks into factor
# takes sorted "factor" variable
# splits it into sections of size "step" or less


baby.steps <- length(factor)


factor <- as.numeric(factor)

current <- 1

lastFactor <- factor[1]

pager <- rep(1,baby.steps)

previous.page <- 1

spacer <- step

for(steper in 1:max(factor)){
	
	factor.space <- factor == steper
	
	factor.length <- sum(factor.space)
	
	if(factor.length<=step){
	
		inclusion.test <- factor.length <= spacer
		
		#print(inclusion.test)
		#print(factor.length)
		#print(spacer)
	
		if(inclusion.test) {
			
			pager[factor.space] <- previous.page
			
			spacer <- spacer - factor.length
			
			}else{
			
				previous.page <- previous.page + 1	
				
				spacer <- step - factor.length
				
				pager[factor.space] <- previous.page
				
				}
		
		
	} else { # long factors
	
			# put it on its own set of pages
			
			print("Split.runs WARNING: Factor > Page length")
			
			#start new page if not 1st factor level on that page
			if (spacer!=step) {previous.page <- previous.page + 1	}
						
			skipper <- ceiling((1:factor.length)/step) +  (previous.page-1)
			
			pager[factor.space] <- skipper
		
			previous.page <- max(skipper) + 1	
				
			spacer <- step
			
			
		
		}
  } #go through factor levels


return(pager)


} # END: Split.runs


Page.checker <- function(factor,pagination,page.length){

  # Checks the "pagination" of "factor"
  # page.length is the length of the page
  
  page.out <- matrix(0,page.length,max(pagination))
  
  
  for(page in sort(unique(pagination))){
  	
  	lines.in.page <- 1:sum(pagination==page)
  	  	
  	page.out[lines.in.page,page] <- factor[pagination==page]
  }
  
  
  return(page.out)
	
	
  }# END: Page.checker



