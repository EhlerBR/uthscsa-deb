
# from: 'http://stackoverflow.com/questions/1260965/developing-geographic-thematic-maps-with-r'

plot.heat <- function(counties.map,state.map,z,title=NULL,breaks=NULL,reverse=FALSE,cex.legend=1,bw=.2,col.vec=NULL,plot.legend=TRUE,xlim = NULL, ylim = NULL, xaxt = "s", yaxt = "s", xlab = NULL, ylab = NULL) {

  ##Break down the value variable
  if (is.null(breaks)) {
    breaks=
      seq(
          floor(min(counties.map@data[,z],na.rm=TRUE)*10)/10,
          ceiling(max(counties.map@data[,z],na.rm=TRUE)*10)/10,
          .1)
      }
  counties.map@data$zCat <- cut(counties.map@data[,z],breaks,include.lowest=TRUE)
  cutpoints <- levels(counties.map@data$zCat)
  if (is.null(col.vec)) col.vec <- heat.colors(length(levels(counties.map@data$zCat)))
  if (reverse) {
    cutpointsColors <- rev(col.vec)
  } else {
    cutpointsColors <- col.vec
  }
  levels(counties.map@data$zCat) <- cutpointsColors
  plot(counties.map,border=gray(.8), lwd=bw,axes = TRUE, las = 1,col=as.character(counties.map@data$zCat),xlim = xlim, ylim = ylim, xlab = xlab, ylab = ylab, xaxt = xaxt, yaxt = yaxt)
  if (!is.null(state.map)) {
    plot(state.map,add=TRUE,lwd=1,border=gray(.8))
  }
  ##with(counties.map.c,text(x,y,name,cex=0.75))
  if (plot.legend) legend("bottomleft", cutpoints, fill = cutpointsColors,bty="n",title=title,cex=cex.legend)
  ##title("Cartogram")
}

