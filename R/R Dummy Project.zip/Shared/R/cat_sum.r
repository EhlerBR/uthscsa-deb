#
# Summarize Categorical Variables
#

cat_sum <-      function(class, var, class.labels, var.name, var.label = levels(var), test = "chisq", panel = 1, row.perc = FALSE, round = 2, ...){

  if(!is.factor(class)){ class <- as.factor(class) }
  if(!is.factor(var)){ var <- as.factor(var) }
  n.class <- length(levels(class)); n.var.class <- length(levels(var))
  contingency <- table(var, class);
  
  if(sum(contingency < 5)){ test <- "fisher" }
  if(n.class > 3 | n.var.class > 3){ simulate.p.value <- TRUE } else { simulate.p.value <- FALSE }
  
  if(test == "chisq"){ pval <- chisq.test(contingency)$p.value
  } else { pval <- fisher.test(contingency, simulate.p.value = simulate.p.value)$p.value
  }
  
# Changed Total to show total of var regardless of missing status of class #
#  rowsums <- apply(contingency, 1, sum) # commented out 17 Aug 2012
  rowsums <- table(var) # added 17 Aug 2012
  colsums <- c(apply(contingency, 2, sum), sum(contingency))
  colsums[length(colsums)] <- sum(rowsums)  # added 17 Aug 2012
  
  if(row.perc){
    percents <- round(100*matrix(contingency, ncol = n.class)/matrix(rep(rowsums, n.class), nrow = n.var.class, byrow = FALSE), round)
    contingency <- rbind(cbind(matrix(paste(contingency, " (", percents, ")", sep = ""), ncol = n.class), rowsums), as.character(colsums))
  } else {
    percents <- round(100*cbind(matrix(contingency, ncol = n.class)/matrix(rep(colsums[1:n.class], n.var.class), ncol = n.class, byrow = TRUE), rowsums/colsums[(n.class + 1)]), round)
    contingency <- rbind(matrix(paste(cbind(contingency, rowsums), " (", percents, ")", sep = ""), ncol = n.class + 1), as.character(colsums))
  }
  
  var.labels <- c(var.name, var.label, "Total")
  row.blank <- rep("", n.class + 3)
  
  contingency <- cbind(matrix(var.labels, ncol = 1), rbind(row.blank[1:(n.class + 1)], contingency))
  
  col.pval <- c(format.p.val(pval), rep("", n.var.class + 1))
  contingency <- rbind(cbind(contingency, col.pval), row.blank)
  
  class.labels <- c("Label", class.labels, "Total", "Pval")
  colnames(contingency) <- class.labels; rownames(contingency) <- NULL
  contingency <- as.data.frame(cbind(contingency, row = 1:(n.var.class + 3), panel = panel, test = test))
  
  return(list(contingency, pval))
}


### EOF ###