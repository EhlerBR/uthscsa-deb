### extract.zip.r ###
# Aetna Opiates Data
# Author: Benjamin Ehler
# Date: 10 DEC 2012
# Inputs: 
#         
# Output:
#
######################################################################

# USE TO FIND MODE AND APPLY ALGORITHM FOR MULTIMODAL VECTORS OF ZIP CODES #

extract.zip <- function(data, ID = "MEMBER_ID", zip = "zip", latitude = "lat", longitude = "lon", prescriber = "presc.id", start.bin = "start_bin"){ 
  new.data.matrix <- matrix(NA, nrow = length(unique(data[[ID]])), ncol = 21)           
  counter <- 0
  data.m <- NULL
  data <- as.data.frame(data)
  data[[zip]] <- as.numeric(as.character(data[[zip]]))
  data[[latitude]] <- as.numeric(as.character(data[[latitude]]))
  data[[longitude]] <- as.numeric(as.character(data[[longitude]]))    
  data[[start.bin]] <- as.numeric(as.character(data[[start.bin]]))
  for(id_index in unique(data[[ID]])){
    counter <- counter + 1
    temp.subset <- data[data[[ID]] == id_index,]
    n.zips.0 <- length(unique(temp.subset[[zip]][temp.subset[[start.bin]] == 0]))
    n.zips.1 <- length(unique(temp.subset[[zip]][temp.subset[[start.bin]] == 1]))
    n.zips.2 <- length(unique(temp.subset[[zip]][temp.subset[[start.bin]] == 2]))
    n.zips.3 <- length(unique(temp.subset[[zip]][temp.subset[[start.bin]] == 3]))
    n.zips.4 <- length(unique(temp.subset[[zip]][temp.subset[[start.bin]] == 4]))
    n.zips.5 <- length(unique(temp.subset[[zip]][temp.subset[[start.bin]] == 5]))
    n.zips.6 <- length(unique(temp.subset[[zip]][temp.subset[[start.bin]] == 6]))
    n.zips.7 <- length(unique(temp.subset[[zip]][temp.subset[[start.bin]] == 7]))                            
    n.zips.8 <- length(unique(temp.subset[[zip]][temp.subset[[start.bin]] == 8]))                                
    
    n.presc.0 <- length(unique(temp.subset[[prescriber]][temp.subset[[start.bin]] == 0])) 
    n.presc.1 <- length(unique(temp.subset[[prescriber]][temp.subset[[start.bin]] == 1])) 
    n.presc.2 <- length(unique(temp.subset[[prescriber]][temp.subset[[start.bin]] == 2])) 
    n.presc.3 <- length(unique(temp.subset[[prescriber]][temp.subset[[start.bin]] == 3])) 
    n.presc.4 <- length(unique(temp.subset[[prescriber]][temp.subset[[start.bin]] == 4])) 
    n.presc.5 <- length(unique(temp.subset[[prescriber]][temp.subset[[start.bin]] == 5])) 
    n.presc.6 <- length(unique(temp.subset[[prescriber]][temp.subset[[start.bin]] == 6])) 
    n.presc.7 <- length(unique(temp.subset[[prescriber]][temp.subset[[start.bin]] == 7]))                             
    n.presc.8 <- length(unique(temp.subset[[prescriber]][temp.subset[[start.bin]] == 8])) 
    
    mlv.lat <- mlv(temp.subset[[latitude]], method = "mfv", na.rm = TRUE)
    if(length(mlv.lat$boot.M) == 1) {
        member.lat <- mlv.lat$M
    } else {
      med <- median(temp.subset[[latitude]], na.rm = TRUE)
      closest <- NULL
      diff <- Inf
      for(mode_index in mlv.lat$boot.M){
        if(abs(med - mode_index) < diff) {
          closest <- mode_index
          diff <- abs(med - mode_index)
        }
      }
      member.lat <- closest
    }
    
    mlv.lon <- mlv(temp.subset[[longitude]], method = "mfv", na.rm = TRUE)  
    if(length(mlv.lon$boot.M) == 1) {
      member.lon <- mlv.lon$M
    } else {
      med <- median(temp.subset[[longitude]], na.rm = TRUE)
      closest <- NULL
      diff <- Inf
      for(mode_index in mlv.lon$boot.M){
        if(abs(med - mode_index) < diff) {
          closest <- mode_index
          diff <- abs(med - mode_index)
        }
      }
      member.lon <- closest
    }
        
    new.data.matrix[counter,] <- c(id_index, member.lat, member.lon, n.zips.0, n.zips.1, n.zips.2, n.zips.3, n.zips.4, n.zips.5, n.zips.6, n.zips.7, n.zips.8,
                                      n.presc.0, n.presc.1, n.presc.2, n.presc.3, n.presc.4, n.presc.5, n.presc.6, n.presc.7, n.presc.8)
    if(counter %% 100 == 0)  print(paste(counter, "of", length(unique(data[[ID]]))))
    if(counter %% 1000 == 0)  print(format(Sys.time(), "%X"))
  }
  new.data.matrix <- as.data.frame(new.data.matrix)
  names(new.data.matrix) <- c("MEMBER_ID", "member_lat", "member_lon", "n_zips_0", "n_zips_1", "n_zips_2", "n_zips_3", "n_zips_4", "n_zips_5", "n_zips_6", "n_zips_7", "n_zips_8", 
                                  "n.presc_0", "n.presc_1", "n.presc_2", "n.presc_3", "n.presc_4", "n.presc_5", "n.presc_6", "n.presc_7", "n.presc_8")
  return(new.data.matrix)
}



