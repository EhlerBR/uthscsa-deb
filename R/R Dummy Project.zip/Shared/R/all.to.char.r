all.to.char <- function(data) {
  for(col_index in 1:dim(data)[2])
    data[, col_index] <- as.character(data[, col_index])
}