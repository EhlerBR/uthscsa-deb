run.end.time <- function(pts, times, n) {
  time.sec <- NULL
  for(row_index in 1:length(times)){
    hr <- substr(times[row_index], 1, 2)
    min <- substr(times[row_index], 3, 4)
    sec <- substr(times[row_index], 5, 6)
    time.sec <- c(time.sec, as.numeric(hr) * 3600 + as.numeric(min) * 60 + as.numeric(sec))
  }
  lm <- lm(pts ~ time.sec)$coefficients
  end.time <- (n - lm[1]) / lm[2]
  end.hrs <- as.integer(end.time/3600)
  end.mins <- as.integer((end.time - (end.hrs * 3600)) / 60)
  end.secs <- as.integer(end.time - (end.hrs * 3600) - (end.mins * 60))
  format.end.time <- paste(end.hrs, end.mins, end.secs, sep = ":")
  plot(time.sec, pts, xaxt = "n")
  at.pts <- seq(min(time.sec), max(time.sec), length = 8)
  label.hrs <- as.integer(at.pts/3600)
  label.mins <- as.integer((at.pts - (label.hrs * 3600)) / 60)
  label.secs <- as.integer(at.pts - (label.hrs * 3600) - (label.mins * 60))
  label.hrs <- ifelse(nchar(label.hrs) == 1, paste("0", label.hrs, sep = ""), label.hrs)
  label.mins <- ifelse(nchar(label.mins) == 1, paste("0", label.mins, sep = ""), label.mins)
  label.secs <- ifelse(nchar(label.secs) == 1, paste("0", label.secs, sep = ""), label.secs)
  labels <- paste(label.hrs, label.mins, label.secs, sep = ":")
  abline(lm)
  axis(1, at = at.pts, labels = labels)
  
  return(format.end.time)
}
