# takes a numeric time and formats it as a character "%H:%M:%S"

number.to.time <- function(x){
  n.x <- length(x)
  new.x <- NULL
  for(index in 1:n.x){
    time <- x[index]
    time <- round(time)
    time.h <- floor(time / 3600)
    time.m <- floor((time - (time.h * 3600)) / 60)
    time.s <- (time - (time.h * 3600) - (time.m * 60))
#    n.days <- floor(time.h / 24) # Messes up Summary
#    time.h <- ifelse(n.days > 0, time.h / n.days, time.h)
    time.h <- as.character(time.h)
    time.h <- ifelse(nchar(time.h) == 1, paste("0", time.h, sep = ""), time.h)
    time.m <- as.character(time.m)
    time.m <- ifelse(nchar(time.m) == 1, paste("0", time.m, sep = ""), time.m)
    time.s <- as.character(time.s)
    time.s <- ifelse(nchar(time.s) == 1, paste("0", time.s, sep = ""), time.s)
    format.time <- paste(time.h, time.m, time.s, sep = ":")
    new.x <- c(new.x, format.time)
  }
  return(new.x)
}

time.to.number <- function(x){
  n.x <- length(x)
  new.x <- NULL
  for(index in 1:n.x){
    time <- as.character(x[index])
    time.h <- as.numeric(substr(time, 1, (gregexpr(":", time)[[1]][1] - 1)))
    time.m <- as.numeric(substr(time, (gregexpr(":", time)[[1]][1] + 1), (gregexpr(":", time)[[1]][2] - 1)))
    time.s <- as.numeric(substr(time, c(gregexpr(":", time)[[1]][2] + 1), nchar(time)))
    format.time <- time.h * 3600 + time.m * 60 + time.s
    new.x <- c(new.x, format.time)
  }
  return(new.x)
}
  

