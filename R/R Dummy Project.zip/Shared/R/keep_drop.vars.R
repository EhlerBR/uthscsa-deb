keep.vars <- function(set, vars){
  class <- class(set)
  set <- as.data.frame(set)
  var.pos <- grep(TRUE, names(set) %in% vars)
  set <- set[,var.pos]
  if(class == "matrix")
    as.matrix(set)
  return(set)
}

drop.vars <- function(set, vars){
  class <- class(set)
  set <- as.data.frame(set)
  var.pos <- grep(TRUE, names(set) %in% vars)
  set <- set[,-var.pos]
  if(class == "matrix")
    as.matrix(set)  
  return(set)
}