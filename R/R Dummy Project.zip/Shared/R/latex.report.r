# Filename:     latex.report.r ###
# Project Name: LaTeX function
# Author:       Ben Ehler
# Date:         25 April 2013

####################################################################################################################################################
### THE PURPOSE OF THIS FUNCTION IS TO COMBINE ALL DOCUMENTS FOR A PROJECT AND LINK THEM TO A LATEX FILE THROUGH A MATRIX OF EACH FILE'S         ###
### DESCRIPTION AND PATH                                                                                                                         ###
####################################################################################################################################################

####################################################################################################################################################
### EXPLANATION OF INPUT/OPTIONS:                                                                                                                ###
### descriptions: Vector of character strings that describe the file of its corresponding link                                                   ###
### links: Vector of character strings that contain the path of each file                                                                        ###
### project.directory: Path to the folder that contains all subsequent paths to the files; this is the path where the LaTeX pdf will be written  ###
### pdf.filename: Name of the pdf file WITHOUT an extension. CANNOT CONTAIN SPACES [default is AllResults(date)]                                 ###
####################################################################################################################################################


latex.report <- function(descriptions, links, project.directory = dir, pdf.filename = NULL) {

  LinkedFiles <- matrix(c(descriptions, links), ncol = 2, byrow = FALSE)

  loc <- c(gregexpr(pattern="/", text=project.directory)[[1]])
  loc <- loc[length(loc) - 1]
  ProjectName <- substr(project.directory, loc + 1, nchar(project.directory) - 1)

  if(is.null(pdf.filename))
    pdf.filename <- paste("AllResults(", gsub(" ", "", date), ")", sep = "")

  pdf.filename <- paste(pdf.filename, ".tex", sep = "")

  file.data <- as.data.frame(LinkedFiles)
  names(file.data) <- c("description", "hyperlink")

  tex.list <- list()

  file.data$hyperlink <- gsub(paste(".*", ProjectName, "/", sep = ""), "", file.data$hyperlink)
  temp <- latex.file.table.out(file.data)
  tex.list <- lcat(tex.list,temp)

  table.files <- write.includer.vector(tex.list,path=project.directory,include.file.base="includeme_tables")
  make.latex.doc.vector(pastes(project.directory, pdf.filename), includer=table.files,title="Analysis",
                        author="Benjamin Ehler", date=date, path=NULL)

  latex.log <- shell(paste("C: & cd ", project.directory, " & pdflatex ", pdf.filename, sep = ""))
  erase.files <- c("LinkedFiles.rdata", "includeme_tables1.tex", "includeme_tables1.aux",
                  paste(gsub(".tex", "", pdf.filename), c(".tex", ".out", ".log", ".aux"), sep = ""))
  for(file_index in erase.files) {
    unlink(paste(project.directory, file_index, sep = ""))
  }

}
