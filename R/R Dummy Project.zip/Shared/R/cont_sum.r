#
# Summarize Continuous Variables
#

cont_sum <- function(class, var, class.labels, var.name, test = "kw", round = NULL, panel = 1){
   if(!is.factor(class)){ class <- as.factor(class) }

   if(is.null(round)) {
     if(mean(var, na.rm = TRUE) > 1){ round = 1
     } else { round = 2 }
   }

   not.missing <- !is.na(var)
   n <- c(aggregate(not.missing, list(path = class), sum, na.rm = TRUE)[, 2], sum(not.missing))
   mean <- c(round(aggregate(var, list(path = class), mean, na.rm = TRUE)[, 2], round), round(mean(var, na.rm = TRUE), round))
   median <- c(round(aggregate(var, list(path = class), median, na.rm = TRUE)[, 2], round), round(median(var, na.rm = TRUE), round))
   sd <- c(round(aggregate(var, list(path = class), sd, na.rm = TRUE)[, 2], round), round(sd(var, na.rm = TRUE), round))
   sd_chk <- c(aggregate(var, list(path = class), sd, na.rm = TRUE)[, 2], sd(var, na.rm = TRUE))
   for(i in 1:length(sd)){
      if(!is.na(sd[i]) & sd[i] == 0 & sd_chk[i] > 0){ sd[i] <- 0.01 }
   }
   q1 <- c(round(aggregate(var, list(path = class), quantile, probs = 0.25, na.rm = TRUE)[, 2], round), round(quantile(var, probs = 0.25, na.rm = TRUE), round))
   q3 <- c(round(aggregate(var, list(path = class), quantile, probs = 0.75, na.rm = TRUE)[, 2], round), round(quantile(var, probs = 0.75, na.rm = TRUE), round))
   min <- c(round(aggregate(var, list(path = class), min, na.rm = TRUE)[, 2], round), round(min(var, na.rm = TRUE), round))
   max <- c(round(aggregate(var, list(path = class), max, na.rm = TRUE)[, 2], round), round(max(var, na.rm = TRUE), round))

#   if(ifelse(is.na(sum(mean/sd < 2)), 2, sum(mean/sd < 2)) > 1){ test <- "kw" }

   # Check that no one group has all observations
   length.check <- 0
   for(i in 1:length(class.labels)){
      if(length(var[class == levels(class)[i]]) == length(var)) length.check <- 1
   }

   if(length.check == 0){
      if(test == "anova"){ pval <- anova(lm(var ~ class))["Pr(>F)"][[1]][1]
      } else if(test == "log"){  pval <- anova(lm(ifelse(var == 0, NA, log(var)) ~ class))["Pr(>F)"][[1]][1]
      } else { pval <- kruskal.test(var ~ class)$p.value }
   } else {
      pval <- NA
   }

#   pval <- anova(lm(log(var + 0.001) ~ class))["Pr(>F)"][[1]][1]

   row.n <- c("N", as.character(n), "")
   row.mean <- c("Mean�SD", paste(mean, "�", sd, sep = ""), "")
   row.median <- c("Median [Q1, Q3]", paste(median, " [", q1, ", ", q3, "]", sep = ""), "")
   row.range <- c("Min, Max", paste(min, ", ", max, sep = ""), "")
   row.blank <- rep("", length(row.n))
   row.name <- c(var.name, rep("", length(row.n) - 2), format.p.val(pval))
   table <- cbind(rbind(row.name, row.n, row.mean, row.median, row.range, row.blank), row = 1:6, panel = panel, test = test)
   bound <- length(class.labels) + 3
   colnames(table)[1:bound] <- c("Label", class.labels, "Total", "Pval")
   rownames(table) <- NULL
   return(list(table, pval))
}



### EOF ###