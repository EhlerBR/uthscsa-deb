# MultiPlot plots multiple, side-by-side plots that use identical x and y axes. #  

MultiPlot <- function(data, x.col = NULL, y.col = 1:dim(data)[2], group.col = NULL, dim = c(2,2), ylab = "y", xlab = "x", main = "Multiplot", 
                   byrow = TRUE, filename = NULL, legend.titles = names(data), legend.position = "topright", legend.space = FALSE, 
                   x.at = NULL, y.at = NULL, x.axis.labels = NULL, y.axis.labels = NULL){
 
# data:            dataframe or matrix that contains the data to be plotted
# x.col:           the column number where the x variable is found
# y.col:           the column number(s) where the y variable(s) is found
# group.col:       optional column number where groups are stored
# dim:             dimensions of the plots for each page
# ylab:            for main y axis
# xlab:            for main x axis
# main:            for main title
# byrow:           logical; whether the plots should be read by row or not (mfrow or mfcol)
# filename:        where pdf will be stored; NULL dictates no output
# legend.titles:   legend titles; same length as y.col
# legend.position: Keywork position for legend placement ("topright", "bottomleft", "right", etc...)
# legend.space:    logical; should the x axes be extended to fit the legend
# x.at:            where x labels should be shown on the x axis
# y.at:            where y labels should be shown on the y axis
# x.axis.labels:   x axis labels if x.at is set
# y.axis.labels:   y axis labels if y.at is set
 
  if(!is.null(filename)) pdf(file = paste(documents.dir, filename, ".pdf", sep = ""))
  
  plots.page <- dim[1] * dim[2]
  n.plots <- length(y.col)
  n.pages <- ceiling(n.plots/plots.page)

  page.min <- NULL
  page.max <- NULL
  for(page_index in 1:n.pages){
    page.min[[page_index]] <- (page_index - 1) * plots.page + 1
    if(page_index == n.pages){
      page.max[[page_index]] <- n.plots
    } else {
      page.max[[page_index]] <- page.min[[page_index]] + (plots.page - 1)
    }
  }
  
  ymin <- floor(min(c(as.matrix(data[,y.col])), na.rm = TRUE))
  ymax <- ceiling(max(c(as.matrix(data[,y.col])), na.rm = TRUE))
   
  x.col <- as.numeric(as.character(x.col))
  if(length(x.col) != 1)
    stop("x.col must be a single, numeric value")
  if(is.na(x.col))
    stop("x.col must be a single, numeric value")  
  x <- data[,x.col]
  if(!is.numeric(x)){
    x <- factor(x, unique(x), unique(x))
    stop("x as factor is not finished")
    print("Warning: x is non-numeric; read as factor")
  }

  xmin <- floor(min(x, na.rm = TRUE))
  xmax <- ceiling(max(x, na.rm = TRUE))
  xmax.for.label <- xmax
  if(legend.space) xmax <- xmax + ((xmax + 1 - xmin) * .33)  
  
  par(oma = c(5,5,3,1))
  par(mar = c(0,0,0,0))
  if(byrow) {
    par(mfrow = dim)
  } else {
    par(mfcol = dim)
  }

  p <- plots.page
  n <- n.plots
  n.row <- dim[1]
  n.col <- dim[2]
  n.full <- floor(n/p)*p
  grand <- ceiling(n/p)*p 
  
  if(byrow){
  
     x.axis.loc <- NULL
    if(n > p){
      for(i in 0:(n.col-1)){
        x.axis.loc <- c(x.axis.loc, seq(p-i, n.full-i, p))
      }
    }
    if(!n %in% seq(0, grand, p)){
      for(i in 1:n.col){
        if(n %in% seq(i, grand, p)){
          x.axis.loc <- c(x.axis.loc, n:(n.full + 1))
        }
      }
      if(n > (n.full + n.col)){
        x.axis.loc <- c(x.axis.loc, n:(n - n.col + 1))
      }
    }

    y.axis.loc <- seq(1, n, n.col)

  } else {
  
    if(n > p) x.axis.loc <- seq(n.row,n.full,n.row)
    else x.axis.loc <- NULL
    for(i in 1:n.col){
      if(n >= i) x.axis.loc <- c(x.axis.loc, n.full + (n.row * i))
    }
    if(!n %in% seq(n.row, n, n.col)) x.axis.loc <- c(x.axis.loc, n)
    
    y.axis.loc <- NULL
    if(n > p){
      for(i in 1:n.row){
        y.axis.loc <- c(y.axis.loc, seq(i, n.full, p))
      }
    }
    extra <- n - n.full
    addon <- min(extra, n.row)
    if(addon != 0) y.axis.loc <- c(y.axis.loc, (n.full + 1):(n.full + addon))  
  
  }
  
  for(plot_index in 1:n.plots){
    y <- data[,y.col[plot_index]]
    if(is.null(group.col)){
      plot(y ~ x, xlab = "", ylab = "", xaxt = "n", yaxt = "n", xlim = c(xmin, xmax), ylim = c(ymin, ymax), type = "l")
      legend(legend.position, "", cex = 1 - ((sqrt(plots.page) - 1) / 10), inset = .025, title = legend.titles[plot_index], bty = "n")
    } else {
      group <- data[,group.col]                                                                                                                                                              
      groups <- levels(as.factor(group))
      plot(NULL, xlab = "", ylab = "", xaxt = "n", yaxt = "n", xlim = c(xmin, xmax), ylim = c(ymin, ymax))
      palette(c("black", "red", "blue", "cyan", "magenta", "gray"))
      col <- 0
      for(group_index in groups){
        col <- col + 1  
        lines(y ~ x, subset = group == group_index, xlab = "", ylab = "", xaxt = "n", yaxt = "n", xlim = c(xmin, xmax), ylim = c(ymin, ymax), type = "l", col = col)
      }
      legend(legend.position, groups, lty = 1, col = 1:col, cex = 1 - ((sqrt(plots.page) - 1) / 10), inset = .025, title = legend.titles[plot_index])
    }
    if(plot_index %in% y.axis.loc) {
      if(!is.null(y.at)) {
        axis(2, at = y.at, labels = y.axis.labels, outer = FALSE, las = 1)
      } else {
        if(!is.null(y.axis.labels) & plot_index == y.axis.loc[1]) print("Warning: y.axis.labels are suppressed when y.at is NULL")      
        axis(2, at = pretty(ymin:ymax, n = max(4, 10 - (n.row * 2))), outer = FALSE, las = 1)
      }      
    }
    if(plot_index %in% x.axis.loc) {
      if(!is.null(x.at)) {
        axis(1, at = x.at, labels = x.axis.labels, outer = FALSE, las = 1)
      } else {
        if(!is.null(x.axis.labels) & plot_index == x.axis.loc[1]) print("Warning: x.axis.labels are suppressed when x.at is NULL")
        axis(1, at = pretty(xmin:xmax, n = max(4, 10 - (n.col * 2))), outer = FALSE)
      }
    }
    if(plot_index %in% page.max){
      mtext(main, 3, line = 1.5, outer = TRUE)
      mtext(xlab, 1, line = 3, outer = TRUE)
      mtext(ylab, 2, line = 3, outer = TRUE)
    }
  }
  
  if(!is.null(filename))   dev.off()
  
}

### End MultiPlot() ###





