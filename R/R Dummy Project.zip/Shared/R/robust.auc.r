# Robust AUC
# Author unknown (recieved from Yuanyuan Liang)
# Date unknown
# Louden Consulting Group
###

robust.auc = function(x, y) {
   ncases = length(x)	#number of cases
   nconts = length(y) #number of controls
   sum1 = 0
   for(i in 1:ncases){
      ylessx = length(y[y < x[i]])
      yequalx = length(y[y == x[i]])
      sum1 = sum1 + 1.0*ylessx + 0.5*yequalx
   }
   theta = sum1/(ncases*nconts)
   v1x10 = rep(0,ncases)
   v1y01 = rep(0,nconts)
   for(i in 1:ncases) v1x10[i] = length(y[y < x[i]]) + 0.5*length(y[y == x[i]])
   v1x10 = v1x10/nconts
   for(i in 1:nconts) v1y01[i] = length(x[y[i] < x]) + 0.5*length(x[x == y[i]])
   v1y01 = v1y01/ncases
   s10 = sum((v1x10 - theta)*(v1x10 - theta))/(ncases*(ncases - 1))
   s01 = sum((v1y01 - theta)*(v1y01 - theta))/(nconts*(nconts - 1))
   varauc = s10+s01
   pval = 1 - pnorm((theta - 0.5)/sqrt(varauc))
   output <- c(theta, sqrt(varauc), pval)
   names(output) <- c("Robust AUC", "Standard Error", "P-Value")
   return(output)
}