##############################################################################
# University of Texas Health Science Center at San Antonio
# Department of Epidemiology and Biostatistics
##############################################################################
# Filename: cont_sum_mult.r
# Author: Benjamin Ehler
# Project Name: Shared Functions
# Input: class
#        var
#        class.labels
#        var.name
#        test
#        round
#        panel
#        mult.comp
#        adjust
#        adj.method
# Output: $table: summary table (list element, data.frame)
# Note: $pval: raw pval vector (list element, numeric vector)
#
# Modification History:
# cont_sum Creation - ??? - CL
# cont_sum_mult Added options for multiple comparisons - 10 August 2012 - BE
##############################################################################

cont_sum_mult <- function(class, var, class.labels, var.name, test = "kw", round = 2, panel = 1, mult.comp = TRUE, adjust = TRUE, adj.method = NULL){
  
  if(F){
  class = outcome
  var = data.table1[,40]
  class.labels = levels(outcome)
  var.name = "Risk"
  test = "anova"
  round = 2
  panel = 1
  mult.comp = FALSE
  adjust = TRUE
  adj.method = "scheffe"
  }  
  
  if(!is.factor(class)){ class <- as.factor(class) }

  if(mean(var, na.rm = TRUE) > 1){ round = 1
  } else { round = 2 }

  not.missing <- !is.na(var)
  n <- c(aggregate(not.missing, list(path = class), sum, na.rm = TRUE)[, 2], sum(not.missing))
  mean <- c(round(aggregate(var, list(path = class), mean, na.rm = TRUE)[, 2], round), round(mean(var, na.rm = TRUE), round))
  median <- c(round(aggregate(var, list(path = class), median, na.rm = TRUE)[, 2], round), round(median(var, na.rm = TRUE), round))
  sd <- c(round(aggregate(var, list(path = class), sd, na.rm = TRUE)[, 2], round), round(sd(var, na.rm = TRUE)))
  sd_chk <- c(aggregate(var, list(path = class), sd, na.rm = TRUE)[, 2], sd(var, na.rm = TRUE))
  for(i in 1:length(sd)){
    if(!is.na(sd[i]) & sd[i] == 0 & sd_chk[i] > 0){ sd[i] <- 0.01 }
  }
  q1 <- c(round(aggregate(var, list(path = class), quantile, probs = 0.25, na.rm = TRUE)[, 2], round), round(quantile(var, probs = 0.25, na.rm = TRUE), round))
  q3 <- c(round(aggregate(var, list(path = class), quantile, probs = 0.75, na.rm = TRUE)[, 2], round), round(quantile(var, probs = 0.75, na.rm = TRUE), round))
  min <- c(round(aggregate(var, list(path = class), min, na.rm = TRUE)[, 2], round), round(min(var, na.rm = TRUE), round))
  max <- c(round(aggregate(var, list(path = class), max, na.rm = TRUE)[, 2], round), round(max(var, na.rm = TRUE), round))

#  if(ifelse(is.na(sum(mean/sd < 2)), 2, sum(mean/sd < 2)) > 1){ test <- "kw" }

  # Check that no one group has all observations
  length.check <- 0
  for(i in 1:length(class.labels)){
    if(length(var[class == levels(class)[i]]) == length(var)) length.check <- 1
  }

  if(length.check == 0){
    if(test == "anova"){ pval <- anova(lm(var ~ class))["Pr(>F)"][[1]][1]
    } else if(test == "log"){  pval <- anova(lm(ifelse(var == 0, NA, log(var)) ~ class))["Pr(>F)"][[1]][1]
    } else { pval <- kruskal.test(var ~ class)$p.value }
  } else {
    pval <- NA
  }

#  pval <- anova(lm(log(var + 0.001) ~ class))["Pr(>F)"][[1]][1]

  row.n <- c("N", as.character(n), "")
  row.mean <- c("Mean�SD", paste(mean, "�", sd, sep = ""), "")
  row.median <- c("Median [Q1, Q3]", paste(median, " [", q1, ", ", q3, "]", sep = ""), "")
  row.range <- c("Min, Max", paste(min, ", ", max, sep = ""), "")
  row.blank <- rep("", length(row.n))
  row.name <- c(var.name, rep("", length(row.n) - 2), format.p.val(pval))
  table <- cbind(rbind(row.name, row.n, row.mean, row.median, row.range, row.blank), row = 1:6, panel = panel, test = test)
  bound <- length(class.labels) + 3
  colnames(table)[1:bound] <- c("Label", class.labels, "Total", "Pval")
  rownames(table) <- NULL
   
  n.class <- length(levels(class))
  
  if(mult.comp){
 
    if(is.null(adj.method)){
      if(test == "anova") adj.method <- "Tukey"
      if(test == "kw") adj.method <- "MC for KW"
    }
  
    combos <- combinations(n.class, 2, levels(class))
    combo.pos <- combinations(n.class, 2)
    
    mult.pvals <- NULL
    mult.tests <- NULL 
    level.1.pos <- NULL
    level.2.pos <- NULL
    for(combo_index in 1:dim(combos)[1]){
      level.1 <- combos[combo_index,1]
      level.1.pos[[combo_index]] <- combo.pos[combo_index,1]
      level.2 <- combos[combo_index,2]   
      level.2.pos[[combo_index]] <- combo.pos[combo_index,2]
      # Create new class with only 2 levels #
      part.class <- class
      part.class[!part.class %in% c(level.1, level.2)] <- NA
      part.class <- as.factor(as.character(part.class))
      part.test <- cont_sum(part.class, var, class.labels = levels(part.class), var.name, test, panel)
      mult.pvals[[combo_index]] <- part.test[[2]]
      part.test[[1]] <- as.data.frame(part.test[[1]])
      mult.tests[[combo_index]] <- as.character(part.test[[1]]$test[1])
      if(adjust) mult.tests[[combo_index]] <- paste(mult.tests[[combo_index]], adj.method)
    }   
    
    if(adjust){
 
      if(test == "anova"){
        if(adj.method == "Tukey") { mult.pvals <- TukeyHSD(aov(lm(var ~ class)))$class[,4]
        } else if (adj.method == "scheffe") {
          require(agricolae)
          print("Scheffe Multiple Comparison is not Finished")
          scheffe.test(aov(lm(var ~ class)), class, group = TRUE, main = NULL)
        }
      } else if(test == "kw") {
        require(pgirmess)
        mult.pvals <- rep("> 0.05", n.class)
        mult.pvals[kruskalmc(var ~ class)$dif.com$difference] <- "< 0.05"
      }
 
    }
    
    table <- as.data.frame(table)
    no.form.pvals <- mult.pvals 
    if(test != "kw" | !adjust) for(index in 1:length(mult.pvals)) mult.pvals[index] <- format.p.value(as.numeric(as.character(mult.pvals[index])))
    pval.loc <- grep("Pval", names(table))
    before <- rep("", pval.loc - 1)
    after <- rep("", 2)
    mult.table <- NULL
    for(test_index in 1:length(mult.pvals)){
      mult.row <- c(before, mult.pvals[test_index], after, mult.tests[test_index])
      mult.table <- rbind(mult.table, mult.row)
    }
    for(row_index in 1:dim(mult.table)[1]){
      mult.table[row_index, (c(level.1.pos[[row_index]], level.2.pos[[row_index]]) + 1)] <- "^S={just=c font_face=symbol}�^S={}"
    }
    n.table <- dim(table)[1]
    table <- as.matrix(table)
    table <- rbind(table[1:n.table - 1,], mult.table, table[n.table,])
    n.table <- dim(table)[1]
    rownames(table) <- 1:n.table
    table <- as.data.frame(table)
    table$row <- 1:n.table
    table$panel <- panel
    
    pval <- c(pval, no.form.pvals)  
    
  }
  pval <- as.character(pval)
  return(list(table, pval))
}



### EOF ###