# Smart Round.
# Chris Louden
# Louden Consulting Group
# 17 May 2010
###
# TO DO - VECTORIZE

smart.round <- function(x, min.depth = 2, max.depth = 5){
   if(min.depth >= max.depth){
      print("min.depth >= max.depth in smart.round. Rounding not performed")
      return(x)
   }
   for(i in min.depth:max.depth){
      cut <- 10**(-1*i)/2
      force <- i == max.depth
      if(x >= cut | force){ y <- round(x, i); break() }
   }
   return(y)
}
