# Format P-Value

format.p.value <- format.p.val <- function(pval){
  p <- as.character(rep(NA, length(pval)))
  for(index in 1:length(pval)) {
    if(is.na(pval[index])){ p[index] <- "NA"
    } else if(round(pval[index], 2) == 0.05) { p[index] <- round(pval[index], 3)
    } else if(pval[index] > 0.005){ p[index] <- round(pval[index], 2)
    } else if(pval[index] > 0.0005){ p[index] <- round(pval[index], 3)
    } else { p[index] <- "< 0.001" }
  } 
  return(p)
}


# Aliased as format.p.val for backwards compatability
