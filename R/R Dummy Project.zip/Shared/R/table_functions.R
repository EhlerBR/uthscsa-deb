# Table functions redefined for SAS.table function #

# Table functions
library(binom)
library(multcomp)
#library(gdata)

##########################################################

pastes <- function(x,y) {return(paste(x,y,sep=""))}

##########################################################

spawnDirectory <- function(dirname){
	if(.Platform$OS.type=="unix"){
		temp <- try({temp2 <- system(paste("mkdir",dirname))})
	}
}

##########################################################

simple.multi.table <- function(resultsdir,resultsdir.sas, shared.dir, outfileName,rtfout,inclusion.vector,close.ods=TRUE,orientation="landscape",title="Multitable",operate=0,fontsize=NULL){
	
#	Makes multiple Tables using previously generated Include statements in inclusion vector
#   Generates the SAS code
#   writes to rtfout within directory resultsdir.sas
	
	sasdir <- "C:/Program Files/SASHome/SASFoundation/9.3/"
	
	outfile <- paste(resultsdir,outfileName,".sas",sep="")
		
	outfileSas <- paste(resultsdir.sas,outfileName,".sas",sep="")
	
	rtffile.sas <- paste(resultsdir.sas,rtfout,sep="")
	
	stylepath <- paste(shared.dir,sep="")
		
	temp2 <- ods.start(rtffile.sas,stylepath,orientation=orientation,title=title,fontsize=fontsize)
	write(temp2,file=outfile,append=FALSE)
		
	write(paste(inclusion.vector,"\n"),file=outfile,append=TRUE)	
	
	if(close.ods){	
		
		temp3 <- ods.close()
		write(temp3,file=outfile,append=TRUE)
		
	}
	
	sas.command <- sas.batch(sasdir,outfileSas,operate=0)
	
	return(sas.command)
	
} #END: Simple Table

##########################################################

feature.table.n <- function(resultsdir,resultsdir.sas,shared.dir,table.id,data.matrix,title1="Summary Tables",title3=NULL,columnLabels=NULL,headerStatement=NULL,footnoteJust=NULL,cellwidth=NULL,fontsize=NULL,
                                                                      col.labels = NULL, orientation = "portrait",span.head = NULL, just.matrix = NULL, indent = 0){
	
#   Writes the data matrix to file
#   Generates the SAS code
#   Generates include statement

# resultsdir = path for R to write the sas/csv files
# resultsdir.sas = path for SAS to read the sas/csv files
# table.id = Name for data table within sas & file system
# data.matrix = rectangular data to be in table
# column labels = vector of columnLabels
# headerStatement = sas column statement for nesting columns or selecting subsets of columns
# footnoteJust = 2 column matrix with [footnotes, justifications]
	
	
	sasdir <- "C:/Program Files/SAS/SASFoundation/9.3/"  # Default SAS directory in Windows
	
	# Define output files
	
	outbase <- paste("tableMaker_",table.id,".sas",sep="")  # Where R should write SAS file
	outfile <- paste(resultsdir,outbase,sep="")				# Where SAS should read the SAS file
	datafile <- paste(resultsdir,"tableMaker_",table.id,".csv",sep="")  # Where R should write the data file	
	datafile.sas <- paste(resultsdir.sas,"tableMaker_",table.id,".csv",sep="")  # Where SAS should read the data file
	
	# Export the data to a CSV file
	
	export.2.csv(datafile,data.matrix)

	# Specify path of Style file
	
	stylepath <- paste(shared.dir,sep="")
		
	# Construct SAS import Statement
		
	temp1 <- procImport.simple(datafile.sas,fontsize=fontsize,orientation=orientation)
	
	write(temp1,file=outfile,append=FALSE)
		
	# Add columnLabels
	
	namer <- colnames(data.matrix)
	
	if(!is.null(columnLabels)){
		temp1b <- dataDefine("data1",cbind(namer,columnLabels),col.labels = col.labels, indent = indent)
		write(temp1b,file=outfile,append=TRUE)
	}
	
	
	# Initialize proc report

	
	temp2 <- procReport.start(fontsize=fontsize)
	write(temp2,file=outfile,append=TRUE)
	
	# Specify Proc Report Title
	temp3 <- procReport.title(titletext=title1,titlenumber="1",justification="center",fontsize=fontsize)
	write(temp3,file=outfile,append=TRUE)	
	temp3 <- procReport.title(ifelse(is.null(title3),table.id,title3),fontsize=fontsize)
	write(temp3,file=outfile,append=TRUE)
	
	# Add headerStatement
	if(!is.null(headerStatement)){
		temp3a <- paste("column",headerStatement,";\n")
		write(temp3a,file=outfile,append=TRUE)
	}
	
  font.size <- ifelse(is.null(fontsize), "", paste("fontsize=", as.character(fontsize), "pt", sep = ""))

  # Create spanning headers
  if(!is.null(span.head)){
    column <- "column"
    pos <- 1:length(span.head)
    span.num <- as.numeric(factor(span.head, levels = unique(span.head)))
    # fix for multiple blanks in spanning header #
    counter <- 1
    new.span.num <- 1
    for(index in 2:length(span.num)) {
      if(span.num[index] != span.num[index - 1]) counter <- counter + 1
      new.span.num <- c(new.span.num, counter)
    }
    span.num <- new.span.num
    for(index in unique(span.num)){
      index.pos <- pos[span.num == index]
      heading.vars <- paste("'", span.head[span.num == index][1], "'", sep = "")
      for(pos_index in index.pos){
        heading.vars <- paste(heading.vars, namer[pos_index])
      }
    column <- paste(column, "(", heading.vars, ")", sep = " ")       
    }
    temp3ba <- paste(column, ";\n", sep = "")
    write(temp3ba,file=outfile,append=TRUE)
  }

	# Add columnLabels
	temp3b <- NULL
  if(!is.null(columnLabels)){
	  for(name_index in 1:length(namer)){
  		  cell.width <- ifelse(is.null(cellwidth), "", paste("cellwidth=", as.character(cellwidth[name_index]), "in", sep = ""))
  		  if(name_index == length(namer)){
  		  
  		  } else {
            if(is.null(just.matrix)){
                if(name_index == 1){
         	  	      temp3b.row <- paste("define",namer[name_index],"/display", " STYLE(COLUMN)={asis=on PROTECTSPECIALCHARS=off", cell.width, font.size, "just=l} STYLE(header)={asis=on", cell.width, font.size, "just=c}",";\n")
  	          	} else {
                    temp3b.row <- paste("define",namer[name_index],"/display", " STYLE(COLUMN)={asis=on PROTECTSPECIALCHARS=off", cell.width, font.size, "just=c} STYLE(header)={asis=on", cell.width, font.size, "just=c}",";\n")
	    	        }
            } else {
                temp3b.row <- paste("define",namer[name_index],"/display", " STYLE(COLUMN)={asis=on PROTECTSPECIALCHARS=off", cell.width, font.size, "just=", just.matrix[name_index,2], "} STYLE(header)={asis=on", cell.width, font.size, "just=", just.matrix[name_index,1], "}",";\n")
            }
           
	         temp3b <- c(temp3b, temp3b.row)
        }
    }
		write(temp3b,file=outfile,append=TRUE)
	}
	
	# Add footnotes
	
	if(!is.null(footnoteJust)){
		footers <- procReport.footnote(footnote=footnoteJust[,1],justification=footnoteJust[,2]) # footnote="This is footnote",justification="left"
		write(footers,file=outfile,append=TRUE)
	}
	
	# Exit proc report
	
	temp3 <- procReport.quit()
	write(temp3,file=outfile,append=TRUE)
	
	
	# Contruct include command
	
	
	include.command <- paste("%include ","\"",resultsdir.sas,outbase,"\";",sep="")
	
	return(include.command)
	
} #END: Feature Table.n

##########################################################

dataDefine <- function(dataname,labels,col.labels = NULL, indent = 0){
	
	# Creates labels for variables within the dataname
	# labels = column 1 is the variable name column 2 is the label title
	
	outvec <- rep("",3)

	outvec[1] <- "/* Stard data define */ \n"
	outvec[2] <- paste("data",dataname,"; \n")
	outvec[3] <- paste("   set",dataname,"; \n")
#	outvec[4] <- paste("if indent NE 0 then ", labels[1], " = '   ' || ", labels[1], "; \n")
#  indent.label <- "' ' || "
#  for(index in 1:(indent - 1)){ indent.label <- paste(indent.label, "' ' ||", sep = " ")}
#	outvec[4] <- paste("if indent NE 0 then ", labels[1], " = ", indent.label, labels[1], "; \n", sep = "")
	outvec[4] <- paste("drop indent; \n")
	# in gsubs: '__' was to protect factor names with leading numbers, the '_' was to protect factor names with spaces
  if(!is.null(col.labels)){
    labelstatements <- paste("LABEL",labels[,1],"=",paste("'", col.labels, "'", sep = ""),"; \n")
  } else {  
    labelstatements <- paste("LABEL",labels[,1],"=",paste("'", gsub("_", " ", gsub("__", "", gsub("_1_", "&", gsub("_2_", "@",  
                    gsub("_3_", "#", gsub("_d_", "$", gsub("_4_", "%", gsub("_5_", "!", gsub("_u_", "^", gsub("_s_", "*", 
                    gsub("_o_", "(", gsub("_c_", ")", gsub("_6_", ".", gsub("_7_", "{", gsub("_8_", "}", gsub("_9_", "-", labels[,2])))))))))))))))),"'",sep=""),"; \n")	
	}
  outvec <- c(outvec,labelstatements)	
	outvec <- c(outvec,"run; \n /* Start data define */ \n")
	return(outvec)
	
} #END: dataDefine

##########################################################

convert2char <- function(x){

	for(i in 1:(ncol(x))){

		x[,i] <- as.character(x[,i])

	}

	return(x)

}#END: conver2char

##########################################################

ods.start <- function(docpath,stylepath,style="styles.LPG_SM_LZ",orientation="landscape",title="RSAS_Tab",style.file="LPG2_STYLE_SMALL_MARGIN_LZ.sas",fontsize = NULL){
	
	# generates a char vector to initiate 
	# ods creation of an RTF file 
	# docpath = document file path
	# orientation = landscape/portrait
	# stylefile = file path to 	
	
	outvec <- rep("",5)

	outvec[1] <- paste("%include",paste("\"",stylepath,style.file,"\"",sep=""),";")
	outvec[2] <- "ods escapechar='^';"
  outvec[3] <- ""
	outvec[4] <- paste("options nodate number", ";")
	style <- ifelse(is.null(fontsize), style, "SmallFont")
  outvec[5] <- paste("ods rtf body=",paste("\"",docpath,"\"",sep="")," style=",style ,"bodytitle", "startpage = YES;")	
  height <- ifelse(is.null(fontsize), "", paste(" height = ", fontsize, "pt ", sep = ""))
  outvec[6] <- paste("title1 justify = center", height, "\"",title,"\";",sep="")
	
	
	outvec <- c(outvec,"\n");
	
	return(outvec)
	
} # END: ods.start
  
##########################################################  	
	
ods.close <- function(){
	
	# Returns the closure for the ods statment
	
	outvec <- rep("",2)

	outvec[1]  <-"ods rtf close;"

	outvec[2]  <-"quit;"
	
	return(outvec)
	
} #END: ods.close
	
##########################################################

procReport.start <- function(dataname="data1",panels=FALSE,fontsize=NULL){

	# Contruct the proc report header statement
	# dataname = dataset name

	outvec <- rep("",10)

	outvec[1] <- "proc report" 
	outvec[2]	<-	paste("data=",dataname,sep=" ") 
	outvec[3]	<-		"headline"
	outvec[4]	<-		"headskip" 
	outvec[5]	<-		"missing" 
	outvec[6]	<-		"nowd" 
	outvec[7]	<-		"split='@'" 
	outvec[8]	<-		"spacing=0 ls=200"
   outvec[9]  <-     "style(header column)=[protectspecialchars=off background=white]"
   outvec[10]  <-     "Style(report)={borderwidth=1pt cellspacing=0pt cellpadding=2pt vjust=bottom}" 
   if(!is.null(fontsize)) {
     outvec[11]  <-      paste("STYLE(HEADER)={ PROTECTSPECIALCHARS=off fontsize=", fontsize, "pt just = c };", sep = "")
   } else {
     outvec[11]  <-      "STYLE(HEADER)={ PROTECTSPECIALCHARS=off just = c };"
   }         
   outvec2     <-    ifelse(panels, "where panel ne 0;","")

	outvec <- paste(outvec,collapse="\n")
	
	outvec <- c("/* BEGIN: procReport.start */","\n",outvec,outvec2,"/* END: procReport.start */","\n")
	
	return(outvec)
	
	} #END: procReport.start	

##########################################################

procReport.title <- function(titletext="Data1",titlenumber="3",justification="center",fontsize = NULL){
	
	# Constructs the title statement
	
	start <- paste("title",titlenumber,sep="")
	
	just <- paste("justify=",justification,sep="")
	
	size <- ifelse(is.null(fontsize), "", paste("height = ",fontsize,"pt",sep=""))
	
	titletext <- paste("\"",titletext,"\"",sep="")
	
	outvec <- paste(start,just,size,titletext,";",sep=" ")
	
	outvec <- c("/* BEGIN: procReport.title */","\n",outvec,"/* END: procReport.title */","\n");
	
	return(outvec)
	
	} #END: procReport.title

##########################################################

procReport.footnote <- function(footnote="This is footnote",justification="left"){
	
	# Generate a footnote for procReport
	#  footnote1 j=lFeft "^{super 1}F Test";
	
	nfoot <- length(footnote)
	njust <- length(justification)
	
	feet <- paste("\"",footnote,"\"",sep="")
	
	justs <- rep(justification,nfoot/njust)
	
	starts <- paste("footnote",1:nfoot," ",sep="")
	
	outvec <- paste(starts,"j=",justs,' \"',footnote,'\" ;',sep="")
	
	outvec <- c(outvec,"\n");
	
	return(outvec)
	
	}	# END procReport.footnote
	
##########################################################
	
export.2.csv <- function(filename,data){
	
	# Simplifies the export to a csv file
	# data = a CHARACTER matrix, 1st row are column names [NOT?]

	maxes <- apply(nchar(data),2,max)

	ncols <- length(maxes)

	datarow1 <- rep("",ncols)

	for(i in 1:ncols){
		datarow1[i] <- paste(rep("a",maxes[i]),collapse="")

	} # loop over i

	cnames <- colnames(data)

	data <- rbind(datarow1,data)

	colnames(data) <- cnames
	
	write.table(data,filename,quote=TRUE,row.names=FALSE,col.names=TRUE,sep=",")
	
	return(NULL)
	
	} #END: export.2.csv	

##########################################################

procReport.quit <- function(){

	# Returns the closure for the proc report statment
	
	outvec <- rep("",3)
	
	outvec[1] <- "run;"
	outvec[2]  <- "footnote;"
	
	outvec[3]  <-"title;"
	
	return(outvec)

}#END: procReport.quit

##########################################################
	
sas.batch <- function(sasdir,sasprog,sas.options="",operate=0){

#: C:\SAS\SAS.EXE -SYSIN C:\SAS\PROGRAMS\PROG1.SAS -CONFIG C:\SAS\SASV9.CFG

	command1 <- paste("\"",sasdir,"sas.exe\" -SYSIN",sep="")

	comand1 <- gsub("/","\\",command1)

	command.config <- paste("-CONFIG",paste("\"",sasdir,"SASV9.CFG\"",sep=""))

	comand.config <- gsub("/","\\",command.config)

	logfile <- paste("-Log \"",gsub("\\.sas$","\\.log",sasprog),"\"",sep="")

	lstfile <- paste("-Print \"",gsub("\\.sas$","\\.lst",sasprog),"\"",sep="")

	sasprog <- paste("\"",sasprog,"\"",sep="")

	command.full <- paste(command1,sasprog,command.config,lstfile,logfile,sas.options,collapse=" ")

	if(operate>0) {system(command.full)}

	return(command.full)
	
} #END: sas.batch

##########################################################
	
procImport.simple <- function(datafile,dataset="data1",fontsize = NULL,orientation = "portrait"){

	#imports the data into SAS
	#from CSV format

	outvec <- rep("",11)

  outvec[1] <- ""
  outvec[2] <- ""
  outvec[3] <- ""

#   outvec[3] <- paste("ods pdf startpage=now; options orientation=", orientation, ";", sep = "")

  	outvec[4] <- "PROC IMPORT" 
	outvec[5] <- paste("OUT=WORK.",dataset,sep="") 
	outvec[6] <- paste("DATAFILE=", "\"",datafile,"\"",sep="")           
	outvec[7] <- "DBMS=CSV REPLACE; GUESSINGROWS = 500;"
      outvec[8] <- "GETNAMES=YES;"
      outvec[9] <- "DATAROW=2;"
	outvec[10] <- "RUN;"

	# Remove the 1st row of character lengths
	
	outvec[11] <- paste("data work.",dataset,";",sep="")
	outvec[12] <- paste("set work.",dataset,";",sep="")
	outvec[13] <- "if _n_ = 1 then delete;"

	outvec <- c(outvec,"run;\n");

	return(outvec)

} #END: procImport.simple



