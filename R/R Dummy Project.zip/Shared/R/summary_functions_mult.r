#
#  Summarize Data Set
#

summarize.data.frame_mult <- function(data., outcome., columns. = NULL, names. = names(data.), levels. = levels(outcome.), output. = FALSE, filename. = "summary.csv", 
                                         cont_test = "kw", cat_test = "chisq", row.perc = FALSE, mult.comp = TRUE, adjust = TRUE, cat.adj.method = "bonferroni", cont.adj.method = NULL){
 
   counter <- 0
   table <- NULL
   pvalues <- NULL
   if(is.null(columns.)) columns. <- 1:dim(data.)[2]
   for(column in columns.){
      print(column)
      counter <- counter + 1
      if(is.numeric(data.[, column])){
         temp <- cont_sum_mult(outcome.[!is.na(data.[, column])], data.[!is.na(data.[, column]), column], levels., names.[column], panel = counter, test = cont_test,
                                   mult.comp = mult.comp, adjust = adjust, adj.method = cont.adj.method)
      } else {
         temp <- cat_sum_mult(outcome.[!is.na(data.[, column])], data.[!is.na(data.[, column]), column], levels., names.[column], panel = counter, test = cat_test, 
                                   row.perc = row.perc, mult.comp = mult.comp, adjust = adjust, adj.method = cat.adj.method)
      }
      table <- rbind(table, temp[[1]])
      pvalues <- rbind(pvalues, temp[[2]])
   }                           

   if(output.) write.csv(table, filename., row.names = FALSE)
   return(list(table = table, pvalues = pvalues))
}



### EOF ###

if(F){
data. = data.table1
outcome. = outcome
columns. = columns
names. = names(data.table1)
levels. = levels(outcome)
output = TRUE
filename. = file
cont_test = cont_test
cat_test = "chisq"
row.perc = FALSE
mult.comp = mult.comp
adjust = adjust
cat.adj.method = cat.adj.method
cont.adj.method = "Tukey"     
}                                       