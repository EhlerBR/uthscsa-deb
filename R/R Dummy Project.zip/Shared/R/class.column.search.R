class.column.search <- function(data, class = c("factor", "numeric", "character", "integer")) {
  class <- class[1]
  vector <- NULL
  for(col.index in 1:ncol(data)) {
    if(class == "factor" & is.factor(data[, col.index])) {
        vector <- c(vector, col.index)
    } else if(class == "numeric" & is.numeric(data[, col.index])) {
        vector <- c(vector, col.index)
    } else if(class == "character" & is.character(data[, col.index])) {
        vector <- c(vector, col.index)
    } else if(class == "integer" & is.integer(data[, col.index])) {
        vector <- c(vector, col.index)
    }
  }
  return(vector)
}
