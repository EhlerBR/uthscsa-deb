##############################################################################
# University of Texas Health Science Center at San Antonio
# Department of Epidemiology and Biostatistics
##############################################################################
# Filename: cat_sum_mult.r
# Author: Benjamin Ehler
# Project Name: Shared Functions
# Input: class
#        var
#        class.labels
#        var.name
#        test
#        round
#        panel
#        mult.comp
#        adjust
#        adj.method
# Output: $table: summary table (list element, data.frame)
# Note: $pval: raw pval vector (list element, numeric vector)
#
# Modification History:
# cat_sum Creation - ??? - CL
# cat_sum_mult Added options for multiple comparisons - 10 August 2012 - BE
##############################################################################

library(gtools)
cat_sum_mult <- function(class, var, class.labels, var.name, var.label = levels(var), test = "chisq", panel = 1, row.perc = FALSE, round = 2, mult.comp = TRUE, adjust = TRUE, adj.method = "bonferroni", ...){

  if(!is.factor(class)){ class <- as.factor(class) }
  if(!is.factor(var)){ var <- as.factor(var) }
  n.class <- length(levels(class)); n.var.class <- length(levels(var))
  contingency <- table(var, class);

  if(sum(contingency < 5)){ test <- "fisher" }
  if(n.class > 3 | n.var.class > 3){ simulate.p.value <- TRUE } else { simulate.p.value <- FALSE }

  if(test == "chisq"){ pval <- chisq.test(contingency)$p.value
  } else { pval <- fisher.test(contingency, simulate.p.value = simulate.p.value)$p.value
  }

# Changed Total to show total of var regardless of missing status of class #
#  rowsums <- apply(contingency, 1, sum) # commented out 17 Aug 2012
  rowsums <- table(var) # added 17 Aug 2012
  colsums <- c(apply(contingency, 2, sum), sum(contingency))
  colsums[length(colsums)] <- sum(rowsums)  # added 17 Aug 2012

  if(row.perc){
    percents <- round(100*matrix(contingency, ncol = n.class)/matrix(rep(rowsums, n.class), nrow = n.var.class, byrow = FALSE), round)
    contingency <- rbind(cbind(matrix(paste(contingency, " (", percents, ")", sep = ""), ncol = n.class), rowsums), as.character(colsums))
  } else {
    percents <- round(100*cbind(matrix(contingency, ncol = n.class)/matrix(rep(colsums[1:n.class], n.var.class), ncol = n.class, byrow = TRUE), rowsums/colsums[(n.class + 1)]), round)
    contingency <- rbind(matrix(paste(cbind(contingency, rowsums), " (", percents, ")", sep = ""), ncol = n.class + 1), as.character(colsums))
  }

  var.labels <- c(var.name, var.label, "Total")
  row.blank <- rep("", n.class + 3)

  contingency <- cbind(matrix(var.labels, ncol = 1), rbind(row.blank[1:(n.class + 1)], contingency))

  col.pval <- c(format.p.val(pval), rep("", n.var.class + 1))
  contingency <- rbind(cbind(contingency, col.pval), row.blank)

  class.labels <- c("Label", class.labels, "Total", "Pval")
  colnames(contingency) <- class.labels; rownames(contingency) <- NULL
  contingency <- as.data.frame(cbind(contingency, row = 1:(n.var.class + 3), panel = panel, test = test))

  if(mult.comp){           
  
    combos <- combinations(n.class, 2, levels(class))
    combo.pos <- combinations(n.class, 2)
    mult.pvals <- NULL
    mult.tests <- NULL 
    level.1.pos <- NULL
    level.2.pos <- NULL
    for(combo_index in 1:dim(combos)[1]){
      level.1 <- combos[combo_index,1]
      level.1.pos[[combo_index]] <- combo.pos[combo_index,1]
      level.2 <- combos[combo_index,2]   
      level.2.pos[[combo_index]] <- combo.pos[combo_index,2]
      # Create new class with only 2 levels #
      part.class <- class
      part.class[!part.class %in% c(level.1, level.2)] <- NA
      part.class <- as.factor(as.character(part.class))
      part.test <- cat_sum(part.class, var, class.labels = levels(part.class), var.name, var.label, test, panel, row.perc)
      mult.pvals[[combo_index]] <- part.test[[2]]
      mult.tests[[combo_index]] <- as.character(part.test[[1]]$test[1])
      if(adjust) mult.tests[[combo_index]] <- paste(mult.tests[[combo_index]], adj.method)
    }
    if(adjust) mult.pvals <- p.adjust(mult.pvals, method = adj.method, n = length(mult.pvals))
    no.form.pvals <- mult.pvals 
    for(index in 1:length(mult.pvals)) mult.pvals[index] <- format.p.value(as.numeric(as.character(mult.pvals[index])))
    pval.loc <- grep("Pval", names(contingency))
    before <- rep("", pval.loc - 1)
    after <- rep("", 2)
    mult.table <- NULL
    for(test_index in 1:length(mult.pvals)){
      mult.row <- c(before, mult.pvals[test_index], after, mult.tests[test_index])
      mult.table <- rbind(mult.table, mult.row)
    }
    for(row_index in 1:dim(mult.table)[1]){
      mult.table[row_index, (c(level.1.pos[[row_index]], level.2.pos[[row_index]]) + 1)] <- "^S={just=c font_face=symbol}�^S={}"
    }
    n.table <- dim(contingency)[1]
    contingency <- as.matrix(contingency)
    contingency <- rbind(contingency[1:n.table - 1,], mult.table, contingency[n.table,])
    n.table <- dim(contingency)[1]
    rownames(contingency) <- 1:n.table
    contingency <- as.data.frame(contingency)
    contingency$row <- 1:n.table
    contingency$panel <- panel
    
    pval <- c(pval, no.form.pvals)
  }
  pval <- as.character(pval) 
  return(list(contingency, pval))
}



if(F){
data.table1 <- data
class <- data.table1$named.group
var <- data.table1$Gender
class.labels <- levels(class)
var.name <- "Gender"
var.label <- levels(var)
test <- "chisq"
panel <- 1
row.perc <- FALSE
mult.comp <- FALSE
adjust <- TRUE
adj.method = "bonferroni"
}






### EOF ###