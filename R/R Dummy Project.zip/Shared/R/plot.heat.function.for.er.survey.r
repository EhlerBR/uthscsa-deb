
# from: 'http://stackoverflow.com/questions/1260965/developing-geographic-thematic-maps-with-r'

plot.heat.map <- function(counties.map,state.map,z,main = NULL, legend.title=NULL,breaks=NULL,reverse=FALSE,cex.legend=1,bw=.2,col.vec=NULL,plot.legend=TRUE,xlim = NULL, ylim = NULL, trim.legend = FALSE, discrete = FALSE, cex.main = NULL) {

  ##Break down the value variable
  if (is.null(breaks)) {
    breaks=
      seq(
          floor(min(counties.map@data[,z],na.rm=TRUE)*10)/10,
          ceiling(max(counties.map@data[,z],na.rm=TRUE)*10)/10,
          .1)
  }
  counties.map@data$zCat <- cut(counties.map@data[,z],breaks,include.lowest=TRUE)
  cutpoints <- levels(counties.map@data$zCat)
  if (is.null(col.vec)) col.vec <- heat.colors(length(levels(counties.map@data$zCat)))
  if (reverse) {
    cutpointsColors <- rev(col.vec)
  } else {
    cutpointsColors <- col.vec
  }
  levels(counties.map@data$zCat) <- cutpointsColors
  plot(counties.map,border=gray(.8), lwd=bw,axes = FALSE, las = 1,main=main,col=as.character(counties.map@data$zCat),xlim = xlim, ylim = ylim, cex.main = cex.main)
  if (!is.null(state.map)) {
    plot(state.map,main=main,add=TRUE,lwd=1, cex.main = cex.main)
  }
  
  mtext(main, side = 3, line = 1, font = 2, cex = cex.main, outer = F)
  ##with(counties.map.c,text(x,y,name,cex=0.75))
  if(discrete){
  if(trim.legend){
    cut.for.legend <- substr(cutpoints,nchar(cutpoints) - 1, nchar(cutpoints) - 1)
    cut.for.legend[length(cut.for.legend)] <- paste(as.numeric(as.character(cut.for.legend[length(cut.for.legend) - 1])) + 1, "+", sep = "")
    gsub("-Inf", 0, cut.for.legend)
  } else {
    cut.for.legend <- cutpoints
      cut.for.legend <- gsub("\\[-Inf,0]", "0", cut.for.legend)
    cut.for.legend <- gsub("\\, Inf]", "",cut.for.legend)
    cut.for.legend[length(cut.for.legend)] <- gsub("\\(", ">", cut.for.legend[length(cut.for.legend)])
    cut.for.legend <- gsub("\\(", "",cut.for.legend)
    cut.for.legend <- gsub("\\]", "",cut.for.legend)
    cut.for.legend <- gsub("\\,", "-",cut.for.legend)
    for(index in 2:(length(cut.for.legend)-1)){
      substr(cut.for.legend[index], 1, cpos(cut.for.legend[index], "-") - 1) <- as.character(as.numeric(substr(cut.for.legend[index], 1, cpos(cut.for.legend[index], "-") - 1)) + 1)
    }
  }
  } else {
    cut.for.legend <- cutpoints
  }
  if (plot.legend) legend("topleft", inset = 0.01, cut.for.legend, fill = cutpointsColors,bty="o",title=legend.title,cex=cex.legend, bg = "white")
  ##title("Cartogram")
}

