### Pepe's power analysis
# Chris Louden
# 17 May 2011
# Louden Consulting Group
###
# NOTE: ONLY PHASE 2 IMPLEMENTED
# RETURNS THE NUMBER OF DISEASED AND NON-DISEASED

pepe.power <- function(phase = 2, se.0 = 0.8, sp.0 = 0.8, se.1 = NULL, sp.1 = NULL, alpha = 0.05, power = 0.8){
   beta <- 1 - power
   beta.star <- 1 - sqrt(1 - beta)
   alpha.star <- 1 - sqrt(1 - alpha)
   z.alpha <- qnorm(1 - alpha.star)
   z.beta <- qnorm(1 - beta.star)
   if(phase == 2){
      n.case <- ceiling((z.alpha*sqrt(se.0*(1 - se.0)) + z.beta*sqrt(se.1*(1 - se.1)))**2/(se.1 - se.0)**2)
      n.control <- ceiling((z.alpha*sqrt(sp.0*(1 - sp.0)) + z.beta*sqrt(sp.1*(1 - sp.1)))**2/(sp.1 - sp.0)**2)
      n <- c(n.case, n.control)
      names(n) <- c("Cases", "Controls")
      return(n)
   }
}



pepe.power(se.0 = 0.5, sp.0 = 0.5, se.1 = 0.80, sp.1 = 0.80)