
unique.data.analysis <- function(data, unique.id) {
  id <- data[[unique.id]]
  id <- as.character(id)
  temp.table <- table(id)
  dups <- names(temp.table)[temp.table > 1]
  if(length(dups) == 0)
    print(paste("No Duplicated Values in ", unique.id, sep = ""))
  else {
    unique.data <- data[!id %in% as.character(dups), ]
    unique.data <- unique.data[order(unique.data[[unique.id]]), ]
    dups.data <- data[id %in% c(dups), ]
    dups.data <- dups.data[order(dups.data[[unique.id]]), ]    
    return(list("no.duplicates.data" = unique.data, "duplicates.data" = dups.data))
  }
}

### EOF ###

### TO TEST ###
if(FALSE) {

data <- data.frame(id = c(1:90,2,4,4,4,60,34,34,90,90,90), grp = sample(c("A", "B", "C"), 100, TRUE), value = runif(100))
unique.id <- "id"
new.data <- unique.data.analysis(data, unique.id)
new.data
#new.data <- rbind(new.data$no.duplicates.data, new.data$duplicates.data)
#data <- data[order(as.character(data$id)), ]
#new.data <- new.data[order(as.character(new.data$id)), ]

data <- data.frame(id = c(1:100), grp = sample(c("A", "B", "C"), 100, TRUE), value = runif(100))
unique.id <- "id"
unique.data.analysis(data, unique.id)

}


