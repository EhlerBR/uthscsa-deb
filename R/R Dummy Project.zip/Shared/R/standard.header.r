##############################################################################
# University of Texas Health Science Center at San Antonio
# Department of Epidemiology and Biostatistics
##############################################################################
# Filename: .r
# Author: Benjamin Ehler
# Project Name: Shared Functions
# Input:
# Output:
# Note:
#
# Modification History:
# v 1.0 Creation
##############################################################################