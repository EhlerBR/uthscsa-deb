# Filename: survey.summary.r ###
# Author: Benjamin Ehler
# Date: 19 Aug 2013

###########################################################################

# data:                    data.frame that contains the question response variables #
#                          In data, if there is a question with multiple options, each variable name should be represented with a "_#" following the Question number #
#                          e.g. Q13_1, Q13_2, Q13_3 # 
# outcome:                 factor (coerced if not) vector used to separate the data (used with summarize.data.frame) #
#
# FOR THE FOLLOWING, IF THERE IS A NUMERIC VARIABLE, INCLUDE IT IN question.labels, BUT NOT IN raw.answers OR answer.labels #
# question.labels:         list containing the questions (with names equal to the names of the variables in the dataset) #
# DO NOT INCLUDE THE MISSING LABELS IN raw.answers OR answer.labels; THEY WILL BE ADDRESSED SEPARATELY #
# raw.answers:             list containing the raw answers as they appear in the dataset (with names equal to the names of the variables in the dataset) #
# answer.labels:           list containing the answer options (with names equal to the names of the variables in the dataset) #
#                          These answer.labels must align EXACTLY with the raw.answers
# missing.label:           How are the missing entries labeled in the dataset (e.g. NA, "Missing", "999")
#                          Missing values in numeric variables should always be labeled NA
# return.dataset:          Logical to determine if the revised dataset should be included in the return list

###########################################################################

survey.summary <- function(data, 
                           outcome, 
                           question.labels, 
                           raw.answers, 
                           answer.labels = raw.answers, 
                           missing.label = NA, 
                           return.dataset = TRUE,
                           write.SAS.table = FALSE,
                           ...) { 

# CHECK FOR ERRORS IN FUNCTION SET UP #
  if(!identical(sort(names(raw.answers)), sort(names(answer.labels))))
    stop("names of raw.answers and answer.labels do not match")
  for(q_index in names(raw.answers)) {
    if(lapply(raw.answers, length)[[q_index]] != lapply(answer.labels, length)[[q_index]]) 
      stop(paste("length of raw.answers and answer.labels for", q_index, "are unequal"))
    if("Missing" %in% answer.labels[[q_index]])
      stop("answer.labels cannot contain the label, 'Missing'")
    if(!is.na(missing.label) & missing.label %in% raw.answers[[q_index]])
      stop(paste("answer.labels for", q_index, "cannot contain the missing.label"))
    if("Missing" %in% answer.labels[[q_index]])
      stop(paste("answer.labels for ", q_index, "cannot contain the label, 'Missing'"))
    if(regexpr("_", q_index) > 0) {
      if(length(answer.labels[[q_index]]) > 1) {
        stop("For multiple response answers, there should only be 1 raw.answer and 1 answer.label (equal to the label of the question response)")
      }
    } else {
      if(sum(!unique(data[[q_index]]) %in% c(raw.answers[[q_index]], missing.label)))  # works even with missing.label NA
        stop(paste("Entry/Entries: '", paste(unique(data[[q_index]])[!unique(data[[q_index]]) %in% c(raw.answers[[q_index]], missing.label)], collapse = "', '"), 
                     "' in the variable, ", q_index, ", in the datset does/do not appear in the raw.answers list", sep = ""))      
    }    
  }
    
  work.data <- data
  
  if(class(outcome) != "factor")
    outcome <- as.factor(as.character(outcome))
  
  for(col_index in 1:dim(work.data)[2]) {
    work.data[, col_index] <- as.character(work.data[, col_index])
    work.data[, col_index] <- gsub("^ *", "", gsub(" *$", "", work.data[, col_index])) # Gets rid of blanks before or after data #
  }
  
# Set uniform Missing label to those that are NA or meet the missing critereon #
  for(colname_index in names(answer.labels)) {
    if(is.na(missing.label)) {   
      work.data[[colname_index]][is.na(work.data[[colname_index]])] <- "Missing"  
    } else {
      work.data[[colname_index]][work.data[[colname_index]] == missing.label] <- "Missing" 
    }
  }
  
  panel.list <- as.list(NULL)
  type.list <- as.list(NULL)
  factored.data <- work.data
  temp.panel <- 1
  for(q_index in names(question.labels)) {
    if(q_index %in% names(answer.labels)) {
      factored.data[[q_index]] <- factor(work.data[[q_index]], levels = c(raw.answers[[q_index]], "Missing"), labels = c(answer.labels[[q_index]], "Missing"))
      panel.list[[q_index]] <- temp.panel  
      type.list[[q_index]] <- "Single Factor"                       
      temp.panel <- temp.panel + 1    
    } else {
      if(length(grep(paste(q_index, "_", sep = ""), names(answer.labels))) > 0) {
        grp.cols <- grep(paste(q_index, "_", sep = ""), names(work.data))      
        for(grp_col_index in names(work.data)[grp.cols]) {
          work.data[[grp_col_index]][work.data[[grp_col_index]] != raw.answers[[grp_col_index]][[1]]] <- "DELETE_ROW"
          factored.data[[grp_col_index]] <- factor(work.data[[grp_col_index]], levels = c(raw.answers[[grp_col_index]], "DELETE_ROW", "Missing"), labels = c(answer.labels[[grp_col_index]], "DELETE_ROW", "Missing"))
          panel.list[[grp_col_index]] <- temp.panel        
          type.list[[grp_col_index]] <- "Multiple Factor"         
        }
        for(row_index in 1:dim(factored.data)[1]) {
          factored.data[[paste(q_index, "_Missing", sep = "")]][row_index] <- ifelse(sum(factored.data[row_index, names(work.data)[grp.cols]] != "DELETE_ROW") > 0, "A.TOTAL", "Missing")       
          panel.list[[paste(q_index, "_Missing", sep = "")]] <- temp.panel        
          type.list[[paste(q_index, "_Missing", sep = "")]] <- "Multiple Factor"                 
        }
        factored.data[[paste(q_index, "_Missing", sep = "")]] <- factor(factored.data[[paste(q_index, "_Missing", sep = "")]], levels = c("A.TOTAL", "Missing"))
        temp.panel <- temp.panel + 1      
      } else {
        factored.data[[q_index]] <- as.numeric(work.data[[q_index]])
        panel.list[[q_index]] <- temp.panel
        type.list[[q_index]] <- "Numeric"               
        temp.panel <- temp.panel + 1      
      }
    }
  }
  
  summ.mat <- NULL
  first.mult <- TRUE
  for(q_index in names(type.list)) {
    if(type.list[[q_index]] == "Numeric") {
      temp.summ <- cont_sum(class = outcome, var = factored.data[[q_index]], class.labels = levels(outcome), var.name = question.labels[[q_index]], round = 2, panel = panel.list[[q_index]])[[1]]
      first.mult <- TRUE    
    } else if(type.list[[q_index]] == "Single Factor") {
      temp.summ.full.miss <- cat_sum(class = outcome, var = factored.data[[q_index]], class.labels = levels(outcome), var.name = question.labels[[q_index]], var.label = levels(factored.data[[q_index]]), panel = panel.list[[q_index]], round = 2)[[1]]
      for(col_index in 1:dim(temp.summ)[2])
        temp.summ.full.miss[, col_index] <- as.character(temp.summ.full.miss[, col_index])
      
      temp.var <- factored.data[[q_index]]
      temp.var[temp.var == "Missing"] <- NA
      temp.summ.empty.miss <- cat_sum(class = outcome, var = temp.var, class.labels = levels(outcome), var.name = question.labels[[q_index]], var.label = levels(temp.var), panel = panel.list[[q_index]], round = 2)[[1]]    
      for(col_index in 1:dim(temp.summ.empty.miss)[2])
        temp.summ.empty.miss[, col_index] <- as.character(temp.summ.empty.miss[, col_index])
  
      temp.var <- factor(temp.var, levels = levels(temp.var)[levels(temp.var) != "Missing"])
      temp.summ.na.miss <- cat_sum(class = outcome, var = temp.var, class.labels = levels(outcome), var.name = question.labels[[q_index]], var.label = levels(temp.var), panel = panel.list[[q_index]], round = 2)[[1]]
      temp.summ.na.miss.test <- as.character(temp.summ.na.miss$test[1])
      temp.summ.na.miss.pval <- as.character(temp.summ.na.miss$Pval[1])      
      
      temp.summ <- temp.summ.empty.miss
      temp.summ[temp.summ$Label == "Missing", ] <- temp.summ.full.miss[temp.summ.full.miss$Label == "Missing", ]
      temp.summ$Pval[1] <- temp.summ.na.miss.pval
      temp.summ$test <- temp.summ.na.miss.test
      
      temp.Missing.Row <- list("line" = temp.summ[temp.summ$Label == "Missing", (1:(dim(temp.summ)[2] - 4))], "row" = as.character(temp.summ$row[temp.summ$Label == "Missing"]))
      temp.Total.Row <- list("line" = temp.summ[temp.summ$Label == "Total", (1:(dim(temp.summ)[2] - 4))], "row" = as.character(temp.summ$row[temp.summ$Label == "Total"]))
      temp.summ[temp.summ$row == temp.Missing.Row[["row"]], (1:(dim(temp.summ)[2] - 4))] <- temp.Total.Row[["line"]]
      temp.summ[temp.summ$row == temp.Total.Row[["row"]], (1:(dim(temp.summ)[2] - 4))] <- temp.Missing.Row[["line"]] 

      first.mult <- TRUE          
          
    } else {  # "Multiple Factor" #
      temp.var <- factored.data[[q_index]]
      if(!length(grep("_Missing", q_index))) {  # If it is not the missing selection, set to NA where all variables are missing
        temp.var[factored.data[[paste(substr(q_index, 1, regexpr("_", q_index)), "Missing", sep = "")]] == "Missing"] <- NA
      }
      temp.summ <- cat_sum(class = outcome, var = temp.var, class.labels = levels(outcome), var.name = q_index, var.label = levels(temp.var), panel = panel.list[[q_index]], round = 2)[[1]]     
      temp.summ <- temp.summ[!temp.summ$Label %in% c("Total"), ]    
      temp.summ <- temp.summ[temp.summ$row != 1, ]              
      if(length(grep("_Missing", q_index))) {
        for(col_index in 2:(dim(temp.summ)[2] - 4)) {
          temp.summ[, col_index] <- as.character(temp.summ[, col_index])
          temp.summ[temp.summ$Label == "A.TOTAL", col_index] <- substr(temp.summ[temp.summ$Label == "A.TOTAL", col_index], 1, (regexpr(" \\(", temp.summ[temp.summ$Label == "A.TOTAL", col_index])[[1]] - 1))      
        }
        temp.summ$Label[temp.summ$Label == "A.TOTAL"] <- "Total"
        first.mult <- TRUE
      } else {      
        if(first.mult) {
          temp.label.row <- as.data.frame(matrix("", nrow = 1, ncol = dim(temp.summ)[2]), stringsAsFactors = FALSE)
          names(temp.label.row) <- names(temp.summ)
          temp.label.row$Label <- question.labels[[substr(q_index, 1, (regexpr("_", q_index) - 1))]]
          temp.label.row$row <- 1
          temp.label.row$panel <- panel.list[[q_index]]          
          temp.summ <- rbind(temp.label.row, temp.summ)
        }
        temp.summ <- temp.summ[!temp.summ$Label %in% c("", "Missing", "DELETE_ROW"), ]    
        first.mult <- FALSE
      }
    }
    
    temp.summ <- as.data.frame(temp.summ, stringsAsFactors = FALSE)  
    for(col_index in 1:dim(temp.summ)[2])
      temp.summ[, col_index] <- as.character(temp.summ[, col_index])
    for(row_index in 1:dim(temp.summ)[1]) {
      temp.summ$row[row_index] <- row_index
    }
    
    summ.mat <- rbind(summ.mat, temp.summ)
  }  
  
  summ.df <- as.data.frame(summ.mat, stringsAsFactors = FALSE)  
  for(row_index in 1:(dim(summ.df)[1] - 1)) {
    if(summ.df$test[row_index] == "")
      summ.df$test[row_index] <- summ.df$test[row_index + 1]
  }
  
  if(write.SAS.table) {   
    SAS.table(summ.df, filename = "Summary", table.name = "summ_table_x", title3 = "Summary", summ.df = TRUE, orientation = "landscape", ...)
  }  
  
  if(return.dataset) {
    return(list("data" = factored.data, "summary" = summ.df))
  } else {
    return(summ.df)
  }
   
}

### EOF ###