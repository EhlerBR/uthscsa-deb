date.2yr <- function(x){
  if(!is.na(x)){
    x <- paste(substr(x, 1,(nchar(x) - 4)), substr(x, (nchar(x) - 1), nchar(x)), sep = "")
    x <- as.Date(x, "%m/%d/%y")
  }
  return(x)
}

