# Filename:     validate.data.r ###
# Project Name: Validation_Review_Summarize_Functions
# Author:       Ben Ehler
# Date:         21 February 2013
# Input:        raw data & data dictionary
# Output:       csv & pdf

####################################################################################################################################################
### THE PURPOSE OF THIS FUNCTION IS TO TAKE THE RAW DATA AND A DATA DICTIONARY AND VALIDATE THAT THE DATA/DATA DICTIONARY MATCH                  ###
### THE ERRORS ARE THEN CHECKED AND OUTPUT                                                                                                       ###
####################################################################################################################################################

####################################################################################################################################################
### EXPLANATION OF INPUT/OPTIONS:                                                                                                                ###
### raw.data.file: Name of raw data csv (with extension)                                                                                         ###
### data.dictionary: Name of data dictionary csv (with extension)                                                                                ###
### data.loc: directory location for input                                                                                                       ###
### output.loc: directory location for output                                                                                                    ###
### summarize.by.group: use summarize.data.frame with grouping variable                                                                          ###                     
### filename: Name of pdf and csv files that are created from function; default is 'Variable Summary'                                            ###
### input.date.format: R date format for input of all date variables; If NULL, format is 'guessed' by R function                                 ###
####################################################################################################################################################

require(lubridate)

validate.data.2 <- function(raw.data.file, data.dictionary.file, data.loc=data.dir, output.loc=documents.dir, summarize.by.group = TRUE, filename = NULL, input.date.format = NULL, stylepath = "shared"){
 
#################### SET UP FOLDER FOR OUTPUT (ATTEMPT) ####################
  date <- format(Sys.time(), "%d %b %Y")

  results.dir <- paste(output.loc, "Data Validation (", date, ")/", sep = "")
  suppressWarnings(dir.create(results.dir))  # Warning occurs when directory already exists.  Still creates files
      
  raw.data <- read.csv(paste(data.loc, raw.data.file, sep = ""), check.names = FALSE)
  data.dictionary <- read.csv(paste(data.loc, data.dictionary.file, sep = ""))
  
  working.data <- raw.data
  names(working.data) <- gsub("^ *", "", gsub(" *$", "", names(working.data)))
  names(working.data)[names(working.data) == ""] <- "[blank]"
  n.obs.data <- dim(working.data)[1]
  n.vars.data <- dim(working.data)[2]
  diction.table <- data.dictionary
  names(diction.table) <- c("Var.Name", "Var.Class", "Test.Grp", "Min.Range", "Max.Range", "Factors", "Var.Label", "Comments")
  diction.table[diction.table == ""] <- NA
  diction.table$Test.Grp[is.na(diction.table$Test.Grp)] <- FALSE
  diction.table <- diction.table[!diction.table$Var.Name %in% c("Example.Group", "Example.ID", "Example.Age", "Example.Sex"),]
  n.vars.diction <- dim(diction.table)[1]
  diction.table <- as.matrix(diction.table)
  diction.table <- gsub("^ *", "", gsub(" *$", "", diction.table))
  diction.table <- as.data.frame(diction.table)
  rownames(diction.table) <- 1:n.vars.diction
  
#################### SET CLASSES OF VARS ####################
  diction.table$Var.Name <- as.character(diction.table$Var.Name)
  diction.table$Var.Label <- as.character(diction.table$Var.Label)
  diction.table$Comments <- as.character(diction.table$Comments)   
  diction.table$Min.Range <- as.numeric(as.character(diction.table$Min.Range))
  diction.table$Max.Range <- as.numeric(as.character(diction.table$Max.Range))  
  diction.table$Factors <- as.character(diction.table$Factors)
  diction.table$Test.Grp <- as.logical(diction.table$Test.Grp)
  diction.table$Var.Class <- as.character(diction.table$Var.Class)
  n.test.grps <- sum(diction.table$Test.Grp, na.rm = TRUE)
  if(n.test.grps == 1) {
    temp.group.var <- working.data[[diction.table$Var.Name[diction.table$Test.Grp]]]
  } else if(n.test.grps > 1) {
    print("Only 1 Test Group allowed at this time.  Using the first Test Group Variable Only")
    diction.table$Test.Grp[diction.table$Test.Grp][-1] <- FALSE
    temp.group.var <- working.data[[diction.table$Var.Name[diction.table$Test.Grp]]]  
    temp.group.var[is.blank(temp.group.var)] <- NA
    temp.group.var <- as.factor(as.character(temp.group.var))
  }
  factor.summ.list <- as.list(NULL)
  factor.list <- as.list(NULL)
  Warning.List <- as.list(NULL)
  Error.List <- as.list(NULL)
  all.summ.list <- as.list(NULL)
  
  if(sum(!names(working.data) %in% diction.table$Var.Name) > 0){
    if(length(names(working.data)[!names(working.data) %in% diction.table$Var.Name]) <= 5) print(paste("The variables '", paste(names(working.data)[!names(working.data) %in% diction.table$Var.Name], collapse = "', '"), 
                "' do not appear in the data dictionary and will be skipped in all analysis", sep = ""))
    else print(paste(length(names(working.data)[!names(working.data) %in% diction.table$Var.Name]), " variables do not appear in the data dictionary and will be skipped in all analysis", sep = ""))
  }
  if(sum(!diction.table$Var.Name %in% names(working.data)) > 0){
    if(length((diction.table$Var.Name)[!diction.table$Var.Name %in% names(working.data)]) <= 5) print(paste("The variables '", paste((diction.table$Var.Name)[!diction.table$Var.Name %in% names(working.data)], collapse = "', '"), 
           "' do not appear as variable names in the data and will be skipped in all analysis", sep = ""))
    else print(paste(length((diction.table$Var.Name)[!diction.table$Var.Name %in% names(working.data)]), " variables do not appear as variable names in the data and will be skipped in all analysis", sep = ""))
  }
      
  for(var_index in 1:n.vars.diction) {
#################### DEFINE CLASS OF EACH VARIABLE #################### 
    if(is.na(diction.table$Var.Class[var_index])){
      if(!is.na(diction.table$Min.Range[var_index]) | !is.na(diction.table$Max.Range[var_index])) diction.table$Var.Class[var_index] <- "Numeric"
      else if(!is.na(diction.table$Factors[var_index]) & diction.table$Factors[var_index] != "") diction.table$Var.Class[var_index] <- "Factor"
      else diction.table$Var.Class[var_index] <- "Character"
    } else {
      if(gsub("S", "", gsub(" ", "", toupper(diction.table$Var.Class[var_index]))) == "NUMERIC") diction.table$Var.Class[var_index] <- "Numeric"
      else if(gsub("S", "", gsub(" ", "", toupper(diction.table$Var.Class[var_index]))) == "FACTOR") diction.table$Var.Class[var_index] <- "Factor"
      else if(gsub("S", "", gsub(" ", "", toupper(diction.table$Var.Class[var_index]))) == "CHARACTER") diction.table$Var.Class[var_index] <- "Character"
      else if(gsub("S", "", gsub(" ", "", toupper(diction.table$Var.Class[var_index]))) == "DATE") diction.table$Var.Class[var_index] <- "Date"    
      else if(gsub("S", "", gsub(" ", "", toupper(diction.table$Var.Class[var_index]))) == "TIME") diction.table$Var.Class[var_index] <- "Time"        
    }
    
#################### LIST OUT FACTORS ####################  
    if(diction.table$Var.Class[var_index] == "Factor"){
      sep.locs <- as.numeric(gregexpr(";", diction.table$Factors[var_index])[[1]])
      for(factor_index in 1:(length(sep.locs) + 1)){
        if(factor_index == 1) temp.factor.list <- substr(diction.table$Factors[var_index], 1, (sep.locs[1] - 1))
        else if(factor_index == (length(sep.locs) + 1)) temp.factor.list <- c(temp.factor.list, substr(diction.table$Factors[var_index], (sep.locs[factor_index - 1] + 1), nchar(diction.table$Factors[var_index])))
        else temp.factor.list <- c(temp.factor.list, substr(diction.table$Factors[var_index], (sep.locs[factor_index - 1] + 1), (sep.locs[factor_index] - 1)))
      }
      temp.factor.list <- gsub("^ *", "", gsub(" *$", "", temp.factor.list))
      temp.factor.list[temp.factor.list == ""] <- "[blank]"
      factor.list[[diction.table$Var.Name[var_index]]] <- temp.factor.list
    }
  }
  if(n.test.grps > 0){
    temp.group.levels <- factor.list[[diction.table$Var.Name[diction.table$Test.Grp]]]
    temp.group.name <- diction.table$Var.Name[diction.table$Test.Grp]
  }
  
  filename <- ifelse(is.null(filename), "Variable Summary", filename)
  
  
  
  pdf(paste(results.dir, filename, " Plots (", date, ").pdf", sep = ""))
  for(var_index in 1:n.vars.diction){
      
    temp.var.name <- diction.table$Var.Name[var_index]
    temp.var <- working.data[[temp.var.name]]
    temp.var.class <- diction.table$Var.Class[var_index] 
    temp.min.range <- diction.table$Min.Range[var_index]
    temp.max.range <- diction.table$Max.Range[var_index] 
    temp.factors <- diction.table$Factors[var_index]  
    temp.var.label <- diction.table$Var.Label[var_index]
    temp.test.grp <- diction.table$Test.Grp[var_index]
    Warning.List[[temp.var.name]] <- NULL
    Error.List[[temp.var.name]] <- NULL    
    
    if(temp.var.name %in% names(working.data)){
    
      all.summ.list[[temp.var.name]] <- as.list(NULL)    
#################### SUMMARIZE VARIABLES ####################
### Factor ###
      if(temp.var.class == "Factor"){
        temp.var <- gsub("^ *", "", gsub(" *$", "", temp.var))
        n.blank <- sum(temp.var == "", na.rm = TRUE)
        temp.var[temp.var == ""] <- NA
        temp.var <- as.factor(as.character(temp.var))
        temp.table <- table(temp.var)
        n.na <- sum(is.na(temp.var))    
        temp.table <- c(temp.table, sum(temp.table), n.na)
        names(temp.table)[(length(temp.table)-1):length(temp.table)] <- c("Total", "NA's")
        
        temp.table <- rbind(names(temp.table), temp.table)
        temp.table <- cbind(c("Level", "Frequency"), temp.table)
        colnames(temp.table) <- NULL
        temp.levels.data <- levels(temp.var)
        temp.levels.diction <- factor.list[[temp.var.name]]
        data.no.diction <- setdiff(temp.levels.data, temp.levels.diction)
        diction.no.data <- setdiff(temp.levels.diction, temp.levels.data)
        if(length(diction.no.data) == 1) if(is.na(diction.no.data)) diction.no.data <- NULL
        if(length(data.no.diction) > 0){
          Error.List[[temp.var.name]] <- ifelse(length(data.no.diction) <=5, 
                       c(Error.List[[temp.var.name]], paste("Error: The levels: '", paste(data.no.diction, collapse = "', '"), "' do not appear in the data dictionary", sep = "")),
                       c(Error.List[[temp.var.name]], paste("Error: ", length(data.no.diction), " levels do not appear in the data dictionary", sep = ""))
                       )
        }
        if(length(diction.no.data) > 0){
          Warning.List[[temp.var.name]] <- ifelse(length(diction.no.data) <= 5,
                       c(Warning.List[[temp.var.name]], paste("Warning: The levels: '", paste(diction.no.data, collapse = "', '"), "' do not appear in the data", sep = "")),
                       c(Warning.List[[temp.var.name]], paste("Warning: ", length(diction.no.data), " levels do not appear in the data", sep = ""))
                       )
        }  
        if(n.blank > 0){
          Warning.List[[temp.var.name]] <- c(Warning.List[[temp.var.name]], paste("Warning: There were ", n.blank, " blank values that were coerced to NA's", sep = ""))
        }
        temp.all.summ <- temp.table
        factor.summ.list[[temp.var.name]] <- temp.table
### Numeric ###
      } else if(temp.var.class == "Numeric"){
        non.num <- temp.var[!is.blank(temp.var, na.blank = TRUE) & is.na(suppressWarnings(as.numeric(as.character(temp.var))))]
        if(length(non.num) > 0) Error.List[[temp.var.name]] <- c(Error.List[[temp.var.name]], paste("Error: the values: '", paste(unique(non.num), collapse = "', '"), "' are not valid numeric entries and have been coerced to NA's", sep = ""))
        temp.var <- suppressWarnings(as.numeric(as.character(temp.var)))
        temp.summ <- summary(temp.var, digits = 100)
        temp.summ <- rbind(c("Statistic", names(temp.summ)), c("Value", temp.summ))
        colnames(temp.summ) <- NULL        
        below.range <- sum(temp.var < temp.min.range, na.rm = TRUE)
        above.range <- sum(temp.var > temp.max.range, na.rm = TRUE)
        if(below.range > 0) Warning.List[[temp.var.name]] <- c(Warning.List[[temp.var.name]], paste("Warning: There are ", below.range, " values that are below the minimum range", sep = ""))
        if(above.range > 0)  Warning.List[[temp.var.name]] <- c(Warning.List[[temp.var.name]], paste("Warning: There are ", above.range, " values that are above the maximum range", sep = ""))
        temp.all.summ <- temp.summ
### Character ###
      } else if(temp.var.class == "Character"){
        temp.var <- gsub("^ *", "", gsub(" *$", "", temp.var))
        n.blank <- sum(temp.var == "", na.rm = TRUE)
        temp.var[temp.var == ""] <- NA      
        n.na <- sum(is.na(temp.var))
        n.unique <- length(unique(temp.var[!is.na(temp.var)]))
        temp.all.summ <- paste("There are ", n.unique, " unique values out of ", n.obs.data - n.na, " non-missing observations", sep = "")
        if(n.na > 0) Warning.List[[temp.var.name]] <- c(Warning.List[[temp.var.name]], paste("Warning: ", n.na, " missing/NA values", sep = ""))
### Date ###
      } else if(temp.var.class == "Date"){
        if(is.null(input.date.format)){
          date.format <- names(sort(-table(guess_formats(temp.var[!is.na(temp.var)], c("mdy", "dmy")))))[1] # Finds the most likely date format (picks 1st alphabetically if multi-modal
          Warning.List[[temp.var.name]] <- c(Warning.List[[temp.var.name]], paste("Warning: No date format supplied; guessing that the input date format is: ", date.format, sep = "")) # Output format diff in R and Excel
        } else { 
          date.format <- input.date.format
        }
        temp.var <- as.Date(temp.var, date.format)
        temp.summ <- summary(temp.var, digits = 100)
        temp.summ <- as.character(temp.summ)
        temp.summ <- rbind(c("Statistic", names(temp.summ)), c("Value", temp.summ))
        colnames(temp.summ) <- NULL     
        temp.all.summ <- temp.summ
### Time ###
      } else if(temp.var.class == "Time"){
        temp.var <- as.character(temp.var)
        n.na <- sum(is.blank(temp.var, na.blank = TRUE))
        temp.var <- temp.var[!is.blank(temp.var, na.blank = TRUE)]
        time.format <- names(sort(-table(guess_formats(temp.var, c("HMS")))))[1] # Finds the most likely time format (picks 1st alphabetically if multi-modal   
        Warning.List[[temp.var.name]] <- c(Warning.List[[temp.var.name]], paste("Warning: No time format supplied; guessing that the input time format is: ", time.format, sep = "")) 
        temp.hr <- as.numeric(strftime(strptime(temp.var, time.format), "%H"))    
        temp.min <- as.numeric(strftime(strptime(temp.var, time.format), "%M"))    
        temp.sec <- as.numeric(strftime(strptime(temp.var, time.format), "%S"))
        temp.time <- temp.hr * 3600 + temp.min * 60 + temp.sec
        time.summ <- summary(temp.time, digits = 100)
        format.summ <- number.to.time(time.summ)
        names(format.summ) <- names(time.summ)                                                
        if(n.na > 0){
          format.summ <- c(format.summ, n.na)
          names(format.summ)[7] <- "NA's"
        }
        format.summ <- rbind(c("Statistic", names(format.summ)), c("Value", format.summ))      
        colnames(format.summ) <- NULL    
        temp.all.summ <- format.summ
### Other ###    
      } else {
        temp.all.summ <- paste("Cannot recognize class: ", temp.var.class, sep = "")
      }
      
      all.summ.list[[temp.var.name]][["Summary"]] <- temp.all.summ
    
      if(!is.null(Error.List[[temp.var.name]])) all.summ.list[[temp.var.name]][["Errors"]] <- t(t(Error.List[[temp.var.name]]))
      if(!is.null(Warning.List[[temp.var.name]])) all.summ.list[[temp.var.name]][["Warnings"]] <- t(t(Warning.List[[temp.var.name]]))
    
#################### PLOT VARIABLES ####################
### NUMERIC ###
      if(temp.var.class == "Numeric"){
      # Overall #
        if(summarize.by.group & n.test.grps > 0 & !temp.test.grp){
          if(is.null(Error.List[[temp.group.name]]) & is.null(Error.List[[temp.var.name]])){
            plot.y <-  cbind(1:n.obs.data, temp.var, as.character(temp.group.var))
          } else {
            plot.y <- cbind(1:n.obs.data, temp.var, NA)  
          }
        } else {
          plot.y <- cbind(1:n.obs.data, temp.var, NA)        
        }
        plot.y <- plot.y[!is.na(plot.y[,2]),]
        main <- ifelse(is.na(temp.var.label), temp.var.name, temp.var.label)
        main <- paste("Plot of ", main, sep = "")
        ymin <- ifelse(!is.na(temp.min.range), min(temp.var, temp.min.range, na.rm = TRUE), min(temp.var, na.rm = TRUE))
        ymax <- ifelse(!is.na(temp.max.range), max(temp.var, temp.max.range, na.rm = TRUE), max(temp.var, na.rm = TRUE))
        ylim <- c(ymin, ymax)
        if(!is.na(temp.min.range) & sum(as.numeric(plot.y[,2]) < temp.min.range) > 0){ 
          plot.y.below <- plot.y[as.numeric(plot.y[,2]) < temp.min.range,]      
          if(!is.matrix(plot.y.below))
            plot.y.below <- as.matrix(t(plot.y.below), nrow = 1)
          plot.y.in <- plot.y[!plot.y[,1] %in% plot.y.below[,1],]
        } else plot.y.in <- plot.y
        if(!is.na(temp.max.range) & sum(as.numeric(plot.y[,2]) < temp.max.range) > 0){
          plot.y.above <- plot.y[as.numeric(plot.y[,2]) > temp.max.range,]
          if(!is.matrix(plot.y.above))
            plot.y.above <- as.matrix(t(plot.y.above), nrow = 1)          
          plot.y.in <- plot.y.in[!plot.y.in[,1] %in% plot.y.above[,1],]
        }
        plot(x = plot.y.in[,1], y = plot.y.in[,2], main = main, xlab = "Observation #", ylab = temp.var.name, ylim = ylim, pch = 16)
        if(!is.na(temp.min.range) & sum(as.numeric(plot.y[,2]) < temp.min.range) > 0){
          lines(x = c(0, n.obs.data - (.112 * n.obs.data)), y = c(rep(temp.min.range, 2)), col = "red")
          text(x = n.obs.data - (.032 * n.obs.data), y = temp.min.range, "Min. Limit", col = "red")
          points(x = plot.y.below[,1], y = plot.y.below[,2], col = "black", bg = "red", pch = 25)
        }
        if(!is.na(temp.max.range & sum(as.numeric(plot.y[,2]) < temp.max.range) > 0)){
          lines(x = c(0, n.obs.data - (.112 * n.obs.data)), y = c(rep(temp.max.range, 2)), col = "red")    
          text(x = n.obs.data - (.03 * n.obs.data), y = temp.max.range, "Max. Limit", col = "red")      
          points(x = plot.y.above[,1], y = plot.y.above[,2], col = "black", bg = "red", pch = 24)      
        }
      # By grp #
        if(summarize.by.group & n.test.grps > 0 & !temp.test.grp) if(is.null(Error.List[[temp.group.name]]) & is.null(Error.List[[temp.var.name]])){
          par(xpd=T, mar=par()$mar+c(0,0,0,7))      
          main <- paste(main, "by", temp.group.name)
          temp.cols <- rainbow(length(levels(temp.group.var)))
          names(temp.cols) <- levels(temp.group.var)
          plot.y.in.list <- split(as.data.frame(plot.y.in), plot.y.in[,3])
          for(level_index in names(plot.y.in.list)){
            plot.y.in.list[[level_index]][,1] <- as.numeric(as.character(plot.y.in.list[[level_index]][,1]))
            plot.y.in.list[[level_index]][,2] <- as.numeric(as.character(plot.y.in.list[[level_index]][,2]))
          }   
          if(!is.na(temp.min.range) & sum(as.numeric(plot.y[,2]) < temp.min.range) > 0){       
            plot.y.below.list <- split(as.data.frame(plot.y.below), plot.y.below[,3])
            for(level_index in names(plot.y.below.list)){
              plot.y.below.list[[level_index]][,1] <- as.numeric(as.character(plot.y.below.list[[level_index]][,1]))
              plot.y.below.list[[level_index]][,2] <- as.numeric(as.character(plot.y.below.list[[level_index]][,2]))
            }         
          }
          if(!is.na(temp.max.range) & sum(as.numeric(plot.y[,2]) < temp.max.range) > 0){
            plot.y.above.list <- split(as.data.frame(plot.y.above), plot.y.above[,3])                
            for(level_index in names(plot.y.above.list)){
              plot.y.above.list[[level_index]][,1] <- as.numeric(as.character(plot.y.above.list[[level_index]][,1]))
              plot.y.above.list[[level_index]][,2] <- as.numeric(as.character(plot.y.above.list[[level_index]][,2]))
            }         
          }          
          plot(NULL, main = main, xlab = "Observation #", ylab = temp.var.name, xlim = c(0, n.obs.data), ylim = ylim)
          for(level_index in names(plot.y.in.list)) points(x = plot.y.in.list[[level_index]][,1], 
               y = plot.y.in.list[[level_index]][,2], pch = 21, col = "black", bg = temp.cols[[level_index]])
          if(!is.na(temp.min.range) & sum(as.numeric(plot.y[,2]) < temp.min.range) > 0){
            lines(x = c(0, n.obs.data - (.15 * n.obs.data)), y = c(rep(temp.min.range, 2)), col = "red")
            text(x = (n.obs.data - (.06 * n.obs.data)), y = temp.min.range, "Min. Limit", col = "red")
            for(level_index in names(plot.y.below.list)) {
              points(x = plot.y.below.list[[level_index]][,1], y = plot.y.below.list[[level_index]][,2], pch = 25, col = "black", bg = temp.cols[[level_index]])
            }
          }
          if(!is.na(temp.max.range) & sum(as.numeric(plot.y[,2]) < temp.max.range) > 0){
            lines(x = c(0, n.obs.data - (.15 * n.obs.data)), y = c(rep(temp.max.range, 2)), col = "red")    
            text(x = (n.obs.data - (.06 * n.obs.data)), y = temp.max.range, "Max. Limit", col = "red")      
            for(level_index in names(plot.y.above.list)) {
              points(x = plot.y.above.list[[level_index]][,1], y = plot.y.above.list[[level_index]][,2], pch = 24, col = "black", bg = temp.cols[[level_index]])      
            }
          }
          legend(x = (n.obs.data + (n.obs.data / 12.5)), y = max(ylim), levels(temp.group.var), pch = 21, col = "black", pt.bg = temp.cols, title = temp.group.name, bty = "n")
          par(mar=c(5.1, 4.1, 4.1, 2.1))  
        }
### FACTOR ###      
      } else if(temp.var.class == "Factor") {
      # Overall #
        plot.y <- factor(ifelse(temp.var %in% data.no.diction, paste(as.character(temp.var), "*", sep = ""), as.character(temp.var)))
        bar.table <- table(plot.y)
        labels <- levels(plot.y)
        main <- ifelse(is.na(temp.var.label), temp.var.name, temp.var.label)
        main <- paste("Plot of ", main, sep = "")
        max.chars <- max(nchar(labels))
        mar.adj <- max(((max.chars - 12) / 4), 0)
        n.factors <- length(labels)
        cex.adj <- min(max((n.factors - 25), 0) / 50, 0.9)
        par(mar=c(5.1 + max((mar.adj - (cex.adj * 3.75)), 0), 4.1 + max((mar.adj - (cex.adj * 5)), 0), 4.1, 2.1))       
        barplot.x.label.pos <- barplot(bar.table, main = "", axisnames = FALSE)
        if ((mar.adj == 0 & cex.adj == 0)) {
          tilt.names <- 0
          names.adj <- c(1.0, 1.0)
          xlab <- temp.var.name
        } else {
          tilt.names <- 45
          names.adj <- c(1.0, 0.5)
          xlab <- ""        
        }
        text(barplot.x.label.pos, par("usr")[3], labels = labels, srt = tilt.names, adj = names.adj, xpd = TRUE, cex = 1 - cex.adj)
        second.title <- NULL
        if(length(data.no.diction) > 1) second.title <- "\n*Level not in data dictionary"
        title(main = paste(main, second.title, sep = ""), xlab = xlab, ylab = "Frequency")
        par(mar=c(5.1, 4.1, 4.1, 2.1))                                
      # By grp #
        if(summarize.by.group & n.test.grps > 0 & !temp.test.grp) if(is.null(Error.List[[temp.group.name]]) & is.null(Error.List[[temp.var.name]])){
          cex.adj <- min(max(((n.factors * length(levels(temp.group.var))) - 25), 0) / 50, 0.9)
          par(mar=c(5.1 + max((mar.adj - (cex.adj * 7.5)), 0), 4.1 + max((mar.adj - (cex.adj * 7.5)), 0), 4.1, 2.1))                 
          par(xpd=T, mar=par()$mar+c(0,0,0,7))      
          bar.table <- table(temp.group.var, temp.var)
          n.na.grp <- sum(table(temp.var)) - sum(bar.table)
          second.title <- NULL
          if(n.na.grp > 0) second.title <- paste("\n(", n.na.grp, " missing group values)", sep = "")
          main <- paste(main, "by", temp.group.name, second.title)          
          bar <- barplot(bar.table, main = main, xlab = xlab, ylab = "Frequency", beside = TRUE, col = rainbow(length(levels(temp.group.var))), axisnames = FALSE)
          barplot.x.label.pos <- rep(NA, dim(bar)[2])
          for(col_index in 1:dim(bar)[2]) barplot.x.label.pos[col_index] <- mean(bar[,col_index])          
          text(barplot.x.label.pos, par("usr")[3], labels = labels, srt = tilt.names, adj = names.adj, xpd = TRUE, cex = 1 - cex.adj)
          legend(x = (bar[length(bar)] + 1), y = max(bar.table), levels(temp.group.var), pch = 22, col = "black", pt.bg = rainbow(length(levels(temp.group.var))), title = temp.group.name, bty = "n")
          par(mar=c(5.1, 4.1, 4.1, 2.1))                        
        }                                                    

### DATE ###      
      } else if(temp.var.class == "Date") {
        main <- ifelse(is.na(temp.var.label), temp.var.name, temp.var.label)
        main <- paste("Histogram of ", main, sep = "")
        plot.y <- hist(as.numeric(temp.var), plot = FALSE)
        n.breaks <- length(plot.y$breaks)
        breaks.adj <- c(1, 0.5)
        if(n.breaks < 10) breaks.adj <- breaks.adj + c(n.breaks / 50, n.breaks / 15)        
        plot(plot.y, main = main, xlab = "", xaxt = "n")
        axis(1, at = plot.y$breaks, labels = FALSE, tick = F)
        labels <- as.Date(plot.y$breaks, origin = "1970-01-01")
        text(plot.y$breaks, par("usr")[3] + .15, labels = labels, srt = 45, adj = breaks.adj, xpd = TRUE, offset = 0)
### TIME ###      
      } else if(temp.var.class == "Time") {
        main <- ifelse(is.na(temp.var.label), temp.var.name, temp.var.label)
        main <- paste("Histogram of ", main, sep = "")        
        temp.var.num <- time.to.number(temp.var)
        plot.y <- hist(as.numeric(temp.var.num), plot = FALSE)
        n.breaks <- length(plot.y$breaks)
        breaks.adj <- c(1, 0.5)
        if(n.breaks < 10) breaks.adj <- breaks.adj + c(n.breaks / 50, n.breaks / 15)          
        plot(plot.y, main = main, xlab = "", xaxt = "n")
        axis(1, at = plot.y$breaks, labels = FALSE, tick = FALSE)
        labels <- number.to.time(plot.y$breaks)
        n.days <- floor(as.numeric(substr(labels, 1, 2)) / 24)
        hr.labels <- as.character(as.numeric(substr(labels, 1, 2)) - (n.days * 24))
        hr.labels <- ifelse(nchar(hr.labels) == 1, paste("0", hr.labels, sep = ""), hr.labels)
        substr(labels, 1, 2) <- hr.labels
        text(plot.y$breaks, par("usr")[3] + .15, labels = labels, srt = 45, adj = breaks.adj, xpd = TRUE, offset = 0)
      }
   
#################### TEST DATA AGAINST CHOSEN GROUP #################### 
      if(summarize.by.group & n.test.grps > 0 & !temp.test.grp) if(is.null(Error.List[[temp.group.name]]) & is.null(Error.List[[temp.var.name]])){
### NUMERIC ###    
        if(temp.var.class == "Numeric"){
          var <- temp.var[!is.na(temp.var) & temp.group.var %in% temp.group.levels]
          class <- factor(temp.group.var[!is.na(temp.var) & temp.group.var %in% temp.group.levels])
          temp.summ.grp <- cont_sum(class = class, var = var, class.labels = levels(class), var.name = temp.var.name, panel = var_index)
          temp.table.grp <- as.matrix(temp.summ.grp[[1]]) 
          combos <- t(combn(levels(class), 2))        
          n.combos <- dim(combos)[1]
          if(n.combos > 1){
            mult.corr <- "hochberg"
            mult.mat <- matrix("", ncol = dim(temp.table.grp)[2], nrow = n.combos)
            colnames(mult.mat) <- colnames(temp.table.grp)
            raw.pvals <- NULL
            for(combo_index in 1:n.combos){
              temp.levels <- combos[combo_index,]
              short.class <- factor(class[class %in% temp.levels])
              short.var <- var[class %in% temp.levels]
              temp.short.grp.table <- cont_sum(class = short.class, var = short.var, class.labels = levels(short.class), var.name = temp.var.name)
              temp.short.grp.pval <- temp.short.grp.table[[2]]
              raw.pvals <- c(raw.pvals, temp.short.grp.pval)
            }
            hoch.pvals <- p.adjust(raw.pvals, method = mult.corr, n = length(raw.pvals))
            hoch.format.pvals <- NULL
            for(pval_index in 1:length(hoch.pvals)) hoch.format.pvals <- c(hoch.format.pvals, format.p.value(hoch.pvals[pval_index]))
            for(combo_index in 1:n.combos){ 
              temp.levels <- combos[combo_index,]         
              mult.mat[combo_index, colnames(mult.mat) %in% temp.levels] <- "*"            
              mult.mat[combo_index, colnames(mult.mat) == "Pval"] <- hoch.format.pvals[combo_index]     
              mult.mat[combo_index, colnames(mult.mat) == "test"] <- paste(temp.table.grp[1,colnames(temp.table.grp) == "test"], " ", mult.corr, "-corrected", sep = "")            
            }
            temp.table.grp <- rbind(temp.table.grp[(1:(dim(temp.table.grp)[1]-1)),], mult.mat)             
            temp.table.grp[,colnames(temp.table.grp) == "row"] <- 1:dim(temp.table.grp)[1]
            temp.table.grp[,colnames(temp.table.grp) == "panel"] <- temp.table.grp[1,colnames(temp.table.grp) == "panel"]
            counter <- 0  
            for(out_index in temp.group.levels){
              counter <- counter + 1
              if(!out_index %in% colnames(temp.table.grp)){
                temp.table.grp <- cbind(temp.table.grp[,1:counter], "", temp.table.grp[,((counter+1):dim(temp.table.grp)[2])])
                colnames(temp.table.grp)[counter+1] <- out_index
              }
            }
          }
          temp.table.grp <- rbind(colnames(temp.table.grp), temp.table.grp)
          colnames(temp.table.grp) <- NULL
          all.summ.list[[temp.var.name]][[paste("Summary by ", temp.group.name, sep = "")]] <- temp.table.grp
### FACTOR ###  
        } else if(temp.var.class == "Factor"){
          var <- temp.var[!is.na(temp.var) & temp.group.var %in% temp.group.levels]
          class <- factor(temp.group.var[!is.na(temp.var) & temp.group.var %in% temp.group.levels])
          temp.summ.grp <- cat_sum(class = class, var = var, class.labels = levels(class), var.name = temp.var.name, var.label = levels(var), panel = var_index)
          temp.table.grp <- as.matrix(temp.summ.grp[[1]])                            
          combos <- t(combn(levels(class), 2))        
          n.combos <- dim(combos)[1]
          if(n.combos > 1){
            mult.corr <- "hochberg"
            mult.mat <- matrix("", ncol = dim(temp.table.grp)[2], nrow = n.combos)
            colnames(mult.mat) <- colnames(temp.table.grp)
            raw.pvals <- NULL
            for(combo_index in 1:n.combos){
              temp.levels <- combos[combo_index,]
              short.class <- factor(class[class %in% temp.levels])
              short.var <- factor(var[class %in% temp.levels])
              temp.short.grp.table <- cat_sum(class = short.class, var = short.var, class.labels = levels(short.class), var.name = temp.var.name)
              temp.short.grp.pval <- temp.short.grp.table[[2]]
              raw.pvals <- c(raw.pvals, temp.short.grp.pval)
            }
            hoch.pvals <- p.adjust(raw.pvals, method = mult.corr, n = length(raw.pvals))
            hoch.format.pvals <- NULL
            for(pval_index in 1:length(hoch.pvals)) hoch.format.pvals <- c(hoch.format.pvals, format.p.value(hoch.pvals[pval_index]))
            for(combo_index in 1:n.combos){ 
              temp.levels <- combos[combo_index,]         
              mult.mat[combo_index, colnames(mult.mat) %in% temp.levels] <- "*"            
              mult.mat[combo_index, colnames(mult.mat) == "Pval"] <- hoch.format.pvals[combo_index]     
              mult.mat[combo_index, colnames(mult.mat) == "test"] <- paste(temp.table.grp[1,colnames(temp.table.grp) == "test"], " ", mult.corr, "-corrected", sep = "")            
            }
            temp.table.grp <- rbind(temp.table.grp[(1:(dim(temp.table.grp)[1]-1)),], mult.mat)
            temp.table.grp[,colnames(temp.table.grp) == "row"] <- 1:dim(temp.table.grp)[1]
            temp.table.grp[,colnames(temp.table.grp) == "panel"] <- temp.table.grp[1,colnames(temp.table.grp) == "panel"]
            counter <- 0  
            for(out_index in temp.group.levels){
              counter <- counter + 1
              if(!out_index %in% colnames(temp.table.grp)){
                temp.table.grp <- cbind(temp.table.grp[,1:counter], "", temp.table.grp[,((counter+1):dim(temp.table.grp)[2])])
                colnames(temp.table.grp)[counter+1] <- out_index
              }
            }
          } 
          temp.table.grp <- rbind(colnames(temp.table.grp), temp.table.grp)
          colnames(temp.table.grp) <- NULL        
          all.summ.list[[temp.var.name]][[paste("Summary by ", temp.group.name, sep = "")]] <- temp.table.grp       
        }
      }
    }                                                       
  }
  
#################### CREATE CSV FROM THE TABLES ####################
  max.tbl.width <- max(c(sapply(factor.summ.list, dim)[2,], 8, ifelse(summarize.by.group & n.test.grps > 0, 6 + length(temp.group.levels), 0)))  
  all.summ.mat <- NULL
  for(var_index in names(all.summ.list)){
    print(var_index)
    temp.var <- all.summ.list[[var_index]]
    all.summ.mat <- rbind(all.summ.mat, rep("", (max.tbl.width)), rep("", (max.tbl.width)), rep("", (max.tbl.width)), c("Variable: ", rep("", (max.tbl.width-1))), c(var_index, rep("", (max.tbl.width-1))))
    if("Summary" %in% names(temp.var)){
      all.summ.mat <- rbind(all.summ.mat, "")
      if(is.matrix(temp.var[["Summary"]])) all.summ.mat <- rbind(all.summ.mat, c("Summary:", rep("", (max.tbl.width-1))), cbind(temp.var[["Summary"]], matrix(rep(rep("", (max.tbl.width-dim(temp.var[["Summary"]])[2])), 2), nrow = 2)))
      else all.summ.mat <- rbind(all.summ.mat, c("Summary:", rep("", (max.tbl.width-1))), c(temp.var[["Summary"]], rep("", (max.tbl.width-length(temp.var[["Summary"]])))))
    }
    if("Warnings" %in% names(temp.var)){
      all.summ.mat <- rbind(all.summ.mat, "")  
      all.summ.mat <- rbind(all.summ.mat, c("Warnings:", rep("", (max.tbl.width-1))))
      for(warning_index in 1:length(temp.var[["Warnings"]])) all.summ.mat <- rbind(all.summ.mat, c(temp.var[["Warnings"]][warning_index], rep("", (max.tbl.width-1))))
    }
    if("Errors" %in% names(temp.var)){
      all.summ.mat <- rbind(all.summ.mat, "")  
      all.summ.mat <- rbind(all.summ.mat, c("Errors:", rep("", (max.tbl.width-1))))
      for(error_index in 1:length(temp.var[["Errors"]])) all.summ.mat <- rbind(all.summ.mat, c(temp.var[["Errors"]][error_index], rep("", (max.tbl.width-1))))
    } 
    if(summarize.by.group & n.test.grps > 0 & !temp.test.grp) if(is.null(Error.List[[temp.group.name]]) & is.null(Error.List[[temp.var.name]])){
      if(paste("Summary by ", temp.group.name, sep = "") %in% names(temp.var)){
        all.summ.mat <- rbind(all.summ.mat, "")
        all.summ.mat <- rbind(all.summ.mat, c(paste("Summary by ", temp.group.name, ":", sep = ""), rep("", (max.tbl.width-1))))
        less.cols <- max.tbl.width - dim(temp.var[[paste("Summary by ", temp.group.name, sep = "")]])[2]
        if(less.cols > 0) temp.var[[paste("Summary by ", temp.group.name, sep = "")]] <- matrix(c(temp.var[[paste("Summary by ", temp.group.name, sep = "")]], rep("", (less.cols*dim(temp.var[[paste("Summary by ", temp.group.name, sep = "")]])[1]))), byrow = FALSE, ncol = max.tbl.width)
        all.summ.mat <- rbind(all.summ.mat, temp.var[[paste("Summary by ", temp.group.name, sep = "")]])    
      }
    }
  }              
  all.summ.mat <- all.summ.mat[-c(1:3),]
  rownames(all.summ.mat) <- 1:dim(all.summ.mat)[1]
  all.summ.df <- as.data.frame(all.summ.mat) 
  names(all.summ.df) <- NULL
  
  dev.off()
  write.csv(all.summ.df, file = paste(results.dir, filename, " (", date, ").csv", sep = ""), row.names = FALSE)
  
#################### USE SAS.table TO CREATE REPORT ####################
  validate <- all.summ.list
  
  total.pages <- 0
  last.var <- names(validate)[length(names(validate))]
  last.stat <- names(validate[[last.var]])[length(validate[[last.var]])]
  for(name_index in names(validate)){
    temp.var <- validate[[name_index]]
    for(stat_index in names(temp.var)){
      temp.var.stat <- temp.var[[stat_index]]
      if(class(temp.var.stat) != "character"){
        if(dim(temp.var.stat)[2] != 1) total.pages <- total.pages + 1
      }
    }
  }
  
  counter <- 0
  for(name_index in names(validate)){
    temp.var <- validate[[name_index]]
    for(stat_index in names(temp.var)){
      temp.var.stat <- temp.var[[stat_index]]
      if(class(temp.var.stat) != "character"){
        if(dim(temp.var.stat)[2] != 1){
          if(dim(temp.var.stat)[1] <= 2) temp.var.stat <- rbind(temp.var.stat, "")
          counter <- counter + 1    
          col.labels <- gsub("'", "", as.character(as.matrix(temp.var.stat)[1,]))
          temp.var.stat <- as.data.frame(temp.var.stat)
          footnotes <- c(validate[[name_index]][["Warnings"]], validate[[name_index]][["Errors"]])
          table.list <- SAS.table(temp.var.stat[-1,], filename = "SAS Summary", table.name = paste(name_index, stat_index, "table", sep = "_"), title1 = paste(name_index, "tables"), 
                                  title3 = stat_index, summ.df = FALSE, table.num = counter, last = ifelse(counter == total.pages, TRUE, FALSE),               
                                  table.list = table.list, before.footnote = footnotes, after.footnote = NULL,         
                                  orientation = "landscape", col.labels = col.labels, span.head = NULL,            
                                  cellwidth = NULL, page.room = NULL, fontsize = NULL, just.matrix = NULL,  
                                  log.pval = FALSE, log.base = "natural", stylepath = stylepath,             
                                  output.loc = paste(output.loc, "Data Validation (", date, ")/", sep = ""), clean.folder = TRUE)
        }
      }                              
    }
  }
     
  return(all.summ.list)

} 
### EOF ###
