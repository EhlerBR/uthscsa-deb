# Table functions redefined for SAS.table function #

# Table functions
#library(binom)
#library(multcomp)
#library(gdata)

##########################################################



##########################################################

make.latex.doc.vector <- 
function(file.name,includers="includeme",title="Data Analysis",author="",date=as.character(Sys.time()),path=NULL){
	
	
	slash <- "\\"
	
	
	out.vec <- list()
	out.vec  <- c(out.vec,pastes(slash,"documentclass[11pt]{amsart}"))
	out.vec <- c(out.vec,pastes(slash,"usepackage{geometry}                % See geometry.pdf to learn the layout options. There are lots."))
	out.vec<- c(out.vec,pastes(slash,"geometry{letterpaper}                   % ... or a4paper or a5paper or ... "))
	out.vec <- c(out.vec,pastes(slash,"usepackage{graphicx}"))
	out.vec <- c(out.vec,pastes(slash,"usepackage{amssymb}"))
	out.vec <- c(out.vec,pastes(slash,"usepackage{epstopdf}"))
	out.vec <- c(out.vec,pastes(slash,"usepackage{morefloats}"))
	out.vec <- c(out.vec,pastes(slash,"usepackage{hyperref}"))
	out.vec <- c(out.vec,pastes(slash,"hypersetup{pdfnewwindow=true}"))
	
	out.vec <- c(out.vec,pastes(slash,"DeclareGraphicsRule{.tif}{png}{.png}{`convert #1 `dirname #1`/`basename #1 .tif`.png}"))
	
	out.vec <- c(out.vec,paste(pastes(slash,"title{"),title,"}"))
	
	out.vec <- c(out.vec,paste(pastes(slash,"author{"),author,"}"))
	
	out.vec <- c(out.vec,paste(pastes(slash,"date{"),date,"}"))
	
	out.vec <- c(out.vec,pastes(slash,"newpage"))
	
	
	out.vec <- c(out.vec,pastes(slash,"begin{document}"))
	
	out.vec <- c(out.vec,pastes(slash,"maketitle"))
	
	last <- length(out.vec)+1
	
	for(includer in 1:length(includers)){
		
		out.vec[[last]] <- paste(pastes(slash,"include"),"{",includers[includer],"}",sep="")
		last <- last + 1
		
		out.vec[[last]] <- "Intentionally Blank\n"
		last <- last + 1
		
		
		
		
	}#loop over includer
	
	
	out.vec[[last]] <- 	pastes(slash,"end{document}")


write(unlist(out.vec),pastes(path,file.name))
	
	
	
} #END: make.latex.doc.vector

##########################################################

write.includer.vector <- function(include.list,path=NULL,include.file.base="includeme"){
	
#Writes lists of string vectors to include in a latex file
	
	if(is.null(names(include.list))){names(include.list) <- 1:length(include.list)}
	
	
	run.10 <- ceiling(length(include.list)/10)
	
	last <- 1
	step <- min(c(last+9,length(include.list)))
	
	file.names <- paste(include.file.base,1:run.10,sep="")
	
	for(chunk in 1:run.10){
		
		
		temp.list <- list()
		
#print(paste("Chunk",chunk))
		
		for(j in last:step){
			
#print(paste("step",j))
			
			temp.list <- c(temp.list,include.list[[j]])
			
			
		}
		
		write(unlist(temp.list) ,paste(path,file.names[chunk],".tex",sep=""))
		
		last <- last + 10
		step <- min(c(last+9,length(include.list)))
		
	}
	
	return(file.names)
	
} #END: write.includer.vector

##########################################################

latex.file.table.out <- function(file.table,tabtype="H",caption="Table of hyperlinks",label=""){
	
# takes data.frame with columns "description" and "hyperlink" 
# create a table with hyperlinks in latex 
	
	
	
	outlist <- list()
	
	dash.char <- "\\"
	
	outlist <- lcat( outlist, paste(pastes(dash.char,"begin{table}"),paste("[",tabtype,"]",sep=""),sep=""))
	outlist <- lcat( outlist, paste(dash.char,"begin{center}",sep=""))
	outlist <- lcat( outlist, paste(dash.char,"caption{",caption,"}",sep=""))

	outlist <- lcat( outlist, paste(dash.char,"begin{tabular}{rll}",sep=""))
	outlist <- lcat( outlist, paste("& Description & Hyperlink",dash.char,dash.char,sep=""))
	outlist <- lcat( outlist, paste(dash.char,"hline",sep=""))

	
	for(file in 1:nrow(file.table)){
		
		
		hyperlink <- paste("\\href{run:",file.table$hyperlink[file],"}","{",gsub("_","\\{\\\\textunderscore\\}",file.table$hyperlink[file]),"}",sep="")
		
		outlist <- lcat(outlist,paste("&",file.table$description[file],"&",hyperlink,dash.char,dash.char,sep=""))
		
		
	} #loop over file
	
	
	outlist <- lcat( outlist, paste(dash.char,"end{tabular}",sep=""))
	

	outlist <- lcat( outlist, paste(dash.char,"end{center}",sep=""))
	outlist <- lcat( outlist, paste(pastes(dash.char,"end{table}"),sep=""))
	
	outlist.2 <- paste(c("",unlist(outlist),""),"\n")
	
	return(outlist.2)
	
} #END latex.file.table.out

##########################################################

 p.rounder <- function(pvalue,digits=4){
	
	small <- 10^-digits
	
	output <- ifelse(pvalue<=small,format(pvalue,digits=digits,scientific=TRUE),as.character(round(pvalue,digits)))
	
	return(output)
	
}

##########################################################

anovaTable <- function(anovatable){
	
	if(ncol(anovatable)==4){anovatable <- anovatable[,-1]}
	
	anovaOut <- data.frame(Variable=rownames(anovatable),anovatable,stringsAsFactors=FALSE)
	
	anovaOut[,2] <- round(anovaOut[,2],4)
	
	anovaOut[,4] <- p.rounder(anovaOut[,4])
	
	names(anovaOut)[2] <- "Chisq"
	names(anovaOut)[4] <- "p_value"
	
	return(anovaOut)
	
} #END: anovaTable

##########################################################

logistic.table <- function(fit.logistic,digits0=c(0,3,2,2,0,4),ci.digits=2){
	
# Summarizes the significance of continuous or binary coefficients

	
sum.fit <- summary(fit.logistic)$coef 
	
	
est <- exp(sum.fit[,1])
se <- sum.fit[,2]
ci95 <- exp(cifort(log(est),se,Inf,0.95))
ci95.char <- paste("[",round(ci95[,1],ci.digits),", ",round(ci95[,2],ci.digits),"]",sep="")

p.val <- p.rounder(sum.fit[,4])

temper <- data.frame("Variable"=rownames(sum.fit),"LogOdds"=sum.fit[,1],"Std_Err"=se,"OR"=est,"CI95"=ci95.char,"PValue"=p.val)

temper <- round.data(temper,digits=digits0)

temper <- temper[-1,]
	
	
return(temper)

	
} #END: logistic.table

##########################################################

Norow.mat <- function(x){
	
# converts to a matrix with NULL rownames for output to latex
	
	x <- as.matrix(x)
	
	rownames(x) <- NULL
	
	return(x)
	
}
	
##########################################################

latex.figure.out <- function(filename,figtype="htpb",width="17cm",height="15cm",caption="From R.",label=""){
	
#filename <- ""
#	figtype="htpb"
#	width="17cm"
#	height="15cm"
#	caption=""
#	label=""
	
	out.list <- list()
	
	dash.char <- "\\"
	
	out.list[[1]] <- paste(pastes(dash.char,"begin{figure}"),paste("[",figtype,"]",sep=""),sep="")
	out.list[[2]] <- paste(pastes(dash.char,"centerline"),"{",pastes(dash.char,"includegraphics"),"[width=",width,",height=",height,"]{",filename,"}}",sep="")
	out.list[[3]] <- paste(pastes(dash.char,"caption{"),caption,"}")
	out.list[[4]] <- paste(pastes(dash.char,"label"),"{fig:",label,"}",sep="")
	out.list[[5]] <- paste(pastes(dash.char,"end"),"{figure}")
	
	out.list.2 <- paste(c("",unlist(out.list),""),"\n")
						   
	return(out.list.2)
	
}

##########################################################

Table2Latex <- function(table.out,rownamer=NULL,colnamer=colnames(table.out)){
	
	table.out2 <- table.out
	
	if(!is.null(rownames(table.out))){
	
	table.out2 <- cbind(rownames(table.out),table.out)
	colnames(table.out2) <- c(ifelse(is.null(rownamer),"",rownamer),colnames(table.out))
		
	}
	
	return(table.out2)
	
}

##########################################################

latex.out.table.2 <-
function(table,
file=NULL,
caption = "",
label = "",
rownamer = NULL,
col.label=NULL){
	
	table0 <- Table2Latex(table,rownamer=rownamer)
	
	table <- xtable(table0)
	caption(table) <- caption
	align(table) <- c("l", "l", rep("c", dim(table)[2] - 1))
	label(table) <- label
	
	temp <- print(table, 
				  type = "latex", 
				  include.rownames = FALSE, 
				  caption.placement = getOption("xtable.caption.placement", "top"))
	
	temp2 <- unlist(strsplit(temp,split="\n"))
	
	split.point <- grep("begin\\{tabular\\}",temp2)
	
	header.add <- NULL
	
	if(!is.null(col.label)){
		
		header.add <- c("\\hline",paste("&",col.label,paste(rep("&",dim(table)[2] - 2),collapse=" "),"\\\\",collapse=""))
		
	}
	
	temp3 <- c(temp2[1:split.point],header.add,temp2[(split.point+1):length(temp2)])
	
	if(!is.null(file)){write(temp3,file)}
	
	
	return(temp3)
	
}

##########################################################

latex.out.table <-
function(table,
file,
caption = "",
label = "",
rownamer = NULL,
col.label=NULL){
	
	table0 <- Table2Latex(table,rownamer=rownamer)
	
	table <- xtable(table0)
	caption(table) <- caption
	align(table) <- c("l", "l", rep("c", dim(table)[2] - 1))
	label(table) <- label
	
	temp <- print(table, 
		  type = "latex", 
		  include.rownames = FALSE, 
		  caption.placement = getOption("xtable.caption.placement", "top"))
	
	temp2 <- unlist(strsplit(temp,split="\n"))
	
	split.point <- grep("begin\\{tabular\\}",temp2)
	
	header.add <- NULL
	
	if(!is.null(col.label)){
		
		header.add <- c("\\hline",paste("&",col.label,paste(rep("&",dim(table)[2] - 2),collapse=" "),"\\\\",collapse=""))
	
	}
	
	temp3 <- c(temp2[1:split.point],header.add,temp2[(split.point+1):length(temp2)])
	
	write(temp3,file)
	
	
	return(temp3)
	
}

##########################################################

lcat <- function(old,appender){
	
# appends a object appender to a list
	
	
	
	if(length(old)==0){old <- list(appender)}else{
		old[[length(old)+1]] <- appender
	}
	
	return(old)
	
}  #END: lcat

##########################################################

pastes <- function(x,y) {return(paste(x,y,sep=""))}

##########################################################

spawnDirectory <- function(dirname){
	if(.Platform$OS.type=="unix"){
		temp <- try({temp2 <- system(paste("mkdir",dirname))})
	}
}

##########################################################

simple.multi.table2 <- function(resultsdir,resultsdir.sas, shared.dir, outfileName,rtfout,inclusion.vector,close.ods=TRUE,orientation="landscape",title="Multitable",operate=0,fontsize=NULL){
	
#	Makes multiple Tables using previously generated Include statements in inclusion vector
#   Generates the SAS code
#   writes to rtfout within directory resultsdir.sas
	
	sasdir <- "C:/Program Files/SASHome/SASFoundation/9.3/"
	
	outfile <- paste(resultsdir,outfileName,".sas",sep="")
		
	outfileSas <- paste(resultsdir.sas,outfileName,".sas",sep="")
	
	rtffile.sas <- paste(resultsdir.sas,rtfout,sep="")
	
	stylepath <- paste(shared.dir,sep="")
		
	temp2 <- ods.start2(rtffile.sas,stylepath,orientation=orientation,title=title,fontsize=fontsize)
	write(temp2,file=outfile,append=FALSE)
		
	write(paste(inclusion.vector,"\n"),file=outfile,append=TRUE)	
	
	if(close.ods){	
		
		temp3 <- ods.close()
		write(temp3,file=outfile,append=TRUE)
		
	}
	
	sas.command <- sas.batch(sasdir,outfileSas,operate=0)
	
	return(sas.command)
	
} #END: Simple Multi Table2

##########################################################

feature.table.n2 <- function(resultsdir,resultsdir.sas,shared.dir,table.id,data.matrix,title1="Summary Tables",title3=NULL,columnLabels=NULL,headerStatement=NULL,footnoteJust=NULL,cellwidth=NULL,fontsize=NULL,
                                                                      col.labels = NULL, orientation = "portrait",span.head = NULL, just.matrix = NULL, indent = 0){
	
#   Writes the data matrix to file
#   Generates the SAS code
#   Generates include statement

# resultsdir = path for R to write the sas/csv files
# resultsdir.sas = path for SAS to read the sas/csv files
# table.id = Name for data table within sas & file system
# data.matrix = rectangular data to be in table
# column labels = vector of columnLabels
# headerStatement = sas column statement for nesting columns or selecting subsets of columns
# footnoteJust = 2 column matrix with [footnotes, justifications]
		
	sasdir <- "C:/Program Files/SAS/SASFoundation/9.3/"  # Default SAS directory in Windows
	
	# Define output files
	
	outbase <- paste("tableMaker_",table.id,".sas",sep="")  # Where R should write SAS file
	outfile <- paste(resultsdir,outbase,sep="")				# Where SAS should read the SAS file
	datafile <- paste(resultsdir,"tableMaker_",table.id,".csv",sep="")  # Where R should write the data file	
	datafile.sas <- paste(resultsdir.sas,"tableMaker_",table.id,".csv",sep="")  # Where SAS should read the data file
	
	# Export the data to a CSV file
	
	export.2.csv(datafile,data.matrix)

	# Specify path of Style file
	
	stylepath <- paste(shared.dir,sep="")
		
	# Construct SAS import Statement
		
	temp1 <- procImport.simple2(datafile.sas,fontsize=fontsize,orientation=orientation)
	
	write(temp1,file=outfile,append=FALSE)
		
	# Add columnLabels
	
	namer <- colnames(data.matrix)
	
	if(!is.null(columnLabels)){
		temp1b <- dataDefine2("data1",cbind(namer,columnLabels),col.labels = col.labels, indent = indent)
		write(temp1b,file=outfile,append=TRUE)
	}
		
	# Initialize proc report
	
	temp2 <- procReport.start2(fontsize=fontsize)
	write(temp2,file=outfile,append=TRUE)
	
	# Specify Proc Report Title
	temp3 <- procReport.title2(titletext=title1,titlenumber="1",justification="center",fontsize=fontsize)
	write(temp3,file=outfile,append=TRUE)	
	if(!is.null(title3)){
	  temp3 <- procReport.title2(ifelse(is.null(title3),table.id,title3),fontsize=fontsize)
	  write(temp3,file=outfile,append=TRUE)
	}
	
	# Add headerStatement
	if(!is.null(headerStatement)){
		temp3a <- paste("column",headerStatement,";\n")
		write(temp3a,file=outfile,append=TRUE)
	}
	
  font.size <- ifelse(is.null(fontsize), "", paste("fontsize=", as.character(fontsize), "pt", sep = ""))

  # Create spanning headers
  if(!is.null(span.head)){
    column <- "column"
    pos <- 1:length(span.head)
    span.num <- as.numeric(factor(span.head, levels = unique(span.head)))
    # fix for multiple blanks in spanning header #
    counter <- 1
    new.span.num <- 1
    for(index in 2:length(span.num)) {
      if(span.num[index] != span.num[index - 1]) counter <- counter + 1
      new.span.num <- c(new.span.num, counter)
    }
    span.num <- new.span.num
    for(index in unique(span.num)){
      index.pos <- pos[span.num == index]
      heading.vars <- paste("'", span.head[span.num == index][1], "'", sep = "")
      for(pos_index in index.pos){
        if(namer[pos_index] != "indent") # added 30 May 2013
          heading.vars <- paste(heading.vars, namer[pos_index]) 
      }
#      heading.vars <- heading.vars[heading.vars != "indent"] # added 30 May 2013
    column <- paste(column, "(", heading.vars, ")", sep = " ")       
    }
    temp3ba <- paste(column, ";\n", sep = "")
    write(temp3ba,file=outfile,append=TRUE)
  }

	# Add columnLabels
	temp3b <- NULL
  if(!is.null(columnLabels)){
	  for(name_index in 1:length(namer)){
  		  cell.width <- ifelse(is.null(cellwidth) || is.na(cellwidth), "", paste("cellwidth=", as.character(cellwidth[name_index]), "in", sep = ""))
  		  if(name_index == length(namer)){
  		  
  		  } else {
            if(is.null(just.matrix)){
                if(name_index == 1){
         	  	      temp3b.row <- paste("define",namer[name_index],"/display", " STYLE(COLUMN)={asis=on PROTECTSPECIALCHARS=off", cell.width, font.size, "just=l} STYLE(header)={asis=on", cell.width, font.size, "just=c}",";\n")
  	          	} else {
                    temp3b.row <- paste("define",namer[name_index],"/display", " STYLE(COLUMN)={asis=on PROTECTSPECIALCHARS=off", cell.width, font.size, "just=c} STYLE(header)={asis=on", cell.width, font.size, "just=c}",";\n")
	    	        }
            } else {
                temp3b.row <- paste("define",namer[name_index],"/display", " STYLE(COLUMN)={asis=on PROTECTSPECIALCHARS=off", cell.width, font.size, "just=", just.matrix[name_index,2], "} STYLE(header)={asis=on", cell.width, font.size, "just=", just.matrix[name_index,1], "}",";\n")
            }
           
	         temp3b <- c(temp3b, temp3b.row)
        }
    }
		write(temp3b,file=outfile,append=TRUE)
	}
	
	# Add footnotes
	
	if(!is.null(footnoteJust)){
		footers <- procReport.footnote(footnote=footnoteJust[,1],justification=footnoteJust[,2],font.size=fontsize) # footnote="This is footnote",justification="left"
		write(footers,file=outfile,append=TRUE)
	}
	
	# Exit proc report
	
	temp3 <- procReport.quit()
	write(temp3,file=outfile,append=TRUE)
		
	# Contruct include command	
	
	include.command <- paste("%include ","\"",resultsdir.sas,outbase,"\";",sep="")
	
	return(include.command)
	
} #END: Feature Table.n2

##########################################################

dataDefine2 <- function(dataname,labels,col.labels = NULL, indent = 0){
	
	# Creates labels for variables within the dataname
	# labels = column 1 is the variable name column 2 is the label title
	
	outvec <- rep("",3)

	outvec[1] <- "/* Stard data define */ \n"
	outvec[2] <- paste("data",dataname,"; \n")                   
	outvec[3] <- paste("   set",dataname,"; \n")
#	outvec[4] <- paste("if indent NE 0 then ", labels[1], " = '   ' || ", labels[1], "; \n")
  indent.label <- "\" \" || "
  for(index in 1:(indent - 1)){ indent.label <- paste(indent.label, "\" \" ||", sep = " ")}
	outvec[4] <- paste("if indent NE 0 then ", labels[1], " = ", indent.label, labels[1], "; \n", sep = "")
	# in gsubs: '__' was to protect factor names with leading numbers, the '_' was to protect factor names with spaces
  if(!is.null(col.labels)){
    labelstatements <- paste("LABEL",labels[,1],"=",paste("\"", col.labels, "\"", sep = ""),"; \n")
  } else {  
    labelstatements <- paste("LABEL",labels[,1],"=",paste("'", gsub("_", " ", gsub("__", "", gsub("_1_", "&", gsub("_2_", "@",  
                    gsub("_3_", "#", gsub("_d_", "$", gsub("_4_", "%", gsub("_5_", "!", gsub("_u_", "^", gsub("_s_", "*", 
                    gsub("_o_", "(", gsub("_c_", ")", gsub("_6_", ".", gsub("_7_", "{", gsub("_8_", "}", gsub("_9_", "-", labels[,2])))))))))))))))),"'",sep=""),"; \n")	
	}
  outvec <- c(outvec,labelstatements)	
	outvec <- c(outvec,paste("drop indent; \n"))
	outvec <- c(outvec,"run; \n /* Start data define */ \n")
	return(outvec)
	
} #END: dataDefine2

##########################################################

convert2char <- function(x){

	for(i in 1:(ncol(x))){

		x[,i] <- as.character(x[,i])

	}

	return(x)

}#END: conver2char

##########################################################

ods.start2 <- function(docpath,stylepath,style="styles.LPG_SM_LZ",orientation="landscape",title="RSAS_Tab",style.file="LPG2_STYLE_SMALL_MARGIN_LZ.sas",fontsize = NULL){
	
	# generates a char vector to initiate 
	# ods creation of an RTF file 
	# docpath = document file path
	# orientation = landscape/portrait
	# stylefile = file path to 	
	
	outvec <- rep("",5)

  outvec[1] <- paste("%let macrodir=",stylepath,";",sep="");
	outvec[2] <- paste("%include",paste("\"",stylepath,style.file,"\"",sep=""),";")
	outvec[3] <- paste("%include",paste("\"",stylepath,"macro_020409.sas\"",sep=""),";")
	outvec[4] <- "ods escapechar='^';"
  outvec[5] <- ""
	outvec[6] <- paste("options nodate number", ";")
	style <- ifelse(is.null(fontsize), style, "SmallFont")
  outvec[7] <- paste("ods rtf body=",paste("\"",docpath,"\"",sep="")," style=",style ,"bodytitle", "startpage = YES;")	
  height <- ifelse(is.null(fontsize), "", paste(" height = ", fontsize, "pt ", sep = ""))
  outvec[8] <- paste("title1 justify = center", height, "\"",title,"\";",sep="")
	
	
	outvec <- c(outvec,"\n");
	
	return(outvec)
	
} # END: ods.start2
  
##########################################################  	
	
ods.close <- function(){
	
	# Returns the closure for the ods statment
	
	outvec <- rep("",2)

	outvec[1]  <-"ods rtf close;"

	outvec[2]  <-"quit;"
	
	return(outvec)
	
} #END: ods.close
	
##########################################################

procReport.start2 <- function(dataname="data1",panels=FALSE,fontsize=NULL){

	# Contruct the proc report header statement
	# dataname = dataset name

	outvec <- rep("",10)

	outvec[1] <- "proc report" 
	outvec[2]	<-	paste("data=",dataname,sep=" ") 
	outvec[3]	<-		"headline"
	outvec[4]	<-		"headskip" 
	outvec[5]	<-		"missing" 
	outvec[6]	<-		"nowd" 
	outvec[7]	<-		"split='@'" 
	outvec[8]	<-		"spacing=0 ls=200"
   outvec[9]  <-     "style(header column)=[protectspecialchars=off background=white]"
   outvec[10]  <-     "Style(report)={borderwidth=1pt cellspacing=0pt cellpadding=2pt vjust=bottom}" 
   if(!is.null(fontsize)) {
     outvec[11]  <-      paste("STYLE(HEADER)={ PROTECTSPECIALCHARS=off fontsize=", fontsize, "pt just = c };", sep = "")
   } else {
     outvec[11]  <-      "STYLE(HEADER)={ PROTECTSPECIALCHARS=off just = c };"
   }         
   outvec2     <-    ifelse(panels, "where panel ne 0;","")

	outvec <- paste(outvec,collapse="\n")
	
	outvec <- c("/* BEGIN: procReport.start2 */","\n",outvec,outvec2,"/* END: procReport.start */","\n")
	
	return(outvec)
	
	} #END: procReport.start2	

##########################################################

procReport.title2 <- function(titletext="Data1",titlenumber="3",justification="center",fontsize = NULL){
	
	# Constructs the title statement
	
	start <- paste("title",titlenumber,sep="")
	
	just <- paste("justify=",justification,sep="")
	
	size <- ifelse(is.null(fontsize), "", paste("height = ",fontsize,"pt",sep=""))
	
	titletext <- paste("\"",titletext,"\"",sep="")
	
	outvec <- paste(start,just,size,titletext,";",sep=" ")
	
	outvec <- c("/* BEGIN: procReport.title2 */","\n",outvec,"/* END: procReport.title2 */","\n");
	
	return(outvec)
	
	} #END: procReport.title2

##########################################################

procReport.footnote <- function(footnote="This is footnote",justification="left",font.size=fontsize){ # fontsize option added 12 Feb 2013
	
	# Generate a footnote for procReport
	#  footnote1 j=lFeft "^{super 1}F Test";
	
	nfoot <- length(footnote)
	njust <- length(justification)
	
	feet <- paste("\"",footnote,"\"",sep="")
	
	justs <- rep(justification,nfoot/njust)
	
	starts <- paste("footnote",1:nfoot," ",sep="")

	outvec <- paste(starts,"j=",justs,ifelse(font.size == "", "", paste(" height=",font.size,'pt ', sep = "")), '\"',footnote,'\" ;',sep="")
	
	outvec <- c(outvec,"\n");
	
	return(outvec)
	
	}	# END procReport.footnote
	
##########################################################
	
export.2.csv <- function(filename,data){
	
	# Simplifies the export to a csv file
	# data = a CHARACTER matrix, 1st row are column names [NOT?]

	maxes <- apply(nchar(data),2,max)

	ncols <- length(maxes)

	datarow1 <- rep("",ncols)

	for(i in 1:ncols){
		datarow1[i] <- paste(rep("a",maxes[i]),collapse="")

	} # loop over i

	cnames <- colnames(data)

	data <- rbind(datarow1,data)

	colnames(data) <- cnames
	
	write.table(data,filename,quote=TRUE,row.names=FALSE,col.names=TRUE,sep=",")
	
	return(NULL)
	
	} #END: export.2.csv	

##########################################################

procReport.quit <- function(){

	# Returns the closure for the proc report statment
	
	outvec <- rep("",3)
	
	outvec[1] <- "run;"
	outvec[2]  <- "footnote;"
	
	outvec[3]  <-"title;"
	
	return(outvec)

}#END: procReport.quit

##########################################################
	
sas.batch <- function(sasdir,sasprog,sas.options="",operate=0){

#: C:\SAS\SAS.EXE -SYSIN C:\SAS\PROGRAMS\PROG1.SAS -CONFIG C:\SAS\SASV9.CFG

	command1 <- paste("\"",sasdir,"sas.exe\" -SYSIN",sep="")

	comand1 <- gsub("/","\\",command1)

	command.config <- paste("-CONFIG",paste("\"",sasdir,"SASV9.CFG\"",sep=""))

	comand.config <- gsub("/","\\",command.config)

	logfile <- paste("-Log \"",gsub("\\.sas$","\\.log",sasprog),"\"",sep="")

	lstfile <- paste("-Print \"",gsub("\\.sas$","\\.lst",sasprog),"\"",sep="")

	sasprog <- paste("\"",sasprog,"\"",sep="")

	command.full <- paste(command1,sasprog,command.config,lstfile,logfile,sas.options,collapse=" ")

	if(operate>0) {system(command.full)}

	return(command.full)
	
} #END: sas.batch

##########################################################
if(FALSE){	   #Needs to be created
latex.batch <- function(sasdir,sasprog,sas.options="",operate=0){

#: C:\SAS\SAS.EXE -SYSIN C:\SAS\PROGRAMS\PROG1.SAS -CONFIG C:\SAS\SASV9.CFG

	command1 <- paste("\"",sasdir,"sas.exe\" -SYSIN",sep="")

	comand1 <- gsub("/","\\",command1)

	command.config <- paste("-CONFIG",paste("\"",sasdir,"SASV9.CFG\"",sep=""))

	comand.config <- gsub("/","\\",command.config)

	logfile <- paste("-Log \"",gsub("\\.sas$","\\.log",sasprog),"\"",sep="")

	lstfile <- paste("-Print \"",gsub("\\.sas$","\\.lst",sasprog),"\"",sep="")

	sasprog <- paste("\"",sasprog,"\"",sep="")

	command.full <- paste(command1,sasprog,command.config,lstfile,logfile,sas.options,collapse=" ")

	if(operate>0) {system(command.full)}

	return(command.full)
	
} #END: latex.batch
}
##########################################################
	
procImport.simple2 <- function(datafile,dataset="data1",fontsize = NULL,orientation = "portrait"){

	#imports the data into SAS
	#from CSV format

	outvec <- rep("",11)

  outvec[1] <- ""
  outvec[2] <- ""
  outvec[3] <- ""

#   outvec[3] <- paste("ods pdf startpage=now; options orientation=", orientation, ";", sep = "")

  	outvec[4] <- "PROC IMPORT" 
	outvec[5] <- paste("OUT=WORK.",dataset,sep="") 
	outvec[6] <- paste("DATAFILE=", "\"",datafile,"\"",sep="")           
	outvec[7] <- "DBMS=CSV REPLACE; GUESSINGROWS = 500;"
      outvec[8] <- "GETNAMES=YES;"
      outvec[9] <- "DATAROW=2;"
	outvec[10] <- "RUN;"

	# Remove the 1st row of character lengths
	
	outvec[11] <- paste("data work.",dataset,";",sep="")
	outvec[12] <- paste("set work.",dataset,";",sep="")
	outvec[13] <- "if _n_ = 1 then delete;"

	outvec <- c(outvec,"run;\n");

	return(outvec)

} #END: procImport.simple2



