# Standard Error of a binomial proportion

binom.se <- function(x, n){
   if(x > n | x < 0 | n == 0){
      print("You can't give more than 100%")
      return(NA)
   }
   p <- x/n
   se <- sqrt((p*(1 - p))/n)
   return(se)
}

