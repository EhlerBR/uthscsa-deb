### Takes a vector/matrix/df/character and returns a logical vector describing which elements of the vector are blank ###
# na.blank: logical that determines the output of NA elements; is.blank(NA, na.blank = T) returns TRUE; is.blank(NA, na.blank = F) returns NA

is.blank <- function(data, na.blank = TRUE){ # Changed to TRUE 25 Feb 2013
if(is.data.frame(data)) data <- as.matrix(data)
if (is.vector(data) | is.factor(data)){
  data <- as.character(data)
  nrow <- 1
} else nrow <- dim(data)[1]
vector.data <- !is.matrix(data)
  blank.mat <- NULL
  
  for(row_index in 1:nrow){
    blank.vec <- NULL
    if(is.vector(data)) vector <- data
    else vector <- data[row_index,]
    
    for(vec_index in 1:length(vector)){
      if(!is.na(vector[vec_index])){
        x <- vector[vec_index]
        counter <- 0
        
        for(char_index in 1:nchar(x)){
          if(substr(x, char_index, char_index) == " ") counter <- counter + 1
        }
        
        blank <- (counter == nchar(x))
      } else {
        if(na.blank) blank <- TRUE
        else blank <- NA
      }
      blank.vec <- c(blank.vec, blank)
    }
    
    blank.mat <- rbind(blank.mat,blank.vec)
  }
  if(vector.data) blank.mat <- c(blank.mat)
  return(blank.mat)
}

### EOF ###
