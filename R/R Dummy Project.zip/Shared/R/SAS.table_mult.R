##############################################################################
# University of Texas Health Science Center at San Antonio
# Department of Epidemiology and Biostatistics                        
##############################################################################
# Filename: analyze_gear_v0.1.R
# Author:              Jonathan Gelfond                                   
# Project Name:          Hemsell
# Input:                  VancHetaBin Cleanish dwh.xlsx    & pre-data.xlxs
# Output: 
#
# Modification History:
# v 0.1 Creation                              
##############################################################################
#
# Modified by: Benjamin Ehler
# Date: May 31, 2012
# SAS.table.R
#
##############################################################################

# Takes a data frame (or the list that is created by summarize.data.frame) and creates a ProcReport directory and file and then runs it to create an rtf file

SAS.table_mult <- function(data.table, filename, table.name = "test_table", title1 = filename, title3 = NULL, summ.df = TRUE, table.num = 1, last = TRUE, 
                      table.list = NULL,  before.footnote = NULL, after.footnote = NULL, orientation = "portrait", col.labels = NULL, span.head = NULL, 
                      cellwidth = NULL, page.room = NULL, fontsize = NULL, just.matrix = NULL, log.pval = FALSE, log.base = "natural",
                      stylepath = "shared", output.loc = documents.dir){ 
                      
# summ.df: TRUE if table was created by summarize.data.frame; affects footnotes
# table.num: If multiple tables, the current table number
# last: False if table is not the last table to be written of multiple tables
# table.list: If table.num > 1, object that the previous SAS.tables were written to
# before.footnote: vector of quoted strings which will appear in order before the test footnotes
# after.footnote: vector of quoted strings which will appear in order after the test footnotes
# col.labels: Vector of column names (does not include row, panel, or test) for a blank label, assign "@"
# span.head: Vector with same length as column names (does not include row, panel, or test); put "" for columns with no spanning header and repeat values
#                              over all columns that share the header [ex: c("", "Baseline", "Baseline", "6 Months", "6 Months", "", "")] 
# cellwidth: numeric vector of cell.widths (in.) in the order of the column labels (Label, factor1, ... ,factorn, total, pvalue)
# fontsize: alters overall font of table (changes style to one where footnote and title sizes are also changed accordingly)
# page.room: alters length of page before creating page break in pagination function (NULL value puts in estimated length according to orientation and number of footnotes)
# just.matrix: matrix with the first column representing the justifications of the headers of the variables and the 2nd column is the justifications of the body of the variables 
# log.pval: changes ONLY FOOTNOTES of tests: DOES NOT CHANGE THE ACTUAL P-VALUES!
# log.base: if log.pval, will change footnote to reflect the base of the log transform
# shared.loc: file path where 'LPG2_STYLE_SMALL_MARGIN_LZ.sas' is located.  If stylepath = "shared", function uses the user-defined, 'root'
# output.loc: file path where the results are written

########## CAN TAKE TABLE FILE OR LIST WITH TABLE (FROM SUMMARIZE.DATA.FRAME) ############
if(is.list(data.table)) if(!is.null(data.table$table)) data.table <- data.table$table
data.table <- as.data.frame(data.table)

date <- format(Sys.time(), "%d %b %Y")

########## FIX SYMBOLS IN COLUMN NAMES ############
colnames(data.table) <- gsub(" ", "_", colnames(data.table))
colnames(data.table) <- gsub("&", "_1_", colnames(data.table))
colnames(data.table) <- gsub("@", "_2_", colnames(data.table)) # skips a line
colnames(data.table) <- gsub("#", "_3_", colnames(data.table))
colnames(data.table) <- gsub("%", "_4_", colnames(data.table))
colnames(data.table) <- gsub("!", "_5_", colnames(data.table))
colnames(data.table) <- gsub("\\.", "_6_", colnames(data.table))
colnames(data.table) <- gsub("\\{", "_7_", colnames(data.table))
colnames(data.table) <- gsub("\\}", "_8_", colnames(data.table))
colnames(data.table) <- gsub("-", "_9_", colnames(data.table))

########## FIX LEADING NUMBERS IN COLUMN NAMES ############
for(col_index in 1:length(colnames(data.table))){
  if(!is.na(suppressWarnings(as.numeric(substr(colnames(data.table)[col_index],1,2))))){  # warnings show conversion to NA, can ignore #
    colnames(data.table)[col_index] <- paste("__", colnames(data.table)[col_index], sep = "")
  }
}

########## SET UP DIRECTORIES ############                                                                    
sourceFileClip <- paste("Results_ProcReport (", date, ")", sep = "")
resultsdir <- paste(output.loc,sourceFileClip,sep="")
resultsdir.r2sas <- pastes(resultsdir,"/")
resultsdir.sas <- resultsdir.r2sas

########## ASSIGN LOCATION OF STYLE FILE ############ 
shared.sas.loc <- paste(root, "Shared/SAS/", sep = "")
stylepath.dir <- ifelse(stylepath == "shared", shared.sas.loc, stylepath)

########## CREATE DIRECTORY FOR ALL FILES AND OUTPUT ############
# Works for windows #
suppressWarnings(dir.create(resultsdir.sas))  # Warning occurs when directory already exists.  Still creates files

########## CONVERT ALL COLUMNS TO CHARACTER ############
data.table <- convert2char(data.table)
data.table[is.na(data.table)] <- ""

########## CHECK FOR INDENTED LABELS ##########
data.table$indent <- 0
for(row_index in 1:dim(data.table)[1]){
  counter <- 1
  for(index in 1:10){
    if(substr(data.table[row_index,1], counter, counter) == " "){
      counter <- counter + 1
    } else {
      break
    }
  }
  data.table$indent[row_index] <- counter - 1
}
indent <- max(data.table$indent, na.rm = TRUE)

########## FORMAT FOOTNOTES ADDED BEFORE THE FOOTNOTES FOR TESTS ##########
pre.footer <- NULL
if(!is.null(before.footnote)){
  for(foot_index in 1:(length(before.footnote))){
     footnote.row <- c(paste("^{super ", foot_index, "}",before.footnote[foot_index], sep = ""), "l") 
     pre.footer <- rbind(pre.footer, footnote.row)
  }
}
total.footnote <- pre.footer

if(summ.df){
  ########## CREATE FOOTNOTES FOR TESTS ##########
  log.base <- ifelse(log.base == "natural", "", paste("^{sub ", log.base, "}", sep = ""))
  log.pval.label <- ifelse((!log.pval), "", paste(" on log", log.base, " transformed values", sep = ""))
  tests <- unique(as.character(data.table$test))
  n.pre.footer <- dim(total.footnote)[1]
  if(is.null(n.pre.footer)) n.pre.footer <- 0
  n.tests <- length(tests)
  n.factor <- length(names(data.table[!names(data.table) %in% c("Label", "Total", "Pval", "row", "panel", "test")])) # lists number of factors of outcome variable
  test.list <- NULL
  for(test_index in 1:n.tests){
        
    adj.method.create <- strsplit(tests[test_index], " ")[[1]][2:length(strsplit(tests[test_index], " ")[[1]])]
    adj.method <- NULL
    for(index in 1:length(adj.method.create)) adj.method <- paste(adj.method, adj.method.create[index])
    if(is.blank(substr(adj.method, 1, 1))) adj.method <- substr(adj.method, 2, nchar(adj.method))

    if(!is.null(adj.method)) substr(adj.method, 1, 1) <- toupper(substr(adj.method, 1, 1))
    adjustment <- ifelse(length(grep(" ", tests[test_index])) == 1, paste(" with ", adj.method, " correction", sep = ""), "")
    footer_index <- n.pre.footer + test_index
    if(length(grep("chisq", tests[test_index])) == 1) test.list[[test_index]] <- paste("^{super ", footer_index, "}Pearson's Chi-squared test", log.pval.label, adjustment, sep = "")
    if(length(grep("fisher", tests[test_index])) == 1) test.list[[test_index]] <- paste("^{super ", footer_index, "}Fisher's exact test", log.pval.label, adjustment, sep = "")
    if(length(grep("anova", tests[test_index])) == 1) test.list[[test_index]] <- paste("^{super ", footer_index, "}t-test", log.pval.label, adjustment, sep = "")
    if(tests[test_index] == "kw"){
      if(n.factor > 2) test.list[[test_index]] <- paste("^{super ", footer_index, "}Kruskal-Wallis test", log.pval.label, sep = "")
      else test.list[[test_index]] <- paste("^{super ", footer_index, "}Mann-Whitney U test", log.pval.label, sep = "") # This could produce problems if table columns are manually deleted    
    }
    if(tests[test_index] == "mannU") test.list[[test_index]] <- paste("^{super ", footer_index, "}Mann-Whitney U test", log.pval.label, sep = "") 
  } 

  ########## FORMAT FOOTNOTES TO FIT FEATURE.TABLE.N FUNCTION AND MERGE WITH BEFORE.FOOTNOTE ##########
  for(test_index in 1:n.tests){
    footer_index <- n.pre.footer + test_index
    for(row_index in 1:dim(data.table)[1]){
      if(data.table$Pval[row_index] != ""){
        if(data.table$test[row_index] == tests[test_index]) data.table$Pval[row_index] <- paste(data.table$Pval[row_index], "^{super ", footer_index, "}", sep = "")
      }
    }
  }
  footnote.tests <- matrix(c(test.list, rep("l", n.tests)), ncol = 2, byrow = FALSE)
  total.footnote <- rbind(total.footnote, footnote.tests)
  
  ########## FORMAT FOOTNOTES ADDED AFTER THE FOOTNOTES FOR TESTS AND MERGE ##########
  n.other.footnotes <- dim(total.footnote)[1]
  add.footnote <- NULL
  if(!is.null(after.footnote)){
    for(foot_index in (n.other.footnotes + 1):((n.other.footnotes + length(after.footnote)))){
       footnote.row <- c(paste("^{super ", foot_index, "}",after.footnote[foot_index - n.other.footnotes], sep = ""), "l") 
       add.footnote <- rbind(add.footnote, footnote.row)
    }
  } 
  total.footnote <- rbind(total.footnote, add.footnote)
  
  ########## ASSIGN PVALUE COLUMN ############
  pval.location <- grep("Pval", colnames(data.table))
  
  ########## ASSIGN COLUMN LABELS AND CHANGE COLNAME FROM PVAL TO P-VALUE ##########                                 
  colLabels <- colnames(data.table)[1:pval.location]
  colLabels[pval.location] <- "P-value"
  col.length <- pval.location
  
} else { # if(!summ.df)
  col.length <- length(colnames(data.table))
  colLabels <- colnames(data.table)
}
 
if(is.null(data.table$page)){  
########## IF PAGE.ROOM IS NULL, SET DEFAULTS ACCORDING TO ORIENTATION AND NO. OF FOOTNOTES ##########
if(is.null(page.room)){
  if(orientation == "landscape") total.page.room <- 24
  if(orientation == "portrait") total.page.room <- 37
  
  page.room <- total.page.room - max(dim(total.footnote)[1], 0)
}

if(!is.null(span.head)) page.room <- page.room - 1

########## PAGINATE TABLE AND CREATE PAGE/PANEL COLUMNS ##########
if(is.null(data.table$panel)){
  data.table$panel <- 1
  with.panel <- TRUE
} else {
  with.panel <- FALSE
}
data.table <- paginate(data.table, data.table$panel, page.room)$table 
}
  
########## IF PANELS WERE PUT IN MANUALY, EXCLUDES THE PANEL COLUMN FROM OUTPUT ##########
if(!summ.df & !with.panel) {
  data.table <- data.table[,names(data.table) != "panel"]
  col.length <- col.length - 1
}

########## DELETES LAST ROW OF PAGE IF BLANK ##########
blank.limit <- ifelse(summ.df, pval.location, 2) # the '2' can change depending on needs
blank.row <- NULL
for(row_index in 2:dim(data.table)[1]){
  if(data.table$page[row_index] != data.table$page[row_index - 1]) {
    if(sum(is.blank(data.table[row_index - 1,1:blank.limit], na.blank = TRUE)) == blank.limit){
      blank.row <- c(blank.row, (row_index-1))
    }
  }
}
last.row <- dim(data.table)[1]
if(sum(is.blank(data.table[last.row,1:blank.limit], na.blank = TRUE)) == blank.limit)  blank.row <- c(blank.row, dim(data.table)[1])
if(!is.null(blank.row)) data.table <- data.table[-blank.row, ]

########## RUN FEATURE.TABLE.N WHICH WRITES CODE AND INCLUDE STATEMENTS IN SAS FILE ##########
if(table.num == 1){
  table.list <- NULL
} else { 
  table.list <- table.list
}                                                       

if(!is.null(fontsize)){
  table.list <- c(paste("Proc template; Define style SmallFont",table.num,"; Parent = Styles.LPG_SM_LZ; Style SystemFooter from systemFooter / Font = ('Arial', ", fontsize, "pt); End; Run;", sep = ""), table.list)
}

line1 <- paste("ods escapechar='^'; options nodate number orientation = portrait;", sep = "")
  font <- ifelse(is.null(fontsize), "styles.LPG_SM_LZ", paste("SmallFont",table.num, sep = ""))
  line2 <- paste("ods rtf style = ", font, " startpage = YES;", sep = "")
  line3 <- paste("options orientation = ", orientation, "; ods rtf;", sep = "")
  
table.list <- c(table.list, line1, line2, line3)

extra.index <- length(table.list)
indent.index <- ifelse(summ.df, dim(data.table)[2]-1, 0)
if(summ.df){
  colLabels <- c(colLabels[1:col.length], "indent")
  if(!is.null(col.labels)) col.labels <- c(col.labels, "indent")  
} else {
  colLabels <- colLabels[1:col.length]
}
for(page_index in unique(data.table$page)){
  if(page_index == 2 & !is.null(title3)) title3 <- paste(title3, " (cont'd)", sep = "")
  table.list[[as.character(as.numeric(page_index) + extra.index)]] <- feature.table.n2(resultsdir.r2sas,resultsdir.sas, stylepath.dir, paste(table.name, "_", page_index, sep = ""), 
                                      as.matrix(data.table[data.table$page==page_index, c(1:col.length,indent.index)]), title1 = title1, title3=title3, columnLabels=colLabels, footnoteJust=total.footnote,
                                      cellwidth = cellwidth, fontsize = fontsize, col.labels = col.labels, orientation = orientation, span.head = span.head, just.matrix = just.matrix, indent = indent)                                      
}

########## RUN SIMPLE.MULTI.TABLE WHICH COMBINES TABLES (DIFF. PAGES OF ALL TABLES) AND CREATES THE RTF FILE ##########
if(last){
  summaryTablesTable4SAS <- simple.multi.table2(resultsdir = resultsdir.r2sas, resultsdir.sas = resultsdir.sas, stylepath.dir, outfileName = filename,
                             rtfout = paste(filename, ".rtf", sep = ""), inclusion.vector = unlist(table.list), close.ods=TRUE, orientation=orientation, 
                             title = title1, operate = 0, fontsize = fontsize)
  
  system(summaryTablesTable4SAS)   # RUN CODE THROUGH THE SYSTEM #
 
} else {
  return(table.list)
}  

} 

### END OF SAS.table FUNCTION ###





### DEFAULTS TO RUN DEBUG TESTS ###

if(FALSE){

table.name = "test_table"
title1 = filename
title3 = NULL
summ.df = TRUE
table.num = 1
last = TRUE
table.list = NULL
before.footnote = NULL
after.footnote = NULL
orientation = "portrait"
col.labels = NULL
span.head = NULL
cellwidth = NULL
page.room = NULL
fontsize = NULL
just.matrix = NULL
log.pval = FALSE
log.base = "natural"
stylepath = root
output.loc = documents.dir

}

### EOF ###