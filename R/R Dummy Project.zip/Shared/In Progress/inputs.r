### TEST INPUTS
actual <- rep(c("Alive", "Dead"), 50)
predicted <- c(rnorm(50), rnorm(50, 1))
predicted <- (predicted - min(predicted))/(max(predicted) - min(predicted))
cut <- 0.5
 event = "Dead"; group.names = c("Alive", "Dead");
                                alpha = 0.05; ci.type = "bayes";
                                roc = TRUE; roc.filename = "roc"; roc.filetype = "png";
                                roc.main = ""; roc.lwd = 2; roc.lty = 1; roc.col = "black";
                                roc.abline.lwd = 2; roc.abline.lty = 1; roc.abline.col = "red";
                                roc.auc.pos = c(); roc.auc.cex = 1; roc.auc.adj = c(1, 1);
                                net = TRUE; net.filename = "net.benefit"; net.filetype = "png";
                                cost.tp = 1; cost.tn = 1; cost.fp = 1; cost.fn = 1;
                                decile = "both"
