### EVALUATE PREDICTION ###
#
# Chris Louden
# Louden Consulting Group
# 18 May 2011
#
# Notes: This function evaluated a predictive model for two groups

### Inputs ###
# actual = The actual outcome
# predicted = The probablility of the outcome
# cut = The probability above which the outcome is predicted to occur
# event = The name of the event
# group.names = The group names in the same order as levels(actual)
# alpha = Type I error
# ci.type = a pass through to binom.confint selecting conf.int type
#           default is bayes (i.e. jefferys). Additional choices are:
#           "exact", "ac", "asymptotic", "wilson", "prop.test", "bayes", "logit",
#           "cloglog", "probit".  Selecting "all" will result in "bayes"
# roc, net = TRUE if you want the graphics made
# roc.filename, net.filename = filenames for graphics
# roc.*, net.* = graphical parameters for Roc, net benefit curve
# roc.filetypes, net.filetypes = filetypes for graphics (default = png)
#                                Valid filetypes are png, pdf, tiff, jpeg, bmp
# cost.* = cost parameters for net benifit curve (NOT IMPLIMENTED)
# decile = "predicted" cuts made on the deciles of predicted
#          "real" cuts made on [0,1] in 0.1 intervals
#          "both" both above tables are made
# ... = additional parameters to binom.confint or file creation functions

### Outputs ###

### TEST INPUTS 
actual <- rep(c("Alive", "Dead"), 50)
predicted <- c(rnorm(50), rnorm(50, 1))
predicted <- (predicted - min(predicted))/(max(predicted) - min(predicted))
cut <- 0.5

evaluate.prediction <- function(actual, predicted, cut = 0.5, event = "Dead", group.names = c("Alive", "Dead"),
                                alpha = 0.05, ci.type = "bayes",
                                roc = TRUE, roc.filename = "roc", roc.filetype = "png",
                                roc.main = "", roc.lwd = 2, roc.lty = 1, roc.col = "black",
                                roc.abline.lwd = 2, roc.abline.lty = 1, roc.abline.col = "red",
                                roc.auc.pos = c(), roc.auc.cex = 1, roc.auc.adj = c(1, 1),
                                net = TRUE, net.filename = "net.benefit", net.filetype = "png",
                                cost.tp = 1, cost.tn = 1, cost.fp = 1, cost.fn = 1,
                                decile = "both", ...){

# Housekeeping
if(!require(ROCR)){ print("ROCR package must exist"); return(-1) }
if(!require(binom)){ print("binom package must exist"); return(-1) }

actual <- as.factor(actual)
event.index <- which(group.names == event)
fail.index <- which(group.names != event)
predicted.group <- ifelse(predicted > cut, event, group.names[fail.index ])
alpha.star <- 1 - sqrt(1 - alpha)

if(ci.type !%in% c("exact", "ac", "asymptotic", "wilson", "prop.test", "bayes", "logit", "cloglog", "probit")){
   print(paste("WARNING: ", ci.type, " not a valid ci.type.  Defaulting to bayes.", sep = ""))
   ci.type = "bayes"
}

if(length(levels(actual) != length(group.names)){
   print("WARNING: Less group names than possible outcomes. Using levels(actual) as group names")
   group.names <- levels(acutal)
}

# Confusion Matrix
table <- table(predicted.group, actual) #row = predicted; col = actual

tp <- table[event.index, event.index]; tn <- table[fail.index, fail.index ]
fp <- table[event.index, fail.index]; fn <- table[fail.index, event.index ]
pos <- tp + fn; neg <- tn + fp
pred.pos <- tp + fp; pred.neg <- tn + fn;
correct <- tp + tn; incorrect <- fn + fp
n <- sum(table)

table <- cbind(table, rowSums(table))
table <- rbind(table, colSums(table))

se.res <- binom.confint(tp, pos, conf.level = 1 - alpha, method = ci.type)
se <- paste(smart.round(se.res$mean), " (", smart.round(binom.se(tp, pos)), ")", sep = "")
se.se <- smart.round(binom.se(tp, pos))

sp.res <- binom.confint(tn, neg, conf.level = 1 - alpha, method = ci.type)
sp <- paste(smart.round(sp.res$mean), " (", smart.round(binom.se(tn, neg)), ")", sep = "")
sp.se <- smart.round(binom.se(tn, neg))

col.sens <- c(se, "", "")
col.spec <- c(sp, "", "")

table <- cbind(table, col.sens)
table <- cbind(table, col.spec)

colnames(table) <- c(group.names, "Total", "Sensitivity", "Specificity")
rownames(table) <- c(group.names, "Total") 

# Statistics based on above

acc.res <- binom.confint(correct, n, conf.level = 1 - alpha, method = ci.type)
acc <- paste(smart.round(acc.res$mean), " (", smart.round(binom.se(correct, n)), ")", sep = "")
acc.ci <- paste("(", smart.round(acc.res$lower), ", ", smart.round(acc.res$upper), ")", sep = "")

se.ci <- paste("(", smart.round(se.res$lower), ", ", smart.round(se.res$upper), ")", sep = "")

sp.ci <- paste("(", smart.round(sp.res$lower), ", ", smart.round(sp.res$upper), ")", sep = "")

fpf.res <- binom.confint(fp, neg, conf.level = 1 - alpha, method = ci.type)
fpf <- paste(smart.round(fpf.res$mean), " (", smart.round(binom.se(fp, neg)), ")", sep = "")
fpf.ci <- paste("(", smart.round(fpf.res$lower), ", ", smart.round(fpf.res$upper), ")", sep = "")

ppv.res <- binom.confint(tp, pred.pos, conf.level = 1 - alpha, method = ci.type)
ppv <- paste(smart.round(ppv.res$mean), " (", smart.round(binom.se(tp, pred.pos)), ")", sep = "")
ppv.ci <- paste("(", smart.round(ppv.res$lower), ", ", smart.round(ppv.res$upper), ")", sep = "")

npv.res <- binom.confint(tn, pred.neg, conf.level = 1 - alpha, method = ci.type)
npv <- paste(smart.round(npv.res$mean), " (", smart.round(binom.se(tn, pred.neg)), ")", sep = "")
npv.ci <- paste("(", smart.round(npv.res$lower), ", ", smart.round(npv.res$upper), ")", sep = "")

joint.se.res <- binom.confint(tp, pos, conf.level = 1 - alpha.star, method = ci.type)
joint.se.ci <- paste("(", smart.round(joint.se.res$lower), ", ", smart.round(joint.se.res$upper), ")", sep = "")
joint.sp.res <- binom.confint(tn, neg, conf.level = 1 - alpha.star, method = ci.type)
joint.sp.ci <- paste("(", smart.round(joint.sp.res$lower), ", ", smart.round(joint.sp.res$upper), ")", sep = "")
joint.fpf.res <- binom.confint(fp, neg, conf.level = 1 - alpha.star, method = ci.type)
joint.fpf.ci <- paste("(", smart.round(joint.fpf.res$lower), ", ", smart.round(joint.fpf.res$upper), ")", sep = "")

joint.sp <- paste(joint.se.ci, " x ", joint.sp.ci, sep = "")
joint.fpf <- paste(joint.se.ci, " x ", joint.fpf.ci, sep = "")

est <- c(acc, se, fpf, sp, ppv, npv)
ci <- c(acc.ci, se.ci, fpf.ci, sp.ci, ppv.ci, npv.ci)
joint <- c("", "", joint.fpf, joint.sp, "", "")
stats <- cbind(est, ci, joint)
colnames(stats) <- c("Estimate", "CI", "Joint")
rownames(stats) <- c("Accuracy", "Sensitivity", "False Positive Fraction", "Specificity", 
                     "Positive Predictive Value", "Negative Predictive Value")

# ROC Curve
if(roc){
   if(roc.filetype !%in% c("png", "jpeg", "bmp", "tiff", "pdf")){
      print(paste("WARNING: ", roc.filetype, " is not a valid file type for the ROC curve.  Defaulting to png", sep = ""))
      roc.filetype = "png"
   }
   print("ONLY .png implementd")
   roc.filename <- paste(roc.filename, roc.filetype, sep = ".")
   FUN <- match.fun(roc.filetype, descend = TRUE)
   FUN(roc.filename, ...)
   pred <- prediction(predicted, actual, label.ordering = c(levels(actual)[levels(actual) != event],levels(actual)[levels(actual) == event])) 
   x <- slot(performance(pred, "tpr", "fpr"), "x.values")[[1]]
   y <- slot(performance(pred, "tpr", "fpr"), "y.values")[[1]]
   auc <- robust.auc(predicted[actual == event], predicted[actual != event])
   auc <- paste("AUC: ", smart.round(auc[1]), " (", smart.round(auc[2]), ")", sep = "")    
   plot(x, y, cex.lab = 1.5, lwd = 2, type = "l", axes = FALSE, xlab = "1 - Specificity", ylab = "Sensitivity")
   text(x = 0.99, y = 0.01, labels = paste("AUC: ", round(slot(auc, "y.values")[[1]], 4), sep = ""), adj = c(1, 0), cex = 1.5)
   axis(1, seq(0, 1, by = 0.2), cex = 1.5, pos = c(0, 0, 0, 1))
   axis(2, seq(0, 1, by = 0.2), cex = 1.5, pos = c(0, 0, 1, 0))
   segments(0, 0, 1, 1, lwd = 2)
   segments(0, 1, 1, 1, lwd = 1)
   segments(1, 0, 1, 1, lwd = 1)   
   dev.off()      
}

# Net Benefit Curve
if(net){
   if(net.filetype !%in% c("png", "jpeg", "bmp", "tiff", "pdf")){
      print(paste("WARNING: ", net.filetype, " is not a valid file type for the ROC curve.  Defaulting to png", sep = ""))
      net.filetype = "png"
   }   
   net.filename <- paste(net.filename, net.filetype, sep = ".")
}
# Decile Table  (needs a lot of work)

# note, if deciles == both, predicted is first, real is second
deciles <- vector(mode = "list", length = ifelse(decile == "both", 2, 1))
if(decile == "predicted" | decile == "both"){
   cuts <- quantile(predicted, probs = seq(0, 1, 0.1))
   cuts[1] <- 0
   cuts[11] <- 1
   cut.labels <- as.character(cuts)
   decile.group <- rep(NA, length = length(predicted))  
   row.names <- NULL
   for(i in 1:10){
      decile.group[predicted >= cuts[i] & predicted <= cuts[i + 1]] <- i
      row.names <- c(row.names, paste(cut.labels[i], "-", cut.labels[i + 1], sep = ""))
   }
   decile.table <- matrix(table(decile.group), 10, 1)
   pval <- c(format.p.val(chisq.test(decile.table)$p.value), rep("", 9))
   decile.table <- cbind(decile.table, pval)   
   colnames(decile.table) <- c("N", "P-Value")
   rownames(decile.table) <- row.names 
}
if(decile == "real" | decile == "both"){
   cuts <- seq(0, 1, by = 0.1)
   cut.labels <- as.character(cuts)
   decile.group <- rep(NA, length = length(predicted))  
   row.names <- NULL
   for(i in 1:10){
      decile.group[predicted >= cuts[i] & predicted <= cuts[i + 1]] <- i
      row.names <- c(row.names, paste(cut.labels[i], "-", cut.labels[i + 1], sep = ""))
   }
   decile.table <- matrix(table(decile.group), 10, 1)
   pval <- c(format.p.val(chisq.test(decile.table)$p.value), rep("", 9))
   decile.table <- cbind(decile.table, pval)   
   colnames(decile.table) <- c("N", "P-Value")
   rownames(decile.table) <- row.names 
}
  
# Return
output <- list(table = table, stats = stats)
return(output)  
                 
### FUNCTION END ###                                
}



