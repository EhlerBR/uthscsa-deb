##############################################################################
# University of Texas Health Science Center at San Antonio
# Department of Epidemiology and Biostatistics                        
##############################################################################
# Filename: r.dummy.project.main                                 
# Author: Benjamin Ehler                                                
# Project Name: R Dummy Project
# Input: dummy_data.csv
#        dummy_data_dictionary.csv 
# Output: 
#
# Modification History:
# v 0.1 Creation - BE - 28 Aug 2013 (actually a re-creation from the project, Stain_Analysis_Example) 
# v 1.1 Update Shared Directory - BE
##############################################################################

# The commented text above is our standard, UTHSCSA Dept. header and should appear at the top of each program

##############################################
##############   A FEW BASICS   ##############
##############################################

# To get R information or download, go to:
# http://cran.revolutionanalytics.com/

# For an R editor, download Tinn-R or for an IDE, download RStudio

# For basic knowledge of the R language, visit the website 'howtor.net'

##################################################
##############   SET UP WORKSPACE   ##############
##################################################

  rm(list=ls()) # Clears all previous saved objects, lists, functions, data, etc. from the working, R workspace 
  set.seed(101100) # Important if using any random/similution code (including the Fisher simulation in cat_sum or summarize.data.frame)

# Create macros from which to store/load documents/data
  root <- "C:/Users/Ben Ehler/Documents/"  # Change to personal workspace
  dir <- file.path(root, "Projects/R Dummy Project/")
  data.dir <- file.path(dir, "data/")
  documents.dir <- file.path(dir, "documents/")
  programs.dir <- file.path(dir, "programs/")

# Creates date macro: running the word, date, will return today's date in the form: "DD MMM YYYY"
  date <- format(Sys.time(), "%d %b %Y")
     
# Load shared folder that contains cont_sum, cat_sum, summarize.data.frame, format.p.value, etc.
# Some files included in the shared folder need additional packages to run
# If warnings appear, please download the packages indicated in the warning and then use the require function to load them
  shared.dir <- paste(dir, "Shared/R/", sep = "")
  files <- list.files(shared.dir)
  for(file in files)  # brackets are not necessary when only one line follows the for loop
    source(file.path(shared.dir, file))

# Load any additional packages necessary for the project
  require(plyr)
  require(reshape2)

##############################################
##############   READ IN DATA   ##############
##############################################
    
### Read In Data and assign to object: raw.data of class: data.frame (df) ###
  raw.data <- read.csv(paste(data.dir, "dummy_data.csv", sep = "")) # paste("name1", "name2", sep = "") concatenates name1name2
             
# Note: If R reads an invalid df column name symbol, it converts it to "."
# Note: df column names must start with a letter; if not, R will precede it with "X"
# Note: If column names are not unique, each subsequent column name will have ".1", ".2", ".3", etc. added to the end of the name
# Therefore, in this dataset, the four columns named "%", become: "X.", "X..1", "X..2", "X..3"


##############################################
##############   CLEAN DATA   ################
##############################################

# delete rows without data; keep rows 1 to 18 and columns 1 to 14; matrices and data frames can be called with example.table[rows, columns] 
# When hard-coding data cells by numbers, be careful that the format of any new versions of the dataset remains the same
  nuclear.data <- raw.data[1:28, 1:14]
# You can also do this by the Genzyme Label if you make sure all of the labels are included in the list
  nuclear.data <- raw.data[c(grep("_A", raw.data[, 1]), grep("_B", raw.data[, 1]), grep("_C", raw.data[, 1])), 1:14]
               
# Assign column names manually 
  names(nuclear.data) <- c("Label", "HE.Label", "CXCR4.Image", "CXCR4.Image.Perc", "CXCR4.Nucl", "CXCR4.Nucl.Perc", "CXCR4.Cyto", 
                            "SDF1.Image", "SDF1.Image.Perc", "SDF1.Nucl", "SDF1.Nucl.Perc", "SDF1.Cyto", "Color", "Tx")

# Assign any value of "N T" or "NT" (no tumor) to missing
  nuclear.data[nuclear.data == "N T"] <- NA
  nuclear.data[nuclear.data == "NT"] <- NA
                 
# R automatically assigns a class to all variables; This needs to be changed a majority of the time before data cleaning can be done 
# The 'for' statement runs a loop for each index (ex: col_index) within a set of assigned indices (ex: char.columns) up to the '}'
# To run a loop for all rows, assign 1:nrow(data) as the indices set;  for all columns, 1:ncol(data)

# The following loops isolate individual variables (columns) and alter their class to character or factor
# Be sure that each assignment includes the index on both sides of the '<-'; if not, only 1 value will be changed or all will be changed to the same value (a warning should occur)
# You can list out the columns to be converted by number...     
  char.columns <- c(1:3, 7, 8, 10, 13)
# ...or name (This is the more consistent method that protects against a change in order in subsequent datasets
  char.columns <- grep("TRUE", names(nuclear.data) %in% c("Label", "HE.Label", "CXCR4.Image", "CXCR4.Cyto", "SDF1.Image", "SDF1.Nucl", "Color"))
  for(col_index in char.columns){
    nuclear.data[, col_index] <- as.character(nuclear.data[, col_index])
  }

# when converting to a factor, it is almost always better to convert to a character first;  This prevents the creation of empty factor levels              
# Once again, you can list out the columns to be converted by number...     
  fact.columns <- c(4:6, 9, 11, 12)
# ...or name
  fact.columns <- grep("TRUE", names(nuclear.data) %in% c("CXCR4.Image.Perc", "CXCR4.Nucl", "CXCR4.Nucl.Perc", "SDF1.Image.Perc", "SDF1.Nucl.Perc", "SDF1.Cyto"))
  for(col_index in fact.columns){
     nuclear.data[, col_index] <- as.factor(as.character(nuclear.data[, col_index]))
  }
  
# Here I am creating a Numeric Variable (for this example only) to show how continuous data is treated with an outlier
  nuclear.data$random.number <- c(runif((nrow(nuclear.data) - 1), min = 0, max = 100), 200)
            
# Though the variable, 'Tx', needs to be re-factored as well, inconsistent data must be fixed first
  nuclear.data$Tx[nuclear.data$Tx == "AMD3100 + SFLT1"] <- "AMD3100+SFLT1"
# Factor levels are, as default, arranged alpha-numerically;  to prevent this, use the function: factor()
# With factor(), levels are then arranged and can be renamed using the labels option
# WARNING: if using labels option, order the same as in levels
  nuclear.data$Tx <- factor(nuclear.data$Tx, levels = c("Control", "AMD3100", "SFLT1", "AMD3100+SFLT1"))
  
# Create New Group Variables #
# In this dataset, the variables, CXCR4.Cyto and SDF1.Nucl have a numeric factor (0 through 3) combined with a character note ('e' or 'pn')
# The PI wants to see these factored both by the combination of numbers and characters and by only the numbers lumped together
# The following creates two new variables that have only the numbers

# The grep function() returns locations of points that contain the quoted string; if there are none, it will return 'integer(0)'
  nuclear.data$CXCR4.Cyto.grp <- NA  # Creates variable where all elements are NA
  nuclear.data$SDF1.Nucl.grp <- NA  # Creates variable where all elements are NA
  for(grp_index in 0:3) {
    nuclear.data$CXCR4.Cyto.grp[grep(grp_index, nuclear.data$CXCR4.Cyto)] <- grp_index
    nuclear.data$SDF1.Nucl.grp[grep(grp_index, nuclear.data$SDF1.Nucl)] <- grp_index
  }                      
# Note: These are now of class numeric, but the following will convert them to factors before the summary analysis is performed
# We can now create tables to detect any errors or categories that were unaccounted for (this includes the NAs, which is not the default
  table(nuclear.data$CXCR4.Cyto, nuclear.data$CXCR4.Cyto.grp, useNA = "ifany")
  table(nuclear.data$SDF1.Nucl, nuclear.data$SDF1.Nucl.grp, useNA = "ifany") 


# The following is designed to label the factors as the PI indicated (changed from what is in the raw data)
# This will be uniquely coded according to project
  perc_cols <- c(4, 6, 9, 11)
  for(col_index in perc_cols){
    label.ind <- (unique(sort(as.numeric(as.character(nuclear.data[,col_index]))))) + 1
    label.vector <- c("no staining", "<10%", "10-50%", ">50%")
    nuclear.data[,col_index] <- factor(nuclear.data[,col_index], levels = unique(sort(nuclear.data[,col_index])), labels = label.vector[label.ind])
  }
     
  nucl_cols <- c(5, 17)
  for(col_index in nucl_cols){
   label.ind <- (unique(sort(as.numeric(as.character(nuclear.data[,col_index]))))) + 1
   label.vector <- c("negative", "weak", "moderate", "strong")
   nuclear.data[,col_index] <- factor(nuclear.data[,col_index], levels = unique(sort(nuclear.data[,col_index])), labels = label.vector[label.ind])
  }
  cyto_cols <- c(12, 16)
  for(col_index in cyto_cols){
    label.ind <- (unique(sort(as.numeric(as.character(nuclear.data[,col_index]))))) + 1
    label.vector <- c("negative", "weak", "moderate", "strong")
    nuclear.data[,col_index] <- factor(nuclear.data[,col_index], levels = unique(sort(nuclear.data[,col_index])), labels = label.vector[label.ind])
  }

  exp.cyto.levels <- c("0", "1", "1e", "2e", "3e")
  exp.cyto.labels <- c("negative", "weak", "weak (endothelial)", "moderate (endothelial)", "strong (endothelial)")
  nuclear.data$CXCR4.Cyto <- factor(nuclear.data$CXCR4.Cyto, levels = exp.cyto.levels, labels = exp.cyto.labels)
  
  exp.nucl.levels <- c("0", "1", "1pn", "2", "2pn", "3")
  exp.nucl.labels <- c("negative", "weak", "weak (partial nuclear staining)", "moderate", "moderate (partial nuclear staining)", "strong")
  nuclear.data$SDF1.Nucl <- factor(nuclear.data$SDF1.Nucl, levels = exp.nucl.levels, labels = exp.nucl.labels) 
  
# The following is used to fix the variable, color
# There are several ways that this variable has been entered (t() transposes an object, which turns 
# this general vector into a horizontal, and then vertical vector to better view the differences)
  t(t(nuclear.data$Color))
  nuclear.data$Color <- gsub(" ", "", nuclear.data$Color)  # Removes all blanks to create a uniform format
  t(t(nuclear.data$Color))
# Obviously because of the 1-digit and two-digit numbers, it is more difficult than using the substring function
  for(row_index in 1:nrow(nuclear.data)) {
    if(suppressWarnings(is.na(as.numeric(substr(nuclear.data$Color[row_index], 2, 2))))) {
      nuclear.data$Color[row_index] <- paste(substr(nuclear.data$Color[row_index], 1, 1), substr(nuclear.data$Color[row_index], 2, nchar(nuclear.data$Color[row_index])), sep = "_")
    } else {
      nuclear.data$Color[row_index] <- paste(substr(nuclear.data$Color[row_index], 1, 2), substr(nuclear.data$Color[row_index], 3, nchar(nuclear.data$Color[row_index])), sep = "_")
    }
  }      
  
  cleaned.data <- nuclear.data
  
  write.csv(cleaned.data, file = file.path(data.dir, "clean_data.csv"), row.names = FALSE)
      
#######################################################
##############   CLEAN DATA VALIDATION   ##############
#######################################################

# validate.data.2 function is used to take a look at the data, based on a manually created data dictionary
# This is a good way to look if the data is outside the reasonable range or if there are factors that were not expected
# This creates a list object, csv & rtf of tables, and pdf of plots
# If you have SAS open while you run a function involving SAS in the background, it is possible that a warning message will occur, but will still create the output

  clean.validation <- validate.data.2(raw.data.file = "clean_data.csv", 
                                      data.dictionary.file = "dummy_data_dictionary_clean.csv", 
                                      data.loc = data.dir, 
                                      output.loc = documents.dir, 
                                      summarize.by.group = TRUE, 
                                      filename = "Temp_Filename_Clean",
                                      stylepath = dir)
         

##########################################################################
##############   CREATE THE SUMMARY TABLE WITH CLEAN DATA   ##############
##############         USING SUMMARIZE.DATA.FRAME           ##############
##########################################################################

# summarize.data.frame creates a summary table for all columns indicated by the columns option, separated by a specified outcome variable.  

# View Clean Dataset
  cleaned.data

### Create Table 1 (Stain Analysis Data Summary) ###

# Assign new temporary dataset
  table1.data <- cleaned.data

# summarize.data.frame creates a summary table for 1 or multiple variable(s) separated by a specified outcome variable
# It reads each variable separately, and will analyze it by cat_sum or cont_sum, depending on the class of the variable

# The following are the options and option descriptions for the summarize.data.frame function

# data.: The entire dataset from which the variables are pulled
# outcome.: the independent factor variable over which data will be compared (if the outcome is not a factor, it will be converted)
# columns.: indicate which variables to summarize (do not include the outcome variable)
# names.: default is names(data.) You have the option to rename the variables for output
# output.: logical, should the data be written to a file? (does not affect the assignment or printing)          
# filename.: If output = TRUE, to where should the summary be written?

  data1 <- table1.data
  outcome1 <- table1.data$Tx
  columns1 <- c(4:7, 16, 9:10, 17, 11:12, 15)   
  filename1 <- paste(documents.dir, "Stain Analysis Data Summary (", date, ").csv", sep = "")
  full.summ <- summarize.data.frame(data. = data1, outcome. = outcome1, columns. = columns1, output. = TRUE, filename. = filename1)

# view summary table (class: list)
  full.summ

# nucl.summ is now a list, consisting of a data.frame ($table) and a matrix ($pvalues)

# In $table, all of the continuous variables show summary statistics and have a Kruskal-Wallis (Mann-Whitney U) p-value

# All of the factor variables are shown in contingency tables and have a Fisher's Exact test p-value
# In this case, all of the factor variables contain a cell with a frequency of less than 5, so the p-value is according to Fisher's test
# Warning: if the dependent OR independent variable contains more than 3 levels, simulation will be included in the Fisher's test
# If a factor variable had all cells at least 5, a Chi-Square test would be utilized    

# All p-values are formatted using the format.p.value function (shared), but the $pvalues vector contains the unformatted values to adjust for multiple comparisons

# The row and panel columns make for easy call of specific rows/variables in both R and SAS
# For example, to pull information for the SDF1.Nucl variable:
  full.summ$table[full.summ$table$panel == 7, ]
           
# Here I have chosen to alter the names of some of the variables for output
  label.col <- full.summ$table[, 1]
  label.col <- gsub(".Perc", " Percentage", label.col)
  label.col <- gsub(".Nucl", " Nuclear", label.col)
  label.col <- gsub(".Cyto", " Cytoplasmic", label.col)
  label.col <- gsub(".grp", " group", label.col)
  label.col <- gsub(".Image", " Image", label.col)
  table.1 <- cbind(label.col, full.summ$table[,-1])

# Write (clean) table to file
  write.csv(table.1, file = paste(documents.dir, "Table 1 (", date, ").csv", sep = ""), row.names = FALSE)


#############################################################
##############   CREATE SUMMARY TABLES USING   ##############
##############      CAT_SUM AND CONT_SUM       ##############
#############################################################

# The cat_sum and the cont_sum can be used to analyze a single comparison #

# Test for Inhibiting Effects on other drugs using cat_sum 
# Assign new temporary dataset
  table2.data <- cleaned.data

# The following are all of the options for the cat_sum function
     
# class: The outcome variable by which the summary is split 
# var: The variable being analyzed
# class.labels: The level labels of the 'class' variable (no default)
# var.name: The name by which 'var' is labeled 
# var.label: Level names of 'var' variable
# test: "fisher" or "chisq" is automatically chosen depending on the contingency table
# panel: option to assign a variable identification number when combining with other tables
# row.perc: Determines whether the contingency table percentages are by row (TRUE) or by column (FALSE)
  image_perc.summ <- cat_sum(class = table2.data$CXCR4.Image.Perc, var = table2.data$SDF1.Image.Perc, class.labels = levels(table2.data$CXCR4.Image.Perc), 
                             var.name = "SDF1 Image Percentage", panel = 1, row.perc = FALSE)[[1]]
# The output is a list with [[1]] as the table matrix and [[2]] as a numeric of the unformatted p-value
# write table to a csv document in data folder
  write.csv(image_perc.summ, file = paste(documents.dir, "Table 2 image_perc (", date, ").csv", sep = ""), row.names = FALSE)

# Repeat for other three, comparable variables                                                                                                                       
  nucl.summ <- cat_sum(class = table2.data$CXCR4.Nucl, var = table2.data$SDF1.Nucl.grp, class.labels = levels(table2.data$CXCR4.Nucl),
                                 var.name = "SDF1 Nuclear", panel = 2, row.perc = FALSE)[[1]]
  write.csv(nucl.summ, file = paste(documents.dir, "Table 2 nucl (", date, ").csv", sep = ""), row.names = FALSE)
                                                                                                                        
  nucl_perc.summ <- cat_sum(class = table2.data$CXCR4.Nucl.Perc, var = table2.data$SDF1.Nucl.Perc, class.labels = levels(table2.data$CXCR4.Nucl.Perc),
                                 var.name = "SDF1 Nuclear Percentage", panel = 3, row.perc = FALSE)[[1]]
  write.csv(nucl_perc.summ, file = paste(documents.dir, "Table 2 nucl_perc (", date, ").csv", sep = ""), row.names = FALSE)
                                                                                                                   
  cyto.summ <- cat_sum(class = table2.data$CXCR4.Cyto.grp, var = table2.data$SDF1.Cyto, class.labels = levels(table2.data$CXCR4.Cyto.grp),
                                 var.name = "SDF1 Cytoplasmic", panel = 4, row.perc = FALSE)[[1]]
  write.csv(cyto.summ, file = paste(documents.dir, "Table 2 cyto (", date, ").csv", sep = ""), row.names = FALSE)

                                                                                                                                                                              
# Sample comparison using cont_sum
# Assign new temporary dataset
  table3.data <- cleaned.data   

# The following are all of the options for the cont_sum function

# class: The outcome variable by which the summary is split 
# var: The variable being analyzed
# class.labels: The level labels of the 'class' variable (no default)
# var.name: The name by which 'var' is labeled 
# test: "kw" or "anova"; default is "kw"
# round: To which decimal place to round the summary statistics
# panel: option to assign a variable identification number when combining with other tables
# row.perc: Determines whether the contingency table percentages are by row (TRUE) or by column (FALSE)     
  example.summ <- cont_sum(class = table3.data$CXCR4.Image.Perc, var = table3.data$random.number, class.labels = c("No Staining", "Less than 10 Percent"), 
                                                               var.name = "Important Variable", test = "anova", round = 1, panel = 1)[[1]]
  write.csv(example.summ, file = paste(documents.dir, "Table 3 Example (", date, ").csv", sep = ""), row.names = FALSE)   


################################################################
##############   USE SAS TO PRINT TABLES TO RTF   ##############
################################################################

# The following are all of the options for the SAS.table function, including the options that are normally left to default

# data: data table to output
# filename: a plain filename without the directory (included automatically)
# table.name: a simple name for the tables that are created
# title1: Uppermost Title
# title3: Lower Title
# summ.df: TRUE if table was created by summarize.data.frame; affects footnotes
# table.num: If multiple tables, the current table number
# last: False if table is not the last table to be written of multiple tables
# table.list: If table.num > 1, object that the previous SAS.tables were written to
# before.footnote: vector of quoted strings which will appear in order before the test footnotes
# after.footnote: vector of quoted strings which will appear in order after the test footnotes
# col.labels: Vector of column names (does not include row, panel, or test) for a blank label, assign "@"
# span.head: Vector with same length as column names (does not include row, panel, or test); put "" for columns with no spanning header and repeat values
#                              over all columns that share the header [ex: c("", "Baseline", "Baseline", "6 Months", "6 Months", "", "")] 
# cellwidth: numeric vector of cell widths (in.) in the order of the column labels (Label, factor1, ... ,factorn, total, pvalue)
# fontsize: alters overall font of table (changes style to one where footnote and title sizes are also changed accordingly)
# page.room: alters length of page before creating page break in pagination function (NULL value puts in estimated length according to orientation and number of footnotes)
# just.matrix: matrix with the first column representing the justifications of the headers of the variables and the 2nd column is the justifications of the body of the variables 
# log.pval: changes ONLY FOOTNOTES of tests: DOES NOT CHANGE THE ACTUAL P-VALUES!
# log.base: if log.pval, will change footnote to reflect the base of the log transform
# shared.loc: file path where 'LPG2_STYLE_SMALL_MARGIN_LZ.sas' is located.  If stylepath = "shared", function uses the user-defined, 'root'
# output.loc: file path where the results are written
# clean.folder: if true, deletes all table files and log except for final rtf
          
        
  temp.table.list <- SAS.table(data = nucl.summ, 
                               filename = "Example Output", 
                               table.name = "nucl.summ", 
                               title1 = "This is For the Uppermost Title", 
                               title3 = "This is for the Lower Title", 
                               summ.df = TRUE, 
                               table.num = 1, 
                               last = FALSE, 
                               table.list = temp.table.list, 
                               before.footnote = "Here you can add a footnote before the test footnotes", 
                               after.footnote = "Here you can add a footnote after the test footnotes", 
                               orientation = "portrait",
                               col.labels = c("Label", "Negative", "Weak", "Moderate", "Strong", "Total", "Pval"),
                               span.head = c("", rep("SDF1 Nuclear Group", 4), "", ""),
                               cellwidth = NULL, 
                               page.room = NULL, 
                               fontsize = NULL, 
                               just.matrix = NULL,
                               stylepath = dir)

  temp.table.list <- SAS.table(data = example.summ, 
                               filename = "Example Output", 
                               table.name = "example.summ", 
                               title1 = "R Dummy Project", 
                               title3 = paste("Example Summary (", date, ")", sep = ""), 
                               table.num = 2, 
                               last = TRUE, 
                               table.list = temp.table.list,
                               stylepath = dir)
                               

# If you have a table, not made from the summarize.data.frame or summary functions, make sure that summ.df is set to FALSE (the default is TRUE)
  sample.data <- cleaned.data[, 1:9]
  sample.data$panel <- NA
  sample.data$panel[grep("_A", sample.data$Label)] <- 1
  sample.data$panel[grep("_B", sample.data$Label)] <- 2
  sample.data$panel[grep("_C", sample.data$Label)] <- 3

  temp.table.list <- SAS.table(data = sample.data, 
                               filename = "Example Sample Dataset", 
                               table.name = "example.data", 
                               title1 = "Example Output", 
                               title3 = "First 10 Entries from the Dataset",
                               summ.df = FALSE, 
                               orientation = "landscape")

                               
#####################################################
##############   DEMONSTRATE TESTING   ##############
#####################################################

# For testing, some random vectors are created
random.cont.1 <- rnorm(n = 100, mean = 0, sd = 1)
random.cont.2 <- rexp(n = 100, rate = 1)
random.cat.1 <- factor(sample(c("TRUE", "FALSE"), size = 100, replace = TRUE))
random.cat.2 <- factor(sample(c("Disagree", "Neutral", "Agree"), size = 100, replace = TRUE))

fisher.test(random.cat.1, random.cat.2)  # May have to use simulate.p.value if there are many categories (make sure a seed is set for randomization)
chisq.test(random.cat.1, random.cat.2)  # If all cells have at least n = 5
anova(lm(random.cont.1 ~ random.cat.2))
kruskal.test(random.cont.1, random.cat.2)  # For non-parametric
# For any of the above, use the names() function to identify elements to extract

# For survival testing, more random vectors
random.group <- as.factor(rep(1:4, times = 25))
random.time <- rep(1:20, times = 5)

example.survdiff <- survdiff(Surv(random.time, as.logical(random.cat.1)) ~ random.group)
# Chi-square statistic for the log-rank test
example.survdiff$chisq
# Log-rank p-value
example.pvalue <- format.p.value(1 - pchisq(example.survdiff$chisq, (length(example.survdiff$obs) - 1)))
# Create survival curve for Kaplan Meier (PLOT FUNCTIONS section)
example.survfit <- survfit(Surv(random.time, as.logical(random.cat.1)) ~ random.group)

####################################################################
##############   DEMONSTRATE OTHER USEFUL FUNCTIONS   ##############
####################################################################

  work.data <- cleaned.data[, c("Color", "Tx", "CXCR4.Nucl", "CXCR4.Cyto.grp", "SDF1.Cyto", "SDF1.Nucl.grp")]

# melt is an function from the reshape2 package that provides a simple way to reshape the data
# This function is highly useful when creating a kaplan meier curve in survival data
  reshape.data <- melt(work.data, id = c("Color", "Tx"))

  reshape.data$variable <- as.character(reshape.data$variable)
  reshape.data$variable <- gsub(".grp", "", reshape.data$variable)

# To separate the elements of the variables, 'Color' & 'variable' you could use:
  split.variable <- colsplit(reshape.data$variable, pattern = "\\.", names = c("Protein", "Location"))  
  split.Color <- colsplit(reshape.data$Color, pattern = "_", names = c("Animal_Color", "Animal_Number"))  # Notice the "\\" escape character to bypass the special character, '.'

# Or to add them directly into the dataset:
  reshape.data[, c("Protein", "Location")] <- colsplit(reshape.data$variable, pattern = "\\.", names = c("", ""))
  reshape.data[, c("Animal_Color", "Animal_Number")] <- colsplit(reshape.data$Color, pattern = "_", names = c("", "")) 

# Remove the variable, 'variable' from the data.frame
  reshape.data <- reshape.data[, !names(reshape.data) %in% c("Color", "variable")]

  ddply(reshape.data, .(Location, Animal_Color), nrow)

################################################
##############   PLOT FUNCTIONS   ##############
################################################

# Scatterplot
  plot(cleaned.data$random.number)
#                                            main title                     x label            y label          point type       color of points   make y axis point labels vertical
  plot(cleaned.data$random.number, main = "Scatterplot of Random Numbers", xlab = "Index", ylab = "Random Number", pch = 15,         col = "blue",    las = 1)
# add points
  points(x = 1:nrow(cleaned.data), y = runif(nrow(cleaned.data), 0, 100))
# add lines
  lines(x = 1:nrow(cleaned.data), y = runif(nrow(cleaned.data), 0, 100))
  lines(x = 1:nrow(cleaned.data), y = runif(nrow(cleaned.data), 0, 100), lty = 2, lwd = 2)  

  plot(cleaned.data$random.number, xaxt = 'n')  # removes all x titles
# add x axis
  axis(1, at = seq(0, 30, 5), labels = paste("I", seq(0, 30, 5))) 

# Boxplot
  boxplot(random.number ~ Tx, data = cleaned.data)
# Range of 0 makes the whiskers extend to the max and min
  boxplot(random.number ~ Tx, data = cleaned.data, names = c("Control", "AMD", "SFLT", "AMD and SFLT"), range = 0, ylab = "Random Number", xlab = "Treatment")    
# The default range is 1.5, which means the whiskers go to the most extreme data point which is no more than 1.5 times the interquartile range from the box
  boxplot(random.number ~ Tx, data = cleaned.data, names = c("Control", "AMD", "SFLT", "AMD and SFLT"), ylab = "Random Number", xlab = "Treatment")  

# Histogram
  histogram(cleaned.data$random.number)

# Plot Survival Data as Kaplan-Meier Curve
cols <- c("red", "blue", "goldenrod", "black")
plot(example.survfit, col = cols)                   
legend(     "bottomleft",                levels(random.group),                     lty = 1,                           col = cols,                inset = .025,       bty = "n",    title = "Group")
# Location (keyword, can use coordinates); labels for legend;  lines to be printed (can use pch for points); colors of lines (or points); moves the legend inward; don't show box; title of legend
text(x = 5, y = 0.4, labels = paste("Log-rank p-value:", example.pvalue))
  
# Print the plots to pdf or png
#pdf(file = paste(documents.dir, "Example Plot (", date, ").pdf", sep = ""))
  png(paste(documents.dir, "Example Plot (", date, ").png", sep = ""), width = 480*4, height = 480*4, res = 72*4)
    plot(cleaned.data$random.number, main = "Scatterplot of Random Numbers", xlab = "Index", ylab = "Random Number", pch = 21, col = "blue", bg = "sienna1", las = 1, cex = 2.5)
  dev.off()  # shuts down the current (plotting) device - in this example, the png (or pdf)   
  
#####################################
##############   EOF   ##############
#####################################
